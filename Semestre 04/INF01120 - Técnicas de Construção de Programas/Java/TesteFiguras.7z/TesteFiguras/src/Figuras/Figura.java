package Figuras;

public class Figura {
	public double area(){
		return(0);
	}
	public double perimetro(){
		return (0);
	}
	public int numLados(){
		return (0);
	}
}
