package Figuras;

public class Retangulo extends Figura {
	private double base;
	private double altura;
	
	Retangulo(double _base, double _altura){
		base = _base;
		altura = _altura;
	}
	
	public double area(){
		return(base * altura);
	}
	public double perimetro(){
		return (base+ altura);
	}
	public int numLados(){
		return (2);
	}
	
	public void setAltura(double altura) {
		this.altura = altura;
	}
	public double getAltura() {
		return altura;
	}
	public void setBase(double base) {
		this.base = base;
	}
	public double getBase() {
		return base;
	}
	
}
