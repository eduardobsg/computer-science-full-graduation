package Figuras;

public class Triangulo extends Figura {
	private double base;
	private double altura;
	
	Triangulo(double _base, double _altura){
		base = _base;
		altura = _altura;
	}
	
	public double area(){
		return(base * altura / 2);
	}
	public double perimetro(){
		return (base * 3);
	}
	public int numLados(){
		return (3);
	}
	
	public void setAltura(double altura) {
		this.altura = altura;
	}
	public double getAltura() {
		return altura;
	}
	public void setBase(double base) {
		this.base = base;
	}
	public double getBase() {
		return base;
	}
}
