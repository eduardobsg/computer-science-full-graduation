package Figuras;

import java.util.LinkedList;

public class Testefiguras {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		LinkedList<Figura> listaDeFiguras = new LinkedList<Figura>();
		listaDeFiguras.add(new Circulo(1.5));
		listaDeFiguras.add(new Triangulo(2,3));
		listaDeFiguras.add(new Retangulo(2,2));
		
		for(Figura umaFigura : listaDeFiguras){
			System.out.println("Area ="+umaFigura.area());
			
		System.out.println("\nMorra Seiya, seu viadinho!!");
		}
	}

}
