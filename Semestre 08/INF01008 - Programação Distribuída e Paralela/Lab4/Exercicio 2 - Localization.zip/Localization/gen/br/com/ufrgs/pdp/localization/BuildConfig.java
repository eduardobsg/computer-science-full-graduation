/** Automatically generated file. DO NOT MODIFY */
package br.com.ufrgs.pdp.localization;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}