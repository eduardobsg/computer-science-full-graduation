package br.ufrgs.pdp.socket.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

import android.util.Log;

public class SocketClient {

    private String host;
    private Integer porta;
    private Socket socket;
    private DataOutputStream streamDeSaida;
    private DataInputStream streamDeEntrada;

    public SocketClient(String host, Integer porta) {
        this.host = host;
        this.porta = porta;
        this.criaConexao();
    }

    private void criaConexao() {
        try {
            //cria o socket para se conectar ao servidor
            socket = new Socket(host, porta);
            //cria stream de sa�da
            streamDeSaida = new DataOutputStream(socket.getOutputStream());
            //cria stream de entrada
            streamDeEntrada = new DataInputStream(socket.getInputStream());
        } catch (UnknownHostException ex) {

        	Log.d("ERRO","[ERRO] O host � inv�lido!");
            Logger.getLogger(SocketClient.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
        	Log.d("ERRO","[ERRO] Problema na comunica��o!");
            Logger.getLogger(SocketClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void enviaMensagem(String menssagem) {
        try {
            //envia mensagem
            streamDeSaida.writeUTF(menssagem);
            streamDeSaida.flush();
        } catch (IOException ex) {
            Log.d("ERRO","[ERRO] Problema no envio de mensagem = " + menssagem);
            Logger.getLogger(SocketClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private String recebeMensagem() {
        try {
            //aguarda retorno do servidor
            return streamDeEntrada.readUTF();

        } catch (IOException ex) {
            Log.d("ERRO","[ERRO] Erro ao receber mensagem!");
            Logger.getLogger(SocketClient.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public void desconectar() {
        enviaMensagem("EXIT");
        try { // Fecha o socket
            this.socket.close();
        } catch (IOException ex) {
            Logger.getLogger(SocketClient.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }

    public boolean conectar() {
        // Declara��o das Vari�veis
        String msgRecebida;

        // Pede para conectar-se com o servidor
        enviaMensagem("HELLO");

        // Recebe resposta do servidor
        msgRecebida = recebeMensagem();

        // se msgRecebida == WELCOME ent�o Conex�o Aceita
        if (msgRecebida.equals("WELCOME")) {
            return true;
        } else {
            // se msgRecebida == REJECT ent�o Conex�o Negada
            if (msgRecebida.equals("REJECT")) {
                return false;
            } else {
                return false;
            }
        }
    }

    public Integer soma(Integer numero1, Integer numero2) {
        String msgRecebida;
        String res[];

        enviaMensagem("SUM;" + numero1 + ";" + numero2);

        // Espera at� receber a mensagem do servidor
        msgRecebida = recebeMensagem();

        // Quebra a mensagem
        res = msgRecebida.split(";");
        // System.out.println(res[0]+" - "+res[1]);

        /*
         *  res[0] == RESULT
         *  res[1] == resultado da soma
         */
        if (res[0].equals("RESULT")) {
            return Integer.parseInt(res[1]);
        } else {
            return null;
        }
    }
}
