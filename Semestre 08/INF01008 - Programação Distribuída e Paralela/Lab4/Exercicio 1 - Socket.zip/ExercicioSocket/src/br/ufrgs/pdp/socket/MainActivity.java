package br.ufrgs.pdp.socket;

import br.ufrgs.pdp.socket.client.SocketClient;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	private EditText edtNumero1;
	private EditText edtNumero2;
	private Button btnSair;
	private Button btnCalcular;
	private TextView txtResultado;
	private SocketClient cliente;
	private Integer portaServidor;
	private String hostServidor;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// Associa os elementos no XML com Objetos da Classe View
		this.edtNumero1 = (EditText) findViewById(R.id.edtNumero1);
		this.edtNumero2 = (EditText) findViewById(R.id.edtNumero2);
		this.btnCalcular = (Button) findViewById(R.id.btnCalcular);
		this.btnSair = (Button) findViewById(R.id.btnSair);
		this.txtResultado = (TextView) findViewById(R.id.txtResultadoSoma);
		
		// Dados para conex�o
		this.hostServidor = "192.168.1.120";
		this.portaServidor = 8513;
		
		// Cria um cliente e conecta com ele
		cliente = new SocketClient(hostServidor, portaServidor);
		if(!cliente.conectar()){ 
			Log.d("ERRO", "N�o foi poss�vel conectar");
			finish();
		}
		
		// Ouvinte no bot�o Conectar
		this.btnCalcular.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//
				Integer resultadoSoma =0;
				// Envia par�metros para soma
				resultadoSoma = cliente.soma(
						Integer.parseInt(edtNumero1.getText().toString()), 
						Integer.parseInt(edtNumero2.getText().toString()));
				// Exibe resultado
				txtResultado.setText(resultadoSoma.toString());
			}
		});
		
		// Ouvinte no bot�o Sair
		this.btnSair.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// Desconecta-se do servidor
				Log.d("RES","Desconectando");
				cliente.desconectar();
				
				// fecha aplica��o
				finish();
			}
		});
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
