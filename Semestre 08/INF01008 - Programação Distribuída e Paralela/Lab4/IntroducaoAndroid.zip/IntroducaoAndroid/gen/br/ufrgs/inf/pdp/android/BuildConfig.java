/** Automatically generated file. DO NOT MODIFY */
package br.ufrgs.inf.pdp.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}