package br.ufrgs.inf.pdp.android;

import br.ufrgs.inf.pdp.android.R;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainMenuActivity extends Activity {

	// endere�o onde conter� o retorno do resultado de IMC
	private Integer IMC_RC = 1;

	// Objetos filhos da Classe View para manipular os elementos no XML
	private Button btnNavegador;
	private Button btnIMC;
	private Button btnSair;
	private TextView txtUltimoResultadoDeIMC;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// setContentView recebe por par�metro a refer�ncia do Layout em XML
		// o qual a presente Activity vai interagir
		setContentView(R.layout.main_menu);

		// Integra��o entre XML e Objetos
		btnNavegador = (Button) findViewById(R.id.btnNavegador);
		btnIMC = (Button) findViewById(R.id.btnIMC);
		btnSair = (Button) findViewById(R.id.btnSair);
		txtUltimoResultadoDeIMC = (TextView) findViewById(R.id.txtUltimoResultadoDeIMC);

		// Adiciona um ouvinte de clicks no bot�o navegador
		btnNavegador.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				abrirNavegador();
			}
		});

		// Adiciona um ouvinte de clicks no bot�o IMC
		btnIMC.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				acessarIMC();
			}
		});

		// Fecha a aplica��o
		btnSair.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
	}

	public void abrirNavegador() {
		// Endere�o da p�gina que ser� aberta
		String endereco = "http://inf.ufrgs.br";
		// Representa o endere�o que vamos abrir
		Uri uri = Uri.parse(endereco);
		// Cria a Intent com o endere�o
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		// Envia a mensagem ao sistema operacional
		startActivity(intent);
	}

	public void acessarIMC() {

		// Cria uma intent para executar a Activity da Classe IMC
		Intent intent = new Intent(getBaseContext(), IMCActivity.class);

		// Executa a activity e espera um resultado.
		startActivityForResult(intent, IMC_RC);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode,
			Intent intentRetornada) {
		// C�digo de requisi��o retornado da tela de IMC
		if (requestCode == IMC_RC) {
			// C�digo de resultado retornado
			if (resultCode == RESULT_OK) {
				// Acessa o resultado da intent retornada, se vier nulo utiliza
				// 0
				Double imc = intentRetornada.getDoubleExtra("imc", 0);
				// Seta o resultado no TextView
				txtUltimoResultadoDeIMC.setText(imc.toString());
				Log.d("Marcador res", imc.toString());
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main_menu, menu);
		return true;
	}

}
