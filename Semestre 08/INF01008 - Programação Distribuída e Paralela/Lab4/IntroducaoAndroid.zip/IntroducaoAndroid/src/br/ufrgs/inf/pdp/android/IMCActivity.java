package br.ufrgs.inf.pdp.android;

import br.ufrgs.inf.pdp.android.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class IMCActivity extends Activity{

	private Double resultadoCalculo;
	private Button btnCalcular;
	private Button btnSair;
	private EditText edtPeso;
	private EditText edtAltura;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.imc);
		
		this.resultadoCalculo = 0.0;
		this.btnCalcular = (Button) findViewById(R.id.btnCalcular);
		this.btnSair = (Button) findViewById(R.id.btnVoltar);
		this.edtAltura = (EditText) findViewById(R.id.edtAltura);
		this.edtPeso = (EditText) findViewById(R.id.edtPeso);
		
		btnCalcular.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				
				Double altura = Double.parseDouble(edtAltura.getText().toString());
				Double peso = Double.parseDouble(edtPeso.getText().toString());
				
				resultadoCalculo = peso/(altura * altura);
				Toast.makeText(IMCActivity.this, "Seu imc �: "+String.valueOf(resultadoCalculo), Toast.LENGTH_LONG).show();				
				
			}
		});
		
		btnSair.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// Cria uma intent para colocar o resultado a ser retornado
				Intent it = new Intent();
				it.putExtra("imc", resultadoCalculo);
				// Adiciona o resultado na resposta para o Menu
				setResult(RESULT_OK,it);
				// Fecha a aplica��o
				finish();
			}
		});
	}	
}
