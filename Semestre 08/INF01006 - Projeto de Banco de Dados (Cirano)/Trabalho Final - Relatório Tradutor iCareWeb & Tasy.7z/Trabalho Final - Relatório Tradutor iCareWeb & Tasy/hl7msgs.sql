﻿-- Tables
CREATE TABLE hl7msgs (
    cdlhl7msgs bigint NOT NULL,
	cdllaudo bigint NOT NULL,
	status boolean
);

CREATE TABLE currentfileindex (
	currentindex bigint NOT NULL
);

-- Constraints
ALTER TABLE ONLY hl7msgs
    ADD CONSTRAINT hl7msgs_pkey PRIMARY KEY (cdlhl7msgs);

ALTER TABLE ONLY hl7msgs
    ADD CONSTRAINT fk_cdlpessoa FOREIGN KEY (cdlpessoa) REFERENCES mbspessoa(cdlpessoa);

-- Data
DELETE FROM currentfileindex;
INSERT INTO currentfileindex VALUES (1);

INSERT INTO tmedocorrencialaudo (cdllaudo, deslaudo, datlaudo) VALUES ('1', 'O paciente tem uns problemas 1', '10-10-2013');
INSERT INTO tmedocorrencialaudo (cdllaudo, deslaudo, datlaudo) VALUES ('2', 'O paciente tem uns problemas 2', '11-10-2013');
INSERT INTO tmedocorrencialaudo (cdllaudo, deslaudo, datlaudo) VALUES ('3', 'O paciente tem uns problemas 3', '12-10-2013');

DELETE FROM hl7msgs;
INSERT INTO hl7msgs (cdlhl7msgs, cdllaudo, status) VALUES ('1','1','TRUE');
INSERT INTO hl7msgs (cdlhl7msgs, cdllaudo, status) VALUES ('2','2','TRUE');
INSERT INTO hl7msgs (cdlhl7msgs, cdllaudo, status) VALUES ('3','3','TRUE');