// testecli.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#ifdef _WIN32
	#include <winsock2.h>
#else
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#define	SOCKET	int
	#define INVALID_SOCKET  ((SOCKET)~0)
#endif


#define PORTA_CLI 1052 // porta TCP do cliente
#define PORTA_SRV 1042 // porta TCP do servidor
#define STR_IPSERVIDOR "127.0.0.1"
//#define STR_IPSERVIDOR "192.168.0.146"

int main(int argc, char* argv[])
{
  	SOCKET s;
  	struct sockaddr_in  s_cli, s_serv;
  
	int server_port;
	int client_port;
	char ip[16];

#ifdef _WIN32
	 WSADATA wsaData;
  
	if (WSAStartup(MAKEWORD(2,2), &wsaData) != 0) {
		printf("Erro no startup do socket\n");
		exit(1);
	}
#endif
  
	//test parameters
  	if(argc < 6){
		printf("Use: tcpclient -h <server_ip> -p <client_port> -q <server_port>\n");
		exit(1);
	}
	int i;
	for(i=1; i<argc; i++){
		if(argv[i][0]=='-'){
			switch(argv[i][1]){
				//ip
				case 'h':
					i++;
					strcpy(ip, argv[i]);
					break;
				//client port 
				case 'p':
					i++;
					client_port = atoi(argv[i]);
					if(client_port < 1024) {
						printf("Invalid cliente port number\n");
						exit(1);
					}
					break;
					  
				case 'q':
                	i++;
					server_port = atoi(argv[i]);
					if(server_port < 1024) {
						printf("Invalid server port number\n");
						exit(1);
					}
                    break;
                         	  
				default:
					printf("Invalid paramenter: %s\n",argv[i]);
					exit(1);
			}		  	 
		}else{
			printf("Invalid paramenter: %s\n",argv[i]); 
			exit(1);
		}
	}

  // abre socket TCP
  if ((s = socket(AF_INET, SOCK_STREAM, 0))==INVALID_SOCKET)
  {
    printf("Erro iniciando socket\n");
    return(0);
  }

  // seta informacoes IP/Porta locais
  s_cli.sin_family = AF_INET;
  s_cli.sin_addr.s_addr = htonl(INADDR_ANY);
  s_cli.sin_port = htons(PORTA_CLI);

  // associa configuracoes locais com socket
  if ((bind(s, (struct sockaddr *)&s_cli, sizeof(s_cli))) != 0)
  {
    printf("erro no bind\n");
    close(s);
    return(0);
  }

  // seta informacoes IP/Porta do servidor remoto
  s_serv.sin_family = AF_INET;
  s_serv.sin_addr.s_addr = inet_addr(STR_IPSERVIDOR);
  s_serv.sin_port = htons(PORTA_SRV);

  // connecta socket aberto no cliente com o servidor
  if(connect(s, (struct sockaddr*)&s_serv, sizeof(s_serv)) != 0)
  {
    //printf("erro na conexao - %d\n", WSAGetLastError());
    printf("erro na conexao");
    close(s);
    exit(1);
  }

#if 0
  // envia mensagem de conexao - aprimorar para dar IP e porta
  if ((send(s, "Conectado\n", 11,0)) == SOCKET_ERROR);
  {
    printf("erro na transmiss�o - %d\n", WSAGetLastError());
    closesocket(s);
    return 0;
  }
#endif

  // recebe do teclado e envia ao servidor
  char str[1250];
  char ch;
  
  
  time_t begin_time=time(NULL);
  time_t current_time;
  i=0;

	while(1){
  	/*
    printf("$ ");

    for(i=0; (i<80) &&  (ch = getchar()) != '\n'; i++ )
      str[i] = (char)ch;
    str[i] = '\0';
    
    //strcpy(str, "mensagem\0");
*/
		//print mbps
		current_time=time(NULL);
		i++;
		if (current_time-begin_time>=1){	
			begin_time=current_time;
			int mbps=(i*1250*8)/(1000000);
			printf("%d Mbps\n",mbps);
			i=0;
		}
		
    if ((send(s, (const char *)&str, sizeof(str),0)) < 0)
    {
      //printf("erro na transmiss�o - %d\n", WSAGetLastError());
      printf("erro na transmiss�o\n");
      close(s);
      return 0;
    }
    if(strcmp((const char *)&str, "q")==0)
      break;
     
     //usleep(100000);
  }

  // fecha socket e termina programa
  printf("Fim da conexao\n");
  close(s);
  return 0;
}
