/*
  Name: Jo�o Luiz Grave Gross
  Exerc�cios de Fixa��o 7.2 - Algoritmos Iterativos e Comando do-while
  Date: 21/03/09 19:45
  Description: Dado o valor de E, tal que 0 < E < 1, calcular:

  s = 1 + 1/2 + 1/4 + 1/6 + 1/8 ...

  at� que um termo da s�rie seja menor que E.
*/

#include<stdlib.h>
#include<stdio.h>

int main ()
{
    float e, s=1, div;
    int deno=0, flag=1, flag2=1;
    printf ("Digite um valor entre 0 e 1 (exclusivo): ");
    scanf ("%f",&e);
    if (e <= 0 || e >= 1)
    {
       printf ("Valor invalido.\nTente denovo.\n\n");
       flag = 0;
       flag2 = 0;
    }
    while (flag)
    {
        deno += 2;
        div=(float)1/deno;
        s += div;
        printf ("div = %f\n",div);
        if (e > div)
        {
           flag = 0;            
           s -= div;
        }
    }
    while (flag2)
    {
       printf ("Saida = %.2f\n\n",s);
       flag2 = 0;
    }
    system ("pause");
    return 0;       
}
