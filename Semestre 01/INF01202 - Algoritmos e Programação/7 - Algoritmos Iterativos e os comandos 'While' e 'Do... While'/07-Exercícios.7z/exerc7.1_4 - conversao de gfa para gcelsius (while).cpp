#include<stdlib.h>
#include<stdio.h>

int main ()
{
	char resp[2];
	float gfa = -600, gcelsius;
	printf ("Quer fazer uma conversao? Digite 'sim' ou 'nao': ");
	scanf ("%s",resp);
//	printf ("%s, %f, %c, %c, %c, %c\n\n",resp, gfa, resp[0], resp[1], resp[2], resp[3]);
	while (resp[0] == 's' && resp[1] == 'i' && resp[2] == 'm')
	{
		while (gfa < -523.4)
		{
			printf ("Indique o valor valido em farenheit para transformar em centigrados: ");
			scanf ("%f",&gfa);
			if (gfa < -523.4)
				printf ("Valor invalido\n\n");
		}
		gcelsius = (float)5 / 9 * (gfa - 32);
		printf ("Graus Celsius: %.2f\n\n",gcelsius);
		gfa = -600;
		printf ("Nova convers�o? Digite 'sim' ou 'nao': ");
		scanf ("%s",resp);
	}
	system ("pause");
	return 0;
}
