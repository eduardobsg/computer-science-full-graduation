/*
  Name: Jo�o Luiz Grave Gross
  Exerc�cios de Fixa��o 7.2 - Algoritmos Iterativos e Comando do-while
  Date: 21/03/09 20:22
  Description: 
  
  Imagine que as �nicas opera��es aritm�ticas dispon�veis na linguagem C sejam a soma + e a 
  subtra��o - . Dados 2 n�meros inteiros positivos X e Y, determinar o quociente e o resto 
  da divis�o de X por Y. Cuidar que a entrada de dados seja no intervalo solicitado, indicado 
  nova entrada em caso negativo. 
*/

#include<stdlib.h>
#include<stdio.h>

int main ()
{
    int x, y, quociente=0, resto=-1, flag=1;
    printf ("Digite dois numeros reais positivos: ");
    scanf ("%d%i",&x,&y);
    if (y == 0)
    {
       printf ("Divisao por zero!\n");
       flag = 0;
    }
    if (y < 0 || x <0)
    {
       printf ("Valores negativos!\n");
       flag = 0;
    }
    while (flag)
    {
       if (x == 0)
       {
          resto = 0;
          quociente = 0;
          flag = 0;
       }   
       while (resto != x)
       {
          //divisao de x por y
          x = x-y;
          quociente = ++quociente;
          if (x < y)
          {
             resto = x;
             flag = 0;          
          }
       }
    printf ("Resto: %d\nQuociente: %d\n\n",resto, quociente);      
    }
    system ("pause");
    return 0;
}
