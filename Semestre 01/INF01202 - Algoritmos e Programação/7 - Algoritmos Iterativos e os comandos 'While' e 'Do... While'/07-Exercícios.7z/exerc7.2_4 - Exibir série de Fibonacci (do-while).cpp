/*
  Name: Jo�o Luiz Grave Gross
  Exerc�cios de Fixa��o 7.2 - Algoritmos Iterativos e Comando do-while
  Date: 21/03/09 21:02
  Description: Mostrar os termos da s�rie de Fibonacci at� o termo N, inteiro >0 lido de teclado, 
  cuja lei de forma��o de seus termos �: dados os 2 primeiros termos de valor 1 e 1, respectivamente 
  e os demais s�o determinados pela soma dos dois termos imediatamente anteriores. Observe:

  S�rie de Fibonacci: 1 1 2 3 5 8 13 ............ 
num1=1
num2=1
soma=2

soma=3
num1=num2
num2=soma

*/

#include<stdlib.h>
#include<stdio.h>

int main ()
{
    int n, num1=1, num2=1, soma, flag=1, flag2=1;
    do 
    {
       printf ("Digite um valor: ");
       scanf ("%i",&n);
       if (n < 0)
          flag2 = 0;
       if (n < 2 && n > 1)
          printf ("1 1 ");   
       do 
       {
          soma = num1 + num2;
          num1 = num2;
          num2 = soma;
          if (soma < n)
             printf ("%d ",soma);
          else
             flag2 = 0;      
       } while (flag2); 
    flag == 1? printf ("\n1 - Reiniciar\n0 - Finalizar\n"):flag=0;
    scanf ("%d",&flag);
    num1=1;
    num2=1;
    soma=0;
    flag2=1;
    } while (flag);
    system ("pause");
    return 0;
}
