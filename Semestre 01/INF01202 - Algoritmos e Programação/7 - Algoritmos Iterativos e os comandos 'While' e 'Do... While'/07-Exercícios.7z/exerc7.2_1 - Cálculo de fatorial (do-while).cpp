/*
  Name: Jo�o Luiz Grave Gross
  Exerc�cios de Fixa��o 7.2 - Algoritmos Iterativos e Comando do-while
  Date: 21/03/09 19:15
  Description: 
               
  Dado o valor de N, inteiro maior ou igual a zero, calcular N!= 1*2*3*...N. 
  Cuidar que a entrada de valores para N seja sempre no intervalo solicitado e 
  no caso de entrada com valores menores que zero enviar mensagem de acordo e 
  solicitar novos valores. 
*/

#include<stdlib.h>
#include<stdio.h>

int main ()
{
    int number, number_fat=1, flag=1, i=0;
    printf ("Digite um numero inteiro maior ou igual a zero: ");
    scanf ("%d",&number);      
    do
    {
       do 
       {                
          i = ++i;      //primeiro incrementa i e depois atribui i+1 para i 
          number_fat *= i;
          if (number == 0)
          {
             number_fat = number;
             i = number;
          }
       } while (i < number);
       flag=0;
       if (number >= 0)
       {
          printf ("Fatorial de %d = %d\n\n",number, number_fat);
          flag = 0;
       } 
       else
          printf ("Numero menor que zero.\nTente novamente.\n\n");   
    } while (flag);
    system("pause");
    return 0;
}

