/*
  Name: Jo�o Luiz Grave Gross
  Exerc�cio de Avalia��o 5.7
  Matr�cula: 180171
  Disciplina de Algoritmos e Programa��o - Turma H
  Date: 21/03/09 21:33
  Description: 
               
  Construir um programa que auxilie o trabalho de um caixa, em uma casa de c�mbio. 
  Este estabelecimento troca reais por d�lares (venda), d�lares por reais (compra), reais por euros 
  (venda) e euros por reais (compra), conforme tabela abaixo. S�o informados para o programa, o tipo 
  de opera��o e o valor da opera��o. O programa deve calcular o valor da convers�o, bem como a quantidade 
  de c�dulas que o caixa deve fornecer ao cliente (os centavos s�o desprezados).
  
  Considerar que o n�mero de convers�es solicitadas, a cada execu��o do programa, ser� indeterminado, e 
  maior ou igual a 1 (um).
  
   C�digo da opera��o       Opera��o                           Taxa

   1                        Trocar reais por d�lares (venda)   R$1,75/US$
   2                        Trocar d�lares por reais (compra)  R$1,72/US$
   3                        Trocar reais por euros (venda)     R$3,10/EU$       
   4                        Trocar euros por reais (compra)    R$3,02/EU$ 
   
   Observar que a tabela que segue mostra que moedas e c�dulas est�o dispon�veis no caixa da Loja de C�mbio.

   Moeda                 C�dulas dispon�veis no caixa
   D�lares (US$)         100,00 / 20,00 / 10,00 / 5,00 / 2,00 / 1,00
   Euros (EU$)           50,00 / 10,00 / 5,00 / 2,00 / 1,00
   Reais (R$)            100,00 / 50,00 / 20,00 / 10,00 / 5,00 / 2,00 / 1,00

   O programa deve calcular o n�mero m�nimo de c�dulas para a opera��o
*/
#include<stdlib.h>
#include<stdio.h>

int main ()
{
    int cod, quant_cedulas, flag=1, trocas;
    float reais, euros, dolares;
    do
    {
        do 
        {  
            printf ("Escolha uma operacao:\n1 - Trocar reais por dolares\n2 - Trocar dolares por reais\n");
            printf ("3 - Trocar reais por euros\n4 - Trocar euros por reais\nCodigo: ");
            scanf ("%d",&cod);
            if (cod < 1 || cod > 4)
               printf ("\nAVISO: Codigo invalido!\n\n");
        } while (cod < 1 || cod > 4);
        do
        {
           printf ("Quantidade de trocas: ");
           scanf ("%d",&trocas);
           if (trocas < 1)
              printf ("AVISO: A quantidade de trocas deve ser igual ou superior a 1\n");
        } while (trocas < 1);
        while (trocas >= 1)
        {
            switch (cod)
            {
               case 1:  
                        printf ("\n(%d trocas restantes) Valor da troca em reais: ", trocas);
                        scanf ("%f",&reais);
                        dolares = reais / 1.75;
                        printf ("Valor em dolares: %.2f\n",dolares);
                        //100
                        quant_cedulas = dolares / 100;
                        printf ("\nValor da cedula\tNumero de cedulas\n");
                        printf ("100\t\t%d\n",quant_cedulas);
                        //20
                        dolares = dolares - quant_cedulas*100;
                        quant_cedulas = dolares / 20;
                        printf ("20\t\t%d\n",quant_cedulas);  
                        //10
                        dolares = dolares - quant_cedulas*20;
                        quant_cedulas = dolares / 10;
                        printf ("10\t\t%d\n",quant_cedulas);  
                        //5                    
                        dolares = dolares - quant_cedulas*10;
                        quant_cedulas = dolares / 5;
                        printf ("5\t\t%d\n",quant_cedulas);  
                        //2
                        dolares = dolares - quant_cedulas*5;
                        quant_cedulas = dolares / 2;
                        printf ("2\t\t%d\n",quant_cedulas);  
                        //1
                        dolares = dolares - quant_cedulas*2;
                        quant_cedulas = dolares / 1;
                        printf ("1\t\t%d\n",quant_cedulas);  
                        break;
              
               case 2:  printf ("\n(%d trocas restantes) Valor da troca em dolares: ", trocas);
                        scanf ("%f",&dolares);
                        reais = dolares * 1.72;
                        printf ("Valor em reais: %.2f\n",reais);
                        //100
                        quant_cedulas = reais / 100;
                        printf ("\nValor da cedula\tNumero de cedulas\n");
                        printf ("100\t\t%d\n",quant_cedulas);
                        //50
                        reais = reais - quant_cedulas*100;
                        quant_cedulas = reais / 50;
                        printf ("50\t\t%d\n",quant_cedulas);  
                        //20
                        reais = reais - quant_cedulas*50;
                        quant_cedulas = reais / 20;
                        printf ("20\t\t%d\n",quant_cedulas); 
                        //10                    
                        reais = reais - quant_cedulas*20;
                        quant_cedulas = reais / 10;
                        printf ("10\t\t%d\n",quant_cedulas); 
                        //5
                        reais = reais - quant_cedulas*10;
                        quant_cedulas = reais / 5;
                        printf ("5\t\t%d\n",quant_cedulas); 
                        //2
                        reais = reais - quant_cedulas*5;
                        quant_cedulas = reais / 2;
                        printf ("2\t\t%d\n",quant_cedulas); 
                        //1
                        reais = reais - quant_cedulas*2;
                        quant_cedulas = reais;
                        printf ("1\t\t%d\n",quant_cedulas); 
                        break;
    
               case 3:  printf ("\n(%d trocas restantes) Valor da troca em reais: ", trocas);
                        scanf ("%f",&reais);
                        euros = reais / 3.1;
                        printf ("Valor em euros: %.2f\n",euros);
                        //50
                        quant_cedulas = euros / 50;
                        printf ("\nValor da cedula\tNumero de cedulas\n");
                        printf ("50\t\t%d\n",quant_cedulas);
                        //10
                        euros = euros - quant_cedulas*50;
                        quant_cedulas = euros / 10;
                        printf ("10\t\t%d\n",quant_cedulas);  
                        //2
                        euros = euros - quant_cedulas*10;
                        quant_cedulas = euros / 2;
                        printf ("2\t\t%d\n",quant_cedulas);  
                        //1                   
                        euros = euros - quant_cedulas*2;
                        quant_cedulas = euros;
                        printf ("1\t\t%d\n",quant_cedulas);  
                        break;
                 
               case 4:  printf ("\n(%d trocas restantes) Valor da troca em euros: ", trocas);
                        scanf ("%f",&euros);
                        reais = euros * 3.02;
                        printf ("Valor em reais: %.2f\n",reais);
                        //100
                        quant_cedulas = reais / 100;
                        printf ("\nValor da cedula\tNumero de cedulas\n");
                        printf ("100\t\t%d\n",quant_cedulas);
                        //50
                        reais = reais - quant_cedulas*100;
                        quant_cedulas = reais / 50;
                        printf ("50\t\t%d\n",quant_cedulas);  
                        //20
                        reais = reais - quant_cedulas*50;
                        quant_cedulas = reais / 20;
                        printf ("20\t\t%d\n",quant_cedulas); 
                        //10                    
                        reais = reais - quant_cedulas*20;
                        quant_cedulas = reais / 10;
                        printf ("10\t\t%d\n",quant_cedulas); 
                        //5
                        reais = reais - quant_cedulas*10;
                        quant_cedulas = reais / 5;
                        printf ("5\t\t%d\n",quant_cedulas); 
                        //2
                        reais = reais - quant_cedulas*5;
                        quant_cedulas = reais / 2;
                        printf ("2\t\t%d\n",quant_cedulas); 
                        //1
                        reais = reais - quant_cedulas*2;
                        quant_cedulas = reais;
                        printf ("1\t\t%d\n",quant_cedulas); 
                        break;
            }
            trocas--;
        }
        printf ("\n\n1 - Trocar de Operacao\t0 - Encerrar Trocas\nCodigo: ");
        scanf ("%d",&flag); 
        printf ("\n");
    } while (flag);
    system ("pause");
    return 0;
}




















