/*
  Name: Jo�o Luiz Grave Gross
  Exerc�cio de Fixa��o 7.1
  Date: 21/03/09 17:36
  Description: Fazer um programa em C, representando o algoritmo de solu��o 
  atrav�s de um fluxograma para o seguinte enunciado: um programa deve ler  
  3 valores para as vari�veis de identificadores A , B , C, assumindo-se que 
  eles ser�o , nesta ordem, os coeficientes dos termos x2 , x1 e x0 de uma fun��o 
  do segundo grau. Determinar as ra�zes reais da fun��o dado os valores A , B , 
  C e avisar quando estes valores determinarem ra�zes complexas. Cuidar que os 
  valores A , B , e C determinem de fato uma fun��o do segundo grau (por exemplo: 
  A=0).
  
  Resumo:
  A, B, C -> valores reais
  A != 0
  Calcular as ra�zes reais
  Avisar quando houver raiz complexa
*/

#include<stdlib.h>
#include<stdio.h>
#include<math.h>

int main ()
{
    float a, b, c, raiz1, raiz2, flag=1;
    printf ("Digite os coeficientes da equa��o de segundo grau: ");
    scanf ("%f%f%f",&a,&b,&c);
    if (a == 0)
    {    
       flag = 0;
       printf ("O coeficiente de x2 deve ser diferente de zero\n\n.");
    }
    if ((b*b-4*a*c) < 0)
    {    
       flag = 0;
       printf ("Raizes complexas.\n\n");
    }
    while (flag)
    {
          raiz1=(-b+sqrt(b*b-4*a*c))/(2*a);
          raiz2=(-b-sqrt(b*b-4*a*c))/(2*a);
          printf ("Raiz1: %.2f\nRaiz2: %.2f\n\n",raiz1,raiz2);
          flag = 0;
    }
    system ("pause");
    return 0;
}
