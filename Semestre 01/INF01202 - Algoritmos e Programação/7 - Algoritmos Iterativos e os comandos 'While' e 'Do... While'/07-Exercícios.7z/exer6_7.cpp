/*
  Name: Jo�o Luiz Grave Gross
  Date: 21/03/09 23:08
  Matr�cula: 180171
  Disciplina de Algoritmos e Programa��o - Turma H
  Description: 
               
  Fazer um programa em C que calcule os valores das s�ries S1 e da S2 a seguir, para uma aproxima��o de 
  N termos. O valor N, inteiro, deve ser lido e necessariamente maior que zero. Caso N<=0, deve ser solicitado 
  um novo valor. Cuidar que as entradas e sa�das sejam bem identificadas pelo usu�rio atrav�s de mensagens 
  esclarecedoras.

  S1 = 1!+ 2!/3 - 3!/6 + 4!/9 - 5!/12 + 6!/15 - ...........
  S2 = 1!/67 - 2!/64 + 3!/61 - 4!/58 + 5!/55 - ........

  Todos os resultados n�o inteiros devem ser apresentados com tres (3) casas decimais.
  Aten��o:

  O programa deve ser gravado como exer6_7.
  Gravar o c�digo-fonte do programa em um arquivo .zip, cujo nome deve ter o seguinte formato: 
  seusobresome_nroidentificacao na UFRGS. Por exemplo: brummer_200688. 
*/

#include<stdlib.h>
#include<stdio.h>

int main ()
{
    int n, i=1, denominador=3, n_fat=1;
    float soma=1, s1, s2;
    do
    {
       do
       {
         printf ("Digite um valor inteiro maior que zero: ");
         scanf ("%d",&n);
         if (n <= 0)
            printf ("Valor negativo ou igual a zero.\n");
       } while (n <= 0);
          
       //S1 = 1!+ 2!/3 - 3!/6 + 4!/9 - 5!/12 + 6!/15 - ...........
       printf ("\nS1 = %d!/%d +", i, (denominador-2));
       while (i < n)
       {    
            //printf ("\n(%d) soma = %f, n_fat = %d, denominador = %d", i, soma, n_fat, ((i-1)*denominador));
            i++;  
            n_fat *= i;       
            if (i % 2)
            {
               //i = �mpar
               printf (" %d!/%d +", i, ((i-1)*denominador));
               soma -= (float)n_fat / ((i-1)*denominador);   
            }
            else
            {
               //i = par
               printf (" %d!/%d -", i, ((i-1)*denominador));         
               soma += (float)n_fat / ((i-1)*denominador);
            }
       }
          
       //S2 = 1!/67 - 2!/64 + 3!/61 - 4!/58 + 5!/55 - ........
       printf ("\b= %.3f\n", soma);         //exibe resultado de s1
       i = 1;                                 //resete de vari�vies
       n_fat = 1;                             //resete de vari�vies
       soma = 0;                              //resete de vari�vies
       denominador = 67;                      //resete de vari�vies
       printf ("\nS2 = %d!/%d -", i, denominador);
       soma += (float)n_fat / denominador; 
       
       while (i < n)
       {   
            i++;  
            n_fat *= i;  
            denominador -= 3;            
            if (i % 2)
            {
               //i = �mpar
               printf (" %d!/%d -", i, denominador);
               soma += (float)n_fat / denominador;   
            }
            else
            {
               //i = par
               printf (" %d!/%d +", i, denominador);         
               soma -= (float)n_fat / denominador;
            }
       } 
       
       printf ("\b= %.3f\n\n", soma);         //exibe resultado de s2
       i = 1;                                 //resete de vari�vies
       n_fat = 1;                             //resete de vari�vies
       soma = 1;                              //resete de vari�vies
       denominador = 3;                      //resete de vari�vies
          
       printf ("Nova operacao?\n1-sim\t0-nao\nCodigo: ");
       scanf ("%d",&n);
       printf ("\n");
    } while (n);
    system ("pause");
    return 0;
}
