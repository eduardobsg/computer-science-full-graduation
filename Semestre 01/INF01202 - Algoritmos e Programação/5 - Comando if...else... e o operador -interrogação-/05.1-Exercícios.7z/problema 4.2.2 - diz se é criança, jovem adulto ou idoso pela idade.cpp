/*
  Name: Jo�o Luiz Grave Gross
  Copyright: 
  Author: 
  Date: 15/03/09 15:44
  Description: Recebida uma idade, fornecer uma das seguintes mensagens:
  Eh crian�a : <= 13
  Eh jovem: > 13 e <= 21
  Eh adulto: > 21 e <= 70
  Eh idoso: > 70.

*/

#include<stdlib.h>
#include<stdio.h>

int main ()
{
    int idade;
    printf ("Digite a nota: ");
    scanf ("%d",&idade);
    if (idade<=13)
       printf ("Eh crianca\n");
    if (idade>13 && idade<=21)
       printf ("Eh jovem\n");
    if (idade>21 && idade<=70)
       printf ("Eh adulto\n");
    if (idade>70)
       printf ("Eh idoso\n");
    system ("pause");
    return 0;
}
