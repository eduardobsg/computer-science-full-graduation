/*
  Disciplina de Algoritmos de Programa��o (INF01202) - Turma H
  Aluno: Jo�o Luiz Grave Gross 	
  Matr�cula: 180171
  Atividade: Exerc�cio de Avalia��o 3.5.1
  Date: 15/03/09 16:30
  Description: Apresentar um fluxograma que represente um algoritmo para um problema de convers�o de temperaturas 
  e o respectivo programa em C, conforme segue. Determinar a convers�o de valores de temperaturas entre as 3 escalas 
  mais conhecidas, C=cent�grados, F= fahrenheit, K= kelvin. O programa recebe como entradas: 

  1. Um caractere indicando a escala fornecida, i.e., {C, K, F} que representam, respectivamente, as escalas Celsius, 
  Kelvin e Fahrenheit; 
  2. A temperatura ( valor num�rico fracion�rio) na escala fornecida; e 
  3. Um caractere indicando a escala para a qual a temperatura fornecida dever� ser convertida, ou seja, podendo ser 
  um dos valores do conjunto {C , K , F}. 

  Para realizar a convers�o, s�o fornecidas as seguintes rela��es: 
  9 * tc = 5 * ( tf - 32 ) e tk = tc + 273, onde: 
  tc = temperatura Celsius
  tf = temperatura Fahrenheit 
  tk = temperatura Kelvin 
  
  As entradas de dados devem ser realizadas pelas vari�veis: esc, temp e esconv. Tanto esc como esconv somente podem 
  ter os valores {C, K, F}, pois representam os dados relativos �s escalas termom�tricas. Cuidado com valores inferiores 
  ao zero absoluto. Caso os dados de entrada estejam fora dos padr�es, exibir mensagem adequada e terminar o processamento. 
  
  Celsius:
  tc = tk-273;
  tc = 5*(tf-32)/9        

  Kelvin:
  tk = tc + 273
  tk = 5*(tf-32)/9 + 273 

  Fahrenheit:
  tf = (9*tc/5)+32
  tf = (9*(tk-273)/5)+32           
  
*/

#include<stdlib.h>
#include<stdio.h>

int main ()
{
    char esc[0], esconv[0];
    float temp;
    //Captura valor de temperatura
    printf ("Digite a temperatura (maior que -459.4): ");
    scanf ("%f",&temp);
    //Captura escala
    printf ("Digite a escala da temperatura (K - Kelvin, F - Fahenrit, C - Celsius): ");
    scanf ("%s",&esc);
    //Captura escala de convers�o
    printf ("Digite qual a escala para conversao (K - Kelvin, F - Fahenrit, C - Celsius): ");
    scanf ("%s",&esconv);  
    if (esc[0]=='K')
    {
       if (temp<0)              //zero absoluto para K
          printf ("Temperatura abaixo do minimo. Tente novamente\n\n");
       else 
       {
          if (esconv[0]=='K')
             printf ("Mesma escala. Temperatura: %.2f K\n\n",temp);
          if (esconv[0]=='C')
          {  
             temp = temp-273;
             printf ("\nConversao de Kelvin para Celsius.\nTemperatura: %.2f graus C\n\n",temp);
          }   
          if (esconv[0]=='F')
          {
             temp = (9*(temp-273)/5)+32;  
             printf ("\nConversao de Kelvin para Fahrenheit.\nTemperatura: %.2f graus F\n\n",temp);
          }
       }
    }
    if (esc[0]=='C')
    {
       if(temp<-273)           //zero absoluto para C
          printf ("Temperatura abaixo do minimo. Tente novamente\n\n");
       else
       {
          if (esconv[0]=='C')
             printf ("Mesma escala. Temperatura: %.2f graus C\n\n",temp);
          if (esconv[0]=='K')
          {  
             temp = temp + 273;
             printf ("\nConversao de Celsius para Kelvin.\nTemperatura: %.2f K\n\n",temp);
          }   
          if (esconv[0]=='F')
          {
             temp = (9*temp/5)+32;    
             printf ("\nConversao de Celsius para Fahrenheit.\nTemperatura: %.2f graus F\n\n",temp);
          }
       }
    }
    if (esc[0]=='F')
    {
       if(temp<-459.4)         //zero absoluto para F
          printf ("Temperatura abaixo do minimo. Tente novamente\n");
       else
       {
          if (esconv[0]=='F')
             printf ("Mesma escala. Temperatura: %.2f graus F",temp);
          if (esconv[0]=='K')
          {  
             temp = 5*(temp-32)/9 + 273; 
             printf ("\nConversao de Fahrenheit para Kelvin.\nTemperatura: %.2f K\n\n",temp);
          }   
          if (esconv[0]=='C')
          {
             temp = 5*(temp-32)/9;    
             printf ("\nConversao de Fahrenheit para Celsius.\nTemperatura: %.2f graus C\n\n",temp);
          }   
       }
    }     
    system ("pause");
    return 0;
}
