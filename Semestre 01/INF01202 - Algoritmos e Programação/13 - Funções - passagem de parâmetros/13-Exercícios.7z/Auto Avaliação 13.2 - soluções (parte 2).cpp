/*
  Name: autoavaliacao132 - parte 2
  Autora: Maria Aparecida C. Livi
  Data: 03/05/08 
  Descricao: Por solicitacao do usuario, ate que ele informe que deseja parar, 
             executa uma das seguintes funcoes: 
             1) fazer uma fun��o que calcule o numero de 
                arranjos de m elementos p a p.
             2) fazer uma funcao que calcule o numero de 
                combinacoes de m elementos p a p.
            3) fazer uma funcao para calcular o indice de massa corporal 
                de uma pessoa. Usar a formula: 
                                                  peso
                                      indice = ----------
                                                 altura2
                Faixas:  ate 18,5 (inclusive) -  abaixo do peso normal; 
                acima de 18,5 ate 25 (inclusive) - peso normal; 
                acima de  25  ate 30 (inclusive) - peso acima do normal; 
                acima de 30  -   peso excessivo. 
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define ALTURAMINIMA 1.4
#define PESOMINIMO 37
int fatorial (int);
int arranjos(int,  int);
int combinacoes(int, int);
float calculaimc (float, float);
void menu (void);
int main (  )
 {
   int  valor, m, p;
   float peso, altura, imc;
   char opcao;
   //Para auxiliar no calculo do numero de arranjos e do numero de combinacaoes 
   //foi desenvolvida uma funcao fatorial
   do
    {
      menu( );
      do
       {
         scanf("%d", &opcao);
         if (opcao < 1 || opcao > 4)
             printf("\nValor deve ser entre 1 e 4!");
       }
      while (opcao < 1 || opcao > 4);
      switch (opcao)
       {
         case 1:
         case 2:  do
                   {
                    printf("\nForneca o numero de elementos: "); 
                    scanf("%d", &m); 
                    if (m < 1)
                       printf("\nO numero de elementos deve ser maior que zero!\n");
                   }
                  while (m < 1);  
                  do
                   {
                    printf("\nForneca o valor para p: "); 
                    scanf("%d", &p); 
                    if (p < 1)
                        printf("\nP deve ser maior que zero!\n");
                   }
                  while(p < 1);  
                  if (opcao == 1)
                     { 
                       //Tarefa 1: calcular o numero de arranjos de m p a p
                       if (m < p)
                          printf("\nNumero de arranjos de %d elementos %d a %d eh 0 \n", m, p, p);
                       else
                          printf("\nNumero de arranjos de %d elementos %d a %d eh: %d \n",
                                             m, p, p, arranjos(m,p)); 
                     }
                  if (opcao == 2)  
                     {                                                 
                       //Tarefa 2: calcular o numero de combinacoes de m p a p
                       if (m < p)
                           printf("\nNumero de combinacoes de %d elementos %d a %d eh 0 \n", m, p, p);
                       else
                           printf("\nNumero de combinacoes de %d elementos %d a %d eh: %d \n",
                                   m, p, p, combinacoes(m,p));   
                     } 
                  break;
         case 3:                      
                  //Tarefa e: calcular o indice de massa corporal de uma pessoa
                  do
                   {
                     printf("\nForneca o peso da pessoa: "); 
                     scanf("%f", &peso); 
                     if (peso < PESOMINIMO)
                        printf("\nPeso deve ser maior que %6.2f!\n", PESOMINIMO);
                   }
                  while (peso < PESOMINIMO); 
                  do
                   {
                     printf("\nForneca a altura da pessoa: "); 
                     scanf("%f", &altura); 
                     if (altura <= ALTURAMINIMA)
                        printf("\nAltura deve ser maior que %6.2f!\n", ALTURAMINIMA);
                   }
                  while (peso < ALTURAMINIMA);   
                  imc = calculaimc (peso , altura);
                  if (imc > 30.0)
                      printf("\nIMC = %6.2f - peso excessivo\n", imc);
                  else 
                      if (imc > 25.0)    
                          printf("\nIMC = %6.2f - peso acima do normal\n", imc);
                      else    
                          if (imc > 18.5)
                              printf("\nIMC = %6.2f - peso normal\n", imc);
                          else
                              printf("\nIMC = %6.2f - peso abaixo do normal\n", imc); 
                 break;
       }           
    }
   while (opcao != 4);                            
   system ("pause");
   return 0;      
 }
 
int fatorial (int valor)
  {
  int fat, i;  
  fat = 1;
  for (i = 2; i <= valor; i++)
      fat *=i;  
  return fat;    
  }
  
int arranjos (int m, int p)
  {
  return (fatorial(m)/(fatorial(m-p)));  
  }
  
int combinacoes (int m, int p)
  {
  return (fatorial(m)/(fatorial(p)*(fatorial(m-p))));  
  }
  
float calculaimc (float peso , float altura)
  {
  return peso/(altura * altura);    
  }
  
void menu (void)
  {
   printf("\nO que deseja fazer a seguir?\n");   
   printf("\n1 - calcular o numero de arranjos de m elementos p a p"); 
   printf("\n2 - calcular o numero de combinacoes de m elementos p a p");
   printf("\n3 - calcular o indice de massa corporal");
   printf("\n4 - parar\n");   
  }
