/*
  Name: exer13_1 - escrita de valor por extenso, mmc, mdc, teste primo
  Author: Jo�o Luiz Grave Gross
  Date: 01/05/09 18:42
  Description: Exerc�cio de avalia��o - enunciado

    Fazer um programa que realize as quatro tarefas indicadas a seguir, na ordem 
    em que o usu�rio desejar e tantas vezes quantas ele queira.
    
    As quatro tarefas s�o:
    
    - verificar se um dado valor inteiro positivo e maior que 1 (um) � primo;
    
    - imprimir por extenso o valor de qualquer n�mero inteiro com at� 12 casas;
    
    - converter para segundos um hor�rio fornecido em horas, minutos e segundos;
    
    - dados 2 inteiros quaisquers mostrar o MMC e o MDC entre os 2.
    
    O programa dever� conter no m�nimo 6 (seis) fun��es:
    
    - a fun��o main;
    
    -uma fun��o que apresente o menu de op��es (sem retorno e sem par�metros); e
    
    -mais quatro fun��es, uma para realizar cada uma das tarefas (com par�metros 
    e com retorno).
    
    As verifica��es de corre��es dos dados dever�o ser realizadas na fun��o main, 
    devendo as fun��es que realizam as tarefas receber apenas dados corretos.
    
    � obrigat�rio o uso de prot�tipos para as fun��es.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void menu (void);
int verificaprimo (double);
void escreveextensao (int);
void centenas (int);
void dezena (int);
void dezena10 (int);
void unidades (int);
void e (void);
void escreveextensao (double);
int convertesegundo (int, int, int);
int mdc (int, int);
int mmc (int, int);
int nprimos (int);

int main ()
{
    int opcao, hora, minuto, segundo, x1, x2;
    double valor, min = -(pow (10, 12) - 1), max = (pow (10, 12) - 1), primo; 
    do 
    {
        menu ();
        do
        {
            scanf ("%d", &opcao);
            if (opcao < 1 || opcao > 6)
            {
               printf ("Codigo invalido!\n");
               printf ("Codigo: ");
            }
        } while (opcao < 1 || opcao > 6);
        switch (opcao)
        {
            case 1:   do
                      {
                          printf ("\nInsira um valor maior que 1 e menor que %.e: ", max);
                          scanf ("%lf", &primo);
                          if (primo < 2 || primo > max)
                             printf ("Valor invalido! (de 2 a %.e)", max);
                      } while (primo < 2 || primo > max);
                      if (verificaprimo (primo))
                         printf ("O numero %.0lf eh primo\n", primo);
                      else 
                         printf ("O numero %.0lf nao eh primo\n", primo); 
                      break; 
            case 2:   do
                      {
                          printf ("\nInsira um valor: ");
                          scanf ("%lf", &valor);       
                          if (valor < min || valor > max)
                             printf ("\nValor fora dos limites (de -999 999 999 999 a 999 999 999 999)");
                      } while (valor < min || valor > max);
                      escreveextensao (valor);
                      break;
            case 3:   do
                      {
                          printf ("\nInsira um horario\nHora: ");
                          scanf ("%d", &hora);  
                          if (hora < 0 || hora > 23)
                             printf ("Hora invalida! (de 0 a 23)\n");
                          else
                          {
                             printf ("Minuto: ");
                             scanf ("%d", &minuto);
                             if (minuto < 0 || minuto > 59)
                                printf ("Minuto invalido! (de 0 a 59)\n");
                             else
                             {
                                printf ("Segundo: ");
                                scanf ("%d", &segundo);   
                                if (segundo < 0 || segundo > 59)
                                   printf ("Segundo invalido! (de 0 a 59)\n");  
                             }
                          }
                      } while (hora < 0 || hora > 23 || minuto < 0 || minuto > 59 || segundo < 0 || segundo > 59);
                      printf ("O horario %d horas, %d minutos e %d segundos equivale a %d segundos", hora, minuto, segundo, convertesegundo (hora, minuto, segundo));
                      break;
                      
            case 4:   do
                      {
                          printf ("\nPrimeiro valor: ");
                          scanf ("%d", &x1);       
                          if (x1 < min || x1 > max)
                             printf ("\nValor fora dos limites (de -999 999 999 999 a 999 999 999 999)");
                          else
                             printf ("Segundo valor: ");
                             scanf ("%d", &x2);       
                                   if (x2 < min || x2 > max)
                                      printf ("\nValor fora dos limites (de -999 999 999 999 a 999 999 999 999)"); 
                      } while (x1 < min || x1 > max || x2 < min || x2 > max);
                      if (x1 == 0 || x2 == 0)
                      {
                         printf ("\nMDC entre %d e %d eh 0", x1, x2);
                         printf ("\nMMC entre %d e %d eh 0", x1, x2); 
                      }
                      else
                      {
                         printf ("\nMDC entre %d e %d eh %d", x1, x2, mdc(x1, x2));
                         printf ("\nMMC entre %d e %d eh %d", x1, x2, mmc(x1, x2)); 
                      }
                      break;
                                            
            case 5:   do
                      {
                          printf ("\nInsira a quantidade de pirmos que deseja imprimir: ");
                          scanf ("%lf", &primo);
                          if (primo < 1 || primo > 5000)
                             printf ("Valor invalido! (de 1 a 5000)");
                      } while (primo < 1 || primo > 5000);
                      nprimos (primo);     
                      break;                         
                                            
            case 6:   printf ("\nFim do programa...");            
        }
        printf ("\n\n");   
    } while (opcao != 6);
    
    system ("pause");
    return 0;
}

void menu (void)
{
   printf ("O que deseja fazer a seguir?");   
   printf ("\n1 - verificar se um dado valor eh primo"); 
   printf ("\n2 - imprimir por extenso de um numero inteiro com ate 12 digitos");
   printf ("\n3 - converter para segundos um horario fornecido em horas, minutos e segundos");
   printf ("\n4 - mostrar o MMC e o MDC entre os 2");   
   printf ("\n5 - imprimir n numeros primos");
   printf ("\n6 - parar");  
   printf ("\nCodigo: ");
}

int verificaprimo (double primo)
{
    int i, cod_primo;
    double div, result;
        
    for (i = 0, div = 1; div <= primo; div++)       
    {
       result = primo / div;                    
       if (primo == (result * div))             
       {
          i++;
          if (i > 2)
          {
             div = primo + 1;
             cod_primo = 0;
          }    
          else       
             if (div == primo)                        
             {
                cod_primo = 1;     
                div = primo + 1;
             }
       }
    } 
    return cod_primo;
} 

void centenas (int n)
{
     switch (n)
     {
            case 1: printf ("Cento");
                    break;
            case 2: printf ("Duzentos"); 
                    break;                       
            case 3: printf ("Trezentos");            
                    break;                    
            case 4: printf ("Quatrocentos");
                    break;                                    
            case 5: printf ("Quinhentos");            
                    break;
            case 6: printf ("Seiscentos");            
                    break;
            case 7: printf ("Setecentos");            
                    break;
            case 8: printf ("Oitocentos");                                                            
                    break;
            case 9: printf ("Novecentos");
                    break;
     }
}

void dezenas (int n)
{
     switch (n)
     {
            case 2: printf ("Vinte"); 
                    break;           
            case 3: printf ("Trinta");            
                    break;
            case 4: printf ("Quarenta");                                    
                    break;
            case 5: printf ("Cinquenta");            
                    break;
            case 6: printf ("Sessenta");            
                    break;
            case 7: printf ("Setenta");            
                    break;
            case 8: printf ("Oitenta");                                                            
                    break;
            case 9: printf ("Noventa");
                    break;
     }
}

void dezena10 (int n)
{
     switch (n)
     {
            case 1: printf ("Dez");
                    break;
            case 2: printf ("Onze");            
                    break;
            case 3: printf ("Doze");            
                    break;
            case 4: printf ("Treze");                                    
                    break;
            case 5: printf ("Quatorze");            
                    break;
            case 6: printf ("Quinze");            
                    break;
            case 7: printf ("Dezeseis");            
                    break;
            case 8: printf ("Dezessete");                                                            
                    break;
            case 9: printf ("Dezoito");
                    break;
            case 10: printf ("Dezenove");
                    break;
     }
}

void unidades (int n)
{
     switch (n)
     {
            case 1: printf ("Um");
                    break;
            case 2: printf ("Dois");            
                    break;
            case 3: printf ("Tres");            
                    break;
            case 4: printf ("Quatro");                                    
                    break;
            case 5: printf ("Cinco");            
                    break;
            case 6: printf ("Seis");            
                    break;
            case 7: printf ("Sete");            
                    break;
            case 8: printf ("Oito");                                                            
                    break;
            case 9: printf ("Nove");
                    break;
     }
}

void e (void)
{
     printf (" e ");
}

void escreveextensao (double valor)
{
     int aux, transforma_int, transforma_int2, x1, x2, x3, flag = 0, j, k;
     double div = pow (10, 11); //100 000 000 000
     
     printf ("O valor %.0lf por extensao eh:\n", valor);
     if (valor == 0)
        printf ("Zero");
     if (valor < 0)
     {
        printf ("Menos ");
        valor = valor * -1;
     }
     for (k = 0; k < 4; k++)
     {
         for (j = 0; j < 3; j++)
         {
             aux = valor / div;    
             valor = valor - aux * div;
             div = div / 10;
             if (j == 1 && aux == 1)
             {
                 j = 3;  
                 x2 = valor / div;
                 aux = aux + x2;
                 valor = valor - x2 * div;
                 div = div / 10;
                 dezena10 (aux);
             }            
             else   
                 switch (j)
                 {
                        case 0: transforma_int = valor / div;
                                transforma_int2 = valor / (div / 10);
                                if (aux == 1 && transforma_int == 0 && transforma_int2 == 0)
                                   printf ("Cem");
                                else   
                                   centenas (aux);
                                if ((transforma_int != 0 || transforma_int2 != 0) && aux != 0)
                                   e ();
                                x1 = aux;
                                break;
                        case 1: transforma_int = valor / div;
                                dezenas (aux);
                                if (transforma_int != 0 && aux != 0)
                                   e ();                                
                                x2 = aux;
                                break;
                        case 2: if (aux == 1 && x1 == 0 && x2 == 0)
                                   flag = 1;
                                unidades (aux);  
                                x3 = aux;                            
                                break;    
                 }
         }
         switch (k)
         {     
             case 0: if (x1 != 0 || x2 != 0 || x3 != 0)
                     {                 
                         if (flag)
                            printf (" Bilhao");
                         else   
                            printf (" Bilhoes");
                         if (valor != 0)
                            e ();         
                     }
                     flag = 0;
                     break;
             case 1: if (x1 != 0 || x2 != 0 || x3 != 0)
                     {                 
                         if (flag)
                            printf (" Milhao");
                         else   
                            printf (" Milhoes");
                         if (valor != 0)
                            e ();         
                     }                            
                     flag = 0;
                     break;
             case 2: if (x1 != 0 || x2 != 0 || x3 != 0)
                     {                 
                         printf (" Mil");
                         if (valor != 0)
                            e ();         
                     }                
                     break;  
         } 
     }        
}

int convertesegundo (int hora, int minuto, int segundo)
{
    int conversao;
    conversao = segundo + minuto * 60 + hora * 3600;
    return conversao;    
}

int mdc (int n1, int n2)
{
    int mdc, aux1, aux2, div;
    if (n1 > n2)
    {                                   
       aux1 = n1 % n2;                     
       mdc = n2;                          
    }
    if (n2 > n1)
    {
       aux1 = n2 % n1;                    
       mdc = n1;                          
    }
    if (n1 == n2)
    {  
       mdc = n1;
       aux1 = 0;
    }
    while (aux1 != 0)
    {
       aux2 = mdc % aux1;                
       mdc = aux1;                       
       aux1 = aux2;                                    
    }
    return mdc;
}

int mmc (int n1, int n2)
{
    int x1, x2, mmc, aux1, aux2, div;
    for (div = 2, mmc = 1, x1 = n1, x2 = n2; x1 != 1 || x2 != 1; div++)
    {
        aux1 = x1 / div;
        if (aux1 * div == x1)
           mmc = mmc * div;
        aux2 = x2 / div;
        if ((aux2 * div) == x2)
        {
           x2 = aux2;            
           if (aux1 * div != x1)
           {
              mmc = mmc * div;
              div--;
           }
        }
        if (aux1 * div == x1)
        {
           div--;
           x1 = aux1;
        }
    }
    return mmc;
}

int nprimos (int n)
{   
    int div, resultado, i, num, j;
    for (i = 0, num = 2; i < n; i++)
    {
       for (div = 1, j = 0; div <= num; div++)       
       {
           resultado = num / div;                    
           if (num == (resultado * div))             
           {
              j++;
              if (j > 2)
              {
                 div = num + 1;
                 i--;
                 num++;
              }    
              else       
                 if (div == num)                        
                 {
                    printf ("%d ", num);
                    num++;
                    div = num + 1;
                 }
           }
       } 
    } 
}








