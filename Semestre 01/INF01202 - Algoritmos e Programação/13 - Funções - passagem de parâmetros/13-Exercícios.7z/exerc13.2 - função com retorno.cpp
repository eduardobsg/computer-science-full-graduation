/*
  Name: exerc13.2 - fun��o com retorno 
  Author: Jo�o Luiz Grave Gross
  Date: 01/05/09 15:57
  Description: AUTO AVALIA��O 13.2 - EXERC�CIOS

  Fazer um ou mais programas com as fun��es a seguir. Em todos os casos declarar os prot�tipos 
  das fun��es.

  a) fun��o que recebe dois valores inteiros, o primeiro menor que o segundo, e retorna em seu
  nome o somat�rio dos valores desse intervalo (limites inclu�dos). Ex.: valores recebidos 3 e 9, 
  resultado retornado 42 (soma de 3, 4, 5, 6, 7 , 8 e 9);

  b) fun��o que recebe a idade de uma pessoa e retorna seu ano de nascimento;

  c) anos bissextos ocorrem de quatro em quatro anos. Mas se o ano � m�ltiplo de 100, ele s� ser� 
  bissexto se tamb�m for m�ltiplo de 400. Por exemplo, o ano 1900 n�o foi bissexto, mas o ano 2000 
  foi. Fazer uma fun��o que fornecido um ano, retorne 1 se ele � bissexto e 0 se ele n�o �;

  d) fazer uma fun��o que calcule o n�mero de arranjos de m elementos p a p.

  e) fazer uma fun��o que calcule o n�mero de combina��es de m elementos p a p.

  f) retomar o problema do �ndice da massa corporal (exerc�cio de avalia��o 6.1) e fazer uma fun��o 
  que recebidos um peso e uma altura (ambos float) calcule o IMC.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int somax1ax2 (int, int);
int ano_nascimento (int);
int testa_bissexto (int);
int calc_arranjos (int, int);
double calc_combinacoes (int, int);

int main ()
{
    int x1, x2, soma, idade, ano, bissexto, m, p;
    
    //somat�rio dos termos inteiros no intervalo de x1 a x2
    printf ("Soma dos termos inteiros no intervalo de x1 a x2\n");
    do
    {
        printf ("Digite dois valores (o primeiro menor que o segundo): \n"); 
        scanf ("%d%d", &x1, &x2);
        if (x1 >= x2)
           printf ("Valores invalidos!\n");
    } while (x1 >= x2);
    soma = somax1ax2 (x1, x2);
    printf ("\b\b= %d", soma);
    
    //idade -> ano de nascimento (para pessoas que fizeram anivers�rio em 2009)
    printf ("\n\nDefinicao da data de nascimento a partir da idade\n");
    do
    {
        printf ("Digite sua idade: ");
        scanf ("%d", &idade);
        if (idade > 120)
           printf ("Idade fora das especificacoes!\n");
    } while (idade > 120);
    ano = ano_nascimento (idade);
    printf ("Nascimento no ano %d", ano);
    
    //anos bissextos
    printf ("\n\nVerifica se um ano eh bissexto\n");
    do
    {
        printf ("Digite um ano: ");
        scanf ("%d", &ano);
        if (ano < 0)
           printf ("Ano fora das especificacoes!\n");
    } while (ano < 0);    
    bissexto = testa_bissexto (ano);
    if (bissexto)
       printf ("Ano %d eh bissexto", ano);
    else
       printf ("Ano %d nao eh bissexto", ano);
       
    //n�mero de arranjos de m elementos p a p. Ex.: m = 5, p = 2 -> combina��es de 5 elementos 2 a 2   
    printf ("\n\nCalcula o numero de arranjos dos parametros especificados\n");
    printf ("Numero de elementos: ");
    scanf ("%d", &m);
    printf ("Numero de elementos por agrupamento: ");
    scanf ("%d", &p);
    printf ("Arranjos: %d", calc_arranjos (m, p));   
    
    //n�mero de combina��es de m elementos p a p.
    printf ("\n\nCalcula o numero de combinacoes dos parametros especificados\n");
    printf ("Numero de elementos: ");
    scanf ("%d", &m);
    printf ("Numero de elementos por agrupamento: ");
    scanf ("%d", &p);
    printf ("Combinacoes: %.2lf", calc_combinacoes (m, p)); 
      
    printf ("\n\n");
    system ("pause");
    return 0;
}

//Fun��es

double calc_combinacoes (int m, int p)
{
    double combinacoes;
    if (m < p)
       combinacoes = 0;
    else
       combinacoes = pow (m, p);
    return combinacoes;
}

int calc_arranjos (int m, int p)
{
    //A(m,p) = m!/(m-p)!
    int i, sub, arranjos;
    if (m < p)
       arranjos = 0;
    else
    {      
        sub = m - p;
        for (i = 1, arranjos = 1; i <= m; i++)
            arranjos *= i;
        m = arranjos;
        for (i = 1, arranjos = 1; i <= sub; i++)
            arranjos *= i;    
        sub = arranjos;
        arranjos = m / sub;
    }
    return arranjos;   
}

int somax1ax2 (int x1, int x2)
{
    int soma = 0, i;
    printf ("Soma dos termos inteiros no intervalo de %d a %d: \n", x1, x2);
    for (i = x1; i <= x2; i++)
    {
        soma += i;
        printf ("%d + ", i);
    }
    return soma;    
}

int ano_nascimento (int idade)
{
    int ano;
    ano = 2009 - idade;
    return ano;
}

int testa_bissexto (int ano)
{
    int aux, bissexto;
    aux = ano / 4;
    if (ano == (aux * 4))
    {
       aux = ano / 100;
       if (ano == (aux * 100))
       {
          aux = ano / 400;
          if (ano == (aux * 400))
             bissexto = 1;
          else
             bissexto = 0;        
       }
       else
          bissexto = 1;     
    }
    else
       bissexto = 0; 
    return bissexto;    
}
