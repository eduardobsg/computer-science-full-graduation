/*
  Name: autoavaliacao131
  Autora: Maria Aparecida C. Livi
  Data: 03/05/08 
  Descricao: Fazer um programa com as seguintes funcoes:
               a) funcao que apresenta os multiplos de 5 
               entre 1 e um n (inteiro e positivo) informado;
               b) funcao que recebe as coordenadas 
               de dois pontos no plano cartesiano (valores float) 
               e apresenta a distancia entres esses dois pontos;
               c) funcao que recebe um caractere 
               e o apresenta  50 vezes em uma linha.
               d) mais uma versao da funcao anterior, em que o usuario
               define o tamanho da linha a ser apresentada.
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MAXLINHA 80
void multiplosde5(int);
void distanciaentrepontos(float, float, float, float);
void produzlinha(char);
void produzlinhavariavel(char, int);
int main (  )
 {
   int numero, vezes;
   float x1, x2, y1, y2;
   char caract;
   //Tarefa 1: apresenta multiplos de 5 entre 1 e numero informado
   do
   {
    printf("\nValor limite (inteiro e positivo) para multiplos de 5 : "); 
    scanf("%d", &numero); 
   }
   while (numero < 1); 
   if (numero >=5)
       {
        printf("\nMultiplo(s) de 5 entre 1 e %d eh(sao): \n", numero); 
        multiplosde5(numero); 
       }
   else
       printf("\nEntre 1 e %d nao ha multiplos de 5!\n", numero);  
   //Tarefa 2: recebidas as coordenadas de um ponto no plano, apresenta sua distancia
   printf("\nForneca as coordenadas do primeiro ponto:");
   printf("\nx1 = ");
   scanf("%f", &x1); 
   printf("    y1 = ");
   scanf("%f", &y1);  
   printf("\nForneca as coordenadas do segundo ponto:");
   printf("\nx2 = ");
   scanf("%f", &x2); 
   printf("    y2 = ");
   scanf("%f", &y2);
   distanciaentrepontos(x1 , y1, x2, y2);  
   //Tarefa 3: recebido um caractere, apresenta-o 50 vezes em uma linha
   printf("\nForneca um caractere para produzir a linha:");
   scanf(" %c", &caract);
   produzlinha(caract);
   //Variacao da tarefa 3: recebido um caractere e um valor num�rico inteiro, 
   // entre 1 e um valor previamente definido, apresenta uma linha com esse caractere
   printf("\nForneca um caractere para produzir a linha:");
   scanf(" %c", &caract);
   do
   {
    printf("\nNumero de vezes a apresentar o caractere (entre 1 e %d) : ", MAXLINHA); 
    scanf("%d", &vezes);
    if (vezes < 1 || vezes > MAXLINHA)
       printf("\nNumero entre 1 e %d!\n", MAXLINHA); 
   }
   while (vezes < 1 || vezes > MAXLINHA); 
   produzlinhavariavel(caract, vezes);
   system ("pause");
   return 0;      
 }
 void multiplosde5(int num)
 {
   int i;   
   for (i = 1; i <=num; i++)
       if (!(i % 5)) 
          printf("%5d");
   printf("\n\n");         
  }
void distanciaentrepontos(float coordx1, float coordy1, float coordx2, float coordy2)
{
  printf("\nDistancia entre os pontos");
  printf("x1 = %6.2f  y1 = %6.2f e x2 = %6.2f e y2 = %6.2f \n eh %6.2f\n",
               coordx1, coordy1, coordx2, coordy2,
               sqrt((coordx2 - coordx1)* (coordx2 - coordx1) + (coordy2 - coordy1)* (coordy2 - coordy1)));   
}
void produzlinha(char caractere)
{
  int j;
  printf("\n\n");      
  for (j=1; j <=50; j++)
       printf("%c", caractere);
  printf("\n\n");        
}
void produzlinhavariavel(char caractere2, int vezes)
{
  int j;  
  printf("\n\n"); 
  for (j=1; j <=vezes; j++)
       printf("%c", caractere2);
  printf("\n\n");        
}
