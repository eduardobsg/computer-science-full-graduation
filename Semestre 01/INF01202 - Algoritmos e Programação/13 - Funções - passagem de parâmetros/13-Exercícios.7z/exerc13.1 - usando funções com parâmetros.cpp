/*
  Name: exerc13.1 - usando fun��es com par�metros 
  Author: Jo�o Luiz Grave Gross
  Date: 01/05/09 15:01
  Description: Fazer um programa com as seguintes fun��es:

  a) fun��o que apresenta os m�ltiplos de 5 entre 1 e um n (inteiro e positivo) informado;

  b) fun��o que recebe as coordenadas de dois pontos no plano cartesiano (valores float) e apresenta 
  a dist�ncia entres esses dois pontos;

  c) fun��o que recebe um caractere e o apresenta  50 vezes em uma linha.

  Previamente � chamada das fun��es, solicitar os dados que o usu�rio deve fornecer e verific�-los 
  quanto � sua corre��o (quando pertinente). S� seguir o processamento, e conseq�ente chamada das fun��es, 
  quando dados corretos tiverem sido fornecidos. Declarar os prot�tipos para todas as fun��es.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void multiplos_5 (int);
void calc_distancia (double, double, double, double);
void mostra_char (char);

int main ()
{
    int n; 
    double x1, y1, x2, y2;
    char c;
    
    //Multiplos de 5
    do 
    {
       printf ("Numero de multiplos de 5: ");
       scanf ("%d", &n);
       if (n < 1)
          printf ("\tInsira uma valor maior ou igual a 1\n");
    } while (n < 1);
    multiplos_5 (n);
    
    //Distancia entre dois pontos
    printf ("\n\nForneca x1, y1:\n");
    scanf  ("%lf%lf", &x1, &y1);
    printf ("Forneca x2, y2:\n");
    scanf  ("%lf%lf", &x2, &y2);
    calc_distancia (x1, y1, x2, y2);
    
    //Mostra caractere
    printf ("\nDigite um caractere: ");
    fflush(stdin);
    scanf ("%c", &c);
    mostra_char (c);
    
    printf ("\n");
    system ("pause");
    return 0;
}

void multiplos_5 (int n)
{
     int valor;
     if (n < 5)
        printf ("Nao ha multiplo de 5");
     else   
        for (valor = 5; valor <= n; valor += 5)
            printf ("%d  ", valor);
}

void calc_distancia (double x1, double y1, double x2, double y2)
{
   double lado1, lado2, d;
   lado1 = x2 - x1;
   lado2 = y2 - y1;
   d = sqrt (lado1 * lado1 + lado2 * lado2); 
   printf ("Distancia = %lf\n", d);
}

void mostra_char (char c)
{
     int i;
     for (i = 0; i < 50; i++)
         printf ("%c", c);
     printf ("\n\n");    
}











