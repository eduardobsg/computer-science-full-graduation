/*
  Name: autoavaliacao132 - parte 1
  Autora: Maria Aparecida C. Livi
  Data: 03/05/08 
  Descricao: Executa as seguintes fun��es:
             a) funcao que recebe dois valores inteiros, 
                o primeiro menor que o segundo, e retorna 
                em seu nome o somatorio dos valores desse 
                intervalo (limites incluidos). 
                Ex.: valores recebidos 3 e 9, 
                resultado retornado 42 (soma de 3, 4, 5, 6, 7 , 8 e 9);
             b) funcao que recebe a idade de uma pessoa e retorna seu ano de nascimento;
             c) anos bissextos ocorrem de quatro em quatro anos. 
                Mas se o ano � multiplo de 100, ele so sera bissexto 
                se tambem for multiplo de 400. Por exemplo, 
                o ano 1900 nao foi bissexto, mas o ano 2000 foi. 
                Fazer uma funcao que fornecido um ano, retorne 1 
                se ele eh bissexto e 0 se ele nao eh; 
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MAXANO 2009
int somatorio (int, int);
int anonascimento(int);
int veseehanobissexto(int);
int main (  )
 {
   int num1, num2, idade_atual, ano_a_verificar;
   //Tarefa a: recebe dois valores (primeiro menor) e apresenta somatorio do intervalo,
   //limites incluidos 
   printf("\nPrimeiro valor (menor de dois) para calculo de somatorio: ");
   scanf("%d", &num1); 
   printf("\nSegundo valor (maior de dois) para calculo de somatorio: ");
   scanf("%d", &num2);
   if (num2 < num1)
   {
      printf("\nValores foram invertidos para calculo do somatorio. \nMaior foi fornecido primeiro!\n");
      printf("\nSomatorio dos valores no intervalo %d a %d = %d\n", num2, num1, somatorio(num2, num1));
   }  
   else  
      printf("\nSomatorio dos valores no intervalo %d a %d = %d\n", num1, num2, somatorio(num1, num2)); 
   //Tarefa b: recebida a idade de uma pessoa retorna seu ano de nascimento
   do
     {
      printf("\nIdade de uma pessoa : "); 
      scanf("%d", &idade_atual); 
      if (idade_atual < 0 || idade_atual > 120)
          printf("\nIdade invalida (< 0 ou > 120)!");
     }
   while (idade_atual < 0 || idade_atual > 120);     
   printf("\nUma pessoa hoje com %d anos nasceu em %d\n", idade_atual, anonascimento(idade_atual));  

   //Tarefa c:  recebido um ano, informa se ele eh ou nao bissexto
   do
     {
      printf("\nAno (entre 1 e %d) para informar se eh bissexto: ", MAXANO); 
      scanf("%d", &ano_a_verificar); 
      if (ano_a_verificar < 1 || ano_a_verificar > MAXANO)
          printf("\nAno invalido - deve ser entre 1 e %d)!\n", MAXANO);
     }
   while (ano_a_verificar < 0 || ano_a_verificar > MAXANO);  
   if (veseehanobissexto(ano_a_verificar))
       printf("\nAno %d eh bissexto\n", ano_a_verificar);
   else
      printf("\nAno %d nao eh bissexto\n", ano_a_verificar);   
   system ("pause");
   return 0;      
 }
 int somatorio (int n1, int n2)
 {
   int i, soma = 0;  
   for (i = n1; i <= n2; i++)
       soma = soma + i;
   return soma;      
 }
int anonascimento(int idade)
{ 
  return (2009 - idade);  
}
int veseehanobissexto(int ano)
{
  if (!(ano %4))
     {
      if (!(ano % 100))
          if (!(ano % 400))
              return 1; 
          else
              return 0;
     else
        return 1;
     }   
  else
     return 0;
 }
