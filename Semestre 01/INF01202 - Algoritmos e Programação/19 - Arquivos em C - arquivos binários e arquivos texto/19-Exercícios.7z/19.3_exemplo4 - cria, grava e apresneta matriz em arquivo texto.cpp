/*
Cria��o de uma matriz, grava��o de uma matriz em um arquivo texto,
apresenta��o da matriz
*/
#include <stdio.h>
#include <stdlib.h>

#define MAXLIN 2
#define MAXCOL 3

void cria_arq (FILE *, int  [] [MAXCOL], int, int);
void mostra_matriz (int [] [MAXCOL], int, int);

int main( )
{
    int m[MAXLIN][MAXCOL];
    FILE *arq;   
    system("color 70");   
    if (!(arq = fopen("primusarq.txt","w")))// vincula a variavel arq ao arquivo primusarq
    {
       printf("\nErro na abertura!\n"); 
       system("pause");
    }
    else
    {       
       cria_arq (arq, m, MAXLIN, MAXCOL);
       mostra_matriz (m, MAXLIN, MAXCOL);
       fclose(arq);    
       system("pause"); 
       return 0;  
    }
}

void cria_arq (FILE * arq, int m[] [MAXCOL], int mlin, int mcol)
{
     int i,j;
     // Leitura dos valores de teclado para compor a matriz  
     printf("Entre com os dados inteiros do intervalo [0,99] para a matriz m \n");  
     for(i=0; i<mlin ; i++)
        for(j=0; j<mcol; j++) 
        { 
          printf("Valor[%d] [%d]: ", i+ 1, j + 1);
          scanf("%2d", &m[i][j]); 
        }
     // gravacao da matriz no arquivo primusarq
     for(i=0; i<mlin; i++)
     {   
         for( j=0; j<mcol; j++)
              fprintf(arq,"%d ",m[i][j]);  //gravacao de dados em arq
         fprintf(arq,"\n"); 
     }
}

void mostra_matriz (int m[ ] [MAXCOL], int mlin, int mcol)
{
     int i,j;
     // Mostrar a matriz gravada                  
     printf("\n  Matriz dada\n");  
     for(i=0; i<mlin ; i++)
     {    
          for(j=0; j<mcol; j++)
                   printf("%d  ",m[i][j]);  
          printf("\n");
     }
}
