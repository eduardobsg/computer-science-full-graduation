/*
  Name: 19.19_avaliacao - altera e lista um arquivo j� existente.cpp
  Author: Jo�o Luiz Grave Gross
  Date: 14/06/09 10:00
  Description: Exerc�cio de Avalia��o 19.19 - enunciado

  Problema: Implemente um programa C que processe randomicamente um arquivo 
  (j� previamente criado pelo(a) aluno(a) no Exerc�cio de Auto Avalia��o) 
  com dados armazenados na seguinte estrutura relativa a clientes de uma empresa:
  "	codigo (inteiro entre 1 e 50) 
  "	nome (m�ximo 15) 
  "	telefone (m�ximo 10) 
  "	email (m�ximo 20) 
  "	d�bito (float) 
  "	exclusao (inteiro) 
  
  Detalhamento:
  1.	Os dados de cada cliente dever�o estar armazenados na posi��o correspondente 
  ao c�digo do cliente menos 1. 
  2.	O programa dever� conter no m�nimo as seguintes fun��es: 
     a.	altera��o: do valor do d�bito de um cliente determinado(processamento rand�mico do arquivo). 
     b.	listagem: de todos os dados de clientes existentes e n�o exclu�dos (processamento seq�encial 
     do arquivo). 
  3.	Essas fun��es dever�o ser chamadas em qualquer ordem, tantas vezes quantas o usu�rio desejar. 
  Ap�s o atendimento de cada solicita��o (altera��o de d�bito de um cliente ou listagem de todo o arquivo), 
  deve ser apresentado o menu de op��es novamente. 
  4.	Verificar a corre��o do d�bito informado. (maior o igual a zero)
  5.	N�o aceitar c�digo inv�lido, e acusar erro se for tentada uma altera��o para cliente n�o existente. 
  Aten��o: 
  como neste problema podem alternar-se os tipos de acesso sobre o arquivo (seq�encial e rand�mico), cuidar 
  para que sempre que for tentada uma leitura sobre o arquivo ele esteja posicionado em algum ponto v�lido 
  para leitura/escrita e n�o direto no seu final.
             
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define MAXCOD 15
#define MAXNOME 16
#define MAXTELEFONE 11
#define MAXEMAIL 21

struct dados
{
    int codigo;
    char nome[MAXNOME];
    char telefone[MAXTELEFONE];
    char email[MAXEMAIL];
    float debito;
    int exclus;   
};  

char opcao_menu (void);
void listar_clientes (int);
void altera_debito (int);

int main()
{   
    char cod;
    do
    {    
         cod = opcao_menu();
         if (cod =='L')  
            listar_clientes(MAXCOD);
         if (cod =='D')  
            altera_debito(MAXCOD);
         printf ("\n");
         fflush (stdin);
         system ("pause");
    } while (cod != 'F');
    return 0;
}

char opcao_menu()      //menu com as opera�oes
{    
     system ("CLS");
     printf ("O que deseja fazer?");
     printf ("\n- (L)istar clientes");
     printf ("\n- Alterar (D)ebito");
     printf ("\n- (F)im");
     printf ("\nCodigo: ");
     return (toupper(getchar()));
}

void listar_clientes (int maxcod)
{    
     FILE *arq;
     int i;
     struct dados bclientes;
     if (!(arq = fopen ("clientes.dat","r")))  
     {  
        printf("Erro ao abrir arquivo\n");
        system("pause");
     }
     else
     {   
        for (i = 0; ((i < maxcod) && !feof(arq)); i++) 
        {
            if (fread (&bclientes, sizeof (struct dados), 1, arq) && bclientes.codigo && !bclientes.exclus) 
            { //fread = 1, c�digo != zero, exclus = zero
               printf ("\nCodigo: %d", bclientes.codigo);  
               printf ("\nNome: %s", bclientes.nome); 
               printf ("\nTelefone: %s", bclientes.telefone);
               printf ("\nE-mail: %s", bclientes.email);
               printf ("\nDebito: %.2f", bclientes.debito);
               printf ("\nExclusao: %d", bclientes.exclus);
               printf("\n\n");                   
            }       
        }
        fclose(arq);
     }
} 

void altera_debito (int maxcod)
{
     FILE *arq;
     int cod;
     struct dados bclientes;  
     if (!(arq = fopen ("clientes.dat","r+b")))  
     {  
        printf("Erro ao abrir arquivo para alterar o debito\n");
        system("pause");
     }
     else
     {
         do
         {
            printf ("\nInsisra o codigo do cliente (1 a 15): ");
            fflush (stdin);
            scanf ("%d", &cod);
            if (cod < 1 || cod > 15)
               printf ("\nCodigo invalido!\n");        
         } while (cod < 1 || cod > 15);
         fseek (arq, (cod - 1)*sizeof (struct dados), SEEK_SET);
         fread (&bclientes, sizeof (struct dados), 1, arq);    
         if (bclientes.codigo && !bclientes.exclus) //c�digo != zero e exclus = zero    
         {
            do
            {
                printf ("Novo debito (0 a 10000): ");       
                scanf ("%f", &bclientes.debito);
                if (bclientes.debito < 0 || bclientes.debito > 10000)
                   printf ("\nValor invalido!\n");        
            } while (bclientes.debito < 0 || bclientes.debito > 10000);         
            fseek (arq, (cod - 1)*sizeof (struct dados), SEEK_SET);
            fwrite (&bclientes, sizeof (struct dados), 1, arq);
            printf ("\nDebito alterado com sucesso\n");
         }
         else
            printf ("\nCliente inexistente\n");
     }
     fclose (arq);
}






















