/* fseek example */
#include <stdio.h>
#include <stdlib.h>

int main ()
{
  FILE * pFile;
  int valor;
  pFile = fopen ( "example1.txt" , "w" );
  valor = ftell ( pFile );
  printf ("\nArquivo aberto -> Posicao: %d", valor);
  fputs ( "This is an apple." , pFile );
  fseek ( pFile , 9 , SEEK_SET );
  valor = ftell ( pFile );
  printf ("\nDepois de fseek com seek_set -> Posicao: %d", valor);
  fputs ( " sam" , pFile );
  fclose ( pFile );
  
  pFile = fopen ( "example2.txt" , "w" );
  valor = ftell ( pFile );
  printf ("\n\nArquivo aberto -> Posicao: %d", valor);
  rewind (pFile);
  fputs ( "This is an apple." , pFile );
  fseek ( pFile , 9 , SEEK_CUR );
  valor = ftell ( pFile );
  printf ("\nDepois de fseek com seek_cur -> Posicao: %d", valor);
  fputs ( " sam" , pFile );
  fclose ( pFile );
  
  pFile = fopen ( "example3.txt" , "r+" );
  valor = ftell ( pFile );
  printf ("\n\nArquivo aberto -> Posicao: %d", valor);
 //fputs ( "This is an apple." , pFile );
  fseek ( pFile , -1 , SEEK_END );
  valor = ftell ( pFile );
  printf ("\nDepois de fseek com seek_end -> Posicao: %d", valor);
  //fputs ( " sam" , pFile );
  fclose ( pFile );
  
  printf ("\n\n\n");
  system ("pause");
  return 0;
}
