/*
Cria um arquivo com dados de uma estrutura
com informacoes de atletas, de forma rand�mica.
*/ 

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

#define MAXCOD 10
#define MAXNOME 21

FILE *arq;

struct atleta
{
       char nome[30];
       int idade;
       float altura;
};

int main()  
{
    int encontrado = 0, contgrav = 0, cod, op;
    struct atleta buffer;
    char nome[MAXNOME], procurado[30];
    system ("color 70");
    fflush(stdin);
    printf ("Nome do arquivo (com no maximo %d caracteres): ", MAXNOME - 1);
    fgets(nome, sizeof(nome), stdin);
    if (nome[strlen(nome) - 1] == '\n')
       nome[strlen(nome) - 1] = '\0';
    fflush(stdin);
    if(!(arq = fopen(nome,"wb")))
    { /*abre para leitura/escrita*/
      printf("Erro abertura");
      system("pause");              
    }
    else
    {  
       do 
       {   
           do
           {
              printf("Codigo do atleta: ");
              scanf("%d", &cod);
              if (cod < 1 || cod > MAXCOD)
                 printf("\nCodigo deve estar entre 1 e %d!\n", MAXCOD);
           } while (cod < 1 || cod > MAXCOD);
           cod--;
           fflush(stdin);
           printf("\nNome: ");
           fgets(buffer.nome, sizeof(buffer.nome), stdin);
           if (buffer.nome[strlen(buffer.nome) - 1] == '\n')
              buffer.nome[strlen(buffer.nome) - 1] = '\0';
           fflush(stdin);
           printf("\nIdade: ");
           scanf("%d",&buffer.idade);
           printf("\nAltura: ");
           scanf("%f",&buffer.altura);
           //fseek(arq,cod*sizeof(struct atleta),SEEK_SET);
           fseek(arq,cod*sizeof(struct atleta),0); // esta linha faz o mesmo que a anterior,
           //no final, SEEK_SET ou 0 � o mesmo.
           fwrite(&buffer,sizeof(struct atleta),1,arq);
           fflush(arq);
           printf("\n1-InserirNovo, 2-Encerrar\n");
           scanf("%d", &op);
       } while(op != 2);
       fclose(arq);  
    }
    system("pause");
    return 0;
}
