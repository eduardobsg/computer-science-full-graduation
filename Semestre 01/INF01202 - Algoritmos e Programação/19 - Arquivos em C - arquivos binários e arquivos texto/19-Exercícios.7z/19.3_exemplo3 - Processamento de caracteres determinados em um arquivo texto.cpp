/*
Processamento de caracteres determinados em um arquivo texto
(com uso de acesso rand�mico)

Ler um arquivo texto e trocar todas as 
ocorr�ncias de um caractere no arquivo por 
outro caractere, informado pelo usu�rio em 
tempo de execu��o.
*/

#include <stdio.h>
#include <stdlib.h>

int main( )
{
    FILE *arq;
    char antigo, novo, temp, caract;
    int alt = 0;
    system("color f1");
    if ((arq = fopen("texto01.txt", "r+")) == NULL)
    {
       printf("Erro ao abrir \n");
       system("pause");
    }
    else
    {
        printf("\nCaractere a procurar: \n");
        scanf(" %c", &antigo);
        printf("\nSubstituir por: \n");
        scanf(" %c", &novo);  
        while (!feof(arq))
        {
              temp = getc(arq);
              if (temp == antigo)
              {
                 alt++;    
                 /*volta a posicao do caractere procurado*/
                 fseek(arq,-1*sizeof(char),SEEK_CUR); 
                 putc(novo,arq); /*substitui*/
                 fflush(arq); /*escreve mudancas*/
              }
        }
        fclose(arq);
        printf("\nNumero de caracteres alterados: %d\n", alt);
        if ((arq = fopen("texto01.txt", "r")) == NULL)
        {
           printf("Erro ao abrir para listar \n");
           system("pause");
        }
        else
        {  
           printf("\n\n"); 
           while (!feof(arq))
                 printf ("%c", getc(arq));
           fclose(arq);
           system("pause");
           return 0;
        }
    }
}
