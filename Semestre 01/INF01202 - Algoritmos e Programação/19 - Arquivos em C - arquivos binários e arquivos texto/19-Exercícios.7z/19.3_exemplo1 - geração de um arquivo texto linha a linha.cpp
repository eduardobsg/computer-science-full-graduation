//Gera��o de um arquivo texto linha a linha

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLIN 80

int grava_arq(FILE *, int);
int le_arq(FILE *, int);

int main( )
{
    FILE *arq;
    int linhas_grav = 0, linhas_lid = 0;
    system("color f1");
    if ((arq = fopen("texto01.txt", "w")) == NULL)
    {
       printf("Erro abertura arquivo para gravar\n");
       system("pause");
    }
    else
    {
        linhas_grav = grava_arq(arq, MAXLIN);
        printf("\nLinhas gravadas = %d\n", linhas_grav);
        fclose (arq);
        if ((arq = fopen("texto01.txt", "r")) == NULL)
        {
           printf("Erro abertura arquivo para ler\n");
           system("pause");
        }
        else
        {
            linhas_lid = le_arq(arq, MAXLIN); 
            printf("\nLinhas lidas = %d\n", linhas_lid);
            fclose(arq);
            system ("pause");
            return 0;
        }
    }
}

int grava_arq(FILE *arq1, int maximo)
{
    char linha[maximo];
    int gravs = 0;
    printf("\nDigite quantas linhas de %d caracteres desejar\n", maximo);
    printf ("Para parar FIM no inicio de uma linha\n");
    fgets(linha, sizeof(linha), stdin);
    if (linha[strlen(linha) - 1] == '\n')
       linha[strlen(linha) - 1] = '\0';
    while ((strcmp(linha, "FIM")))
    {
          fputs (linha, arq1);
          putc('\n', arq1);
          gravs++;
          fgets(linha, sizeof(linha), stdin);
          if (linha[strlen(linha) - 1] == '\n')
             linha[strlen(linha) - 1] = '\0';
    }
    return gravs;  
}

int le_arq(FILE * arq2, int maximo)
{
    char linha[maximo];
    int lidas = 0, i;
    fgets(linha, sizeof(linha), arq2);
    printf ("Valores, em ordem, de cada caracter da primeira linha:\n");
    for  (i = 0; i < strlen(linha) ; i++)
         printf("\n%d\n", linha[i]);
    while (!(feof(arq2)))
    {
          printf("%s", linha);
          lidas++;
          fgets (linha, sizeof (linha) , arq2);
    }
    return lidas;   
}
