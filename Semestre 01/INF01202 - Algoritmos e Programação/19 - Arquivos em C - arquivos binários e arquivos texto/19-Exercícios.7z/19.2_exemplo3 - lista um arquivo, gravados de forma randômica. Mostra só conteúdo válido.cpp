/*
Lista sequencialmente um arquivo com dados de uma estrutura
com informacoes de atletas. Arquivo gerado randomicamente.
Na listagem h� controle para bloquear a apresentacao de posicoes
para as quais nao foram fornecidos dados.

Gerar arquivo com o programa: 19.2_exemplo2 - grava dados em um 
arquivo com informa��es de atletas. Grava em ordem rand�mica, 
definia pelo user.cpp
*/ 

#include <stdio.h> 
#include <stdlib.h>

FILE *arq;

struct atleta
{
       char nome[30];
       int idade;
       float altura;
};

int main()  
{
    struct atleta buffer;
    int contlidos = 0;
    char nome[15];
    int op;
    system("color 70");
    printf("Nome do arquivo: ");
    gets(nome);
    fflush(stdin);
    if(!(arq = fopen(nome,"rb")))
    {
       printf("Erro abertura");
       system("pause");
    }
    else
    {
        printf("-----Comeco da listagem-----\n");
        while(!feof(arq))
           if (fread(&buffer,sizeof(struct atleta),1,arq) == 1)
           {//l� e confirma se o que foi lido � estrutura, ent�o imprime
                 contlidos++;
                 if (buffer.idade > 0)
                 {
                    printf("Codigo: %d\n", contlidos);
                    printf("Nome: %s\n",buffer.nome);
                    printf("Idade: %d\n",buffer.idade);
                    printf("Altura: %6.2f\n\n",buffer.altura);
                 }
           }
        printf("-----Fim da listagem-----\n");
        fclose(arq);
        system("pause");
        return 0;
    }
}
