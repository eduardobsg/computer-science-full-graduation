/*
  Name: 19.2_auto.avaliacao - insere, lista e exclui uma lista de clientes randomicamente
  Author: 
  Date: 13/06/09 19:05
  Description: AV19 - Exerc�cio de Auto Avalia��o 19.2       

    Fazer um programa que gere randomicamente um arquivo com dados armazenados na seguinte estrutura relativa a 
    clientes de uma empresa: 
          
    Estrutura:      
    "	codigo (inteiro entre 1 e 50) 
    "	nome (m�ximo 15) 
    "	telefone (m�ximo 10) 
    "	email (m�ximo 20)
    "	d�bito (float) 
    "	exclusao (inteiro) 
    
    Detalhamento:
    1.	Os dados de cada cliente dever�o ser armazenados na posi��o correspondente ao c�digo do cliente menos 1. 
    2.	Na inclus�o de um cliente, d�bito e exclus�o dever�o ser inicializados com zero. 
    3.	Email n�o � obrigat�rio. 
    4.	O programa dever� conter no m�nimo as seguintes fun��es: 
    a) inclus�o: dos dados de um cliente no arquivo; 
    b) listagem: de todos os dados de clientes existentes e n�o exclu�dos; 
    c) exlus�o: l�gica de um cliente (um cliente exclu�do � aquele que tem campo exclus�o igual a 1).
    5. Essas fun��es dever�o ser chamadas na seguinte ordem: 
       1) o usu�rio inclui quantos clientes desejar no arquivo; 
       2) todo o arquivo � listado. 
       3) o usu�rio exclui logicamente quantos clientes quiser; 
       4) todo o arquivo � listado. 
    6. N�o aceitar c�digo inv�lido, e acusar erro se for tentada uma inclus�o para cliente j� existente ou uma 
    exclus�o para cliente n�o existente. 
             
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXCOD 15
#define MAXNOME 16
#define MAXTELEFONE 11
#define MAXEMAIL 21

struct dados
  {
    int codigo;
    char nome[MAXNOME];
    char telefone[MAXTELEFONE];
    char email[MAXEMAIL];
    float debito;
    int exclus;   
  } ;  
  
FILE *cli;
int inclusao(FILE *, struct dados, int, int, int, int);
int exclusao(FILE *, struct dados);
void listagem(FILE *, struct dados);

int main (  )
   {
     int op, cod, res; 
     struct dados clientes;
     //cria um arquivo novo para leitura e escrita
     //se o arquivo ja existir, seu conteudo eh ignorado
     //e ele eh tratado como um arquivo novo
     cli = fopen ("clientes.dat", "w+b");
     if (cli == NULL)
        {
         printf("\nErro na abertura do arquivo!\n"); 
         system("PAUSE");
         }
     else
         {
           printf("\n***Inicio das inclusoes***"); 
           do
            {
              do
                {
                  printf("\nCodigo a incluir: ");
                  scanf("%d", &cod);  
                  if (cod < 1 || cod > MAXCOD) 
                     printf("\nCodigo deve ser entre 1 e %d!\n\n", MAXCOD);           
                } while (cod < 1 || cod > MAXCOD); 
              res = inclusao(cli, clientes, cod, MAXNOME, MAXTELEFONE, MAXEMAIL);
              if (res == 1)
                   printf("\nInclusao para ja existente - cliente %d\n\n", cod);     
              else
                  if (res == 2)
                      printf("\nErro de escrita na inclusao\n\n");
                  else
                      {                   
                        printf("1 - NovaInclusao; 0 - PararInclusoes");  
                        scanf("%d", &op);   
                      }             
            } while (op && (res != 2));
           if (res != 2) // se nao aconteceu erro de escrita
              {
                fclose(cli) ;
                printf("\n***Listagem***"); 
                //abre o arquivo para leitura. Ele deve existir.
                cli = fopen ("clientes.dat", "rb");
                listagem(cli, clientes);
                fclose(cli);
                //abre o arquivo para atualizacao - leitura e escrita.
                //arquivo deve existir
                cli = fopen ("clientes.dat", "r+b");
                if (cli == NULL)
                    printf("\nErro abertura antes da exclusao\n\n");     
                res = exclusao(cli, clientes);
                if (res != 2) //
                   {
                     fclose(cli);
                     //abre o arquivo para leitura. Ele deve existir.
                     cli = fopen ("clientes.dat", "rb");
                     listagem(cli, clientes);
                     fclose(cli);
                   } 
             system("pause");      
             return 0;
           }  
        } 
     system("pause");  
   }  
     
int inclusao(FILE *cl, struct dados client, int codig, int maxnome, int maxtelef, int maxemail)
   {
     int erro = 0;
     //Retorna 0 se inclusao bem sucedida;
     //retorna 1 se for tentativa de inclusao para ja existente.             
     //Primeiro verifica-se se a posicao de (codigo - 1) esta livre para inclusao.
     //Posicao ja ocupada eh erro: inclusao para ja existente.
     fseek(cl, (codig - 1)*sizeof(struct dados), SEEK_SET);
     if (fread(&client, sizeof(struct dados), 1, cl) == 1)
         if (client.codigo > 0) //se client.codigo > 0, essa posi��o do arquivo j� tem dados             
             erro = 1;          
     if (!erro)
         {
           client.codigo = codig;       
           printf("\nForneca os dados do cliente %d \n", codig);
           do
             {
              printf("\nNome (maximo de %d caracteres): ", maxnome);
              fflush(stdin);
              gets (client.nome);
              fflush(stdin);
              if  (strlen(client.nome) > (maxnome - 1))
                  printf("\nNome com mais de %d caracteres!\n", maxnome);                
             } while (strlen(client.nome) > maxnome - 1);   
           do
             {
              printf("\nTelefone (maximo de %d caracteres): \n", maxtelef);
              fflush(stdin);
              gets (client.telefone);
              fflush(stdin);
              if  (strlen(client.telefone) > (maxtelef - 1))
                  printf("\nTelefone com mais de %d caracteres!\n", maxnome);                
             } while (strlen(client.telefone) > maxtelef - 1);  
           do
             {
              printf("\nE-mail (maximo de %d caracteres): \n", maxemail);
              fflush(stdin);
              gets (client.email);
              fflush(stdin);
              if  (strlen(client.email) > (maxemail - 1))
                  printf("\nE-mail com mais de %d caracteres!\n", maxemail);                
             } while (strlen(client.email) > maxemail - 1); 
           client.debito = 0;
           client.exclus = 0;
           //a leitura para verificar possibilidade de inclusao para ja existente
           //alterou o posicionamento para leitura/escrita no arquivo,
           //o fseek faz retornar para a posicao onde vai ser feita a inclusao
           fseek(cl, (codig - 1) * sizeof(struct dados), SEEK_SET);
           if (!(fwrite(&client, sizeof(struct dados), 1, cl)))
               {
                printf("\nErro na escrita do arquivo\n\n");
                erro = 2; 
                }
           else
               printf("\nInclusao realizada - codigo %d\n\n", codig);            
           fflush(cl);     
         }          
     return erro;               
   }                
   
void listagem(FILE *cl, struct dados client)
{
     
      fread(&client, sizeof(struct dados), 1, cl);
      while (!feof(cl))
         {       
          if (client.codigo && (!client.exclus))
             {     
                 printf ("\nCodigo: %d", client.codigo);  
                 printf ("\nNome: %s", client.nome);
                 printf ("\nTelefone: %s", client.telefone);
                 printf ("\nE-mail: %s", client.email);
                 printf ("\nDebito: %6.2f", client.debito);
                 printf ("\nExclusao: %d", client.exclus);
                 printf("\n\n");
                 
             } 
          fread(&client, sizeof(struct dados), 1, cl);
         }  
 }
 
int exclusao(FILE *cl, struct dados client)
{
   int erro, op, codig, res;
   printf("\n***Inicio das exclusoes***"); 
   do
     {
       erro = 0;
       do
         {
           printf("\nCodigo a excluir: ");
           scanf("%d", &codig);  
           if (codig < 1 || codig > MAXCOD) 
               printf("\nCodigo deve ser entre  1 e %d!\n", MAXCOD);           
         }                  
       while (codig < 1 || codig > MAXCOD); 
       fseek(cl, (codig -1)*sizeof(struct dados), SEEK_SET);
       res = fread(&client, sizeof(struct dados), 1, cl);
       if (!(res))
           { 
           // eh exclusao para inexistente porque a posicao nao existe no arquivo       
           printf("\nExclusao inexistente - cliente %d\n\n", codig);
           erro = 1;
           }  
       else
           if ((client.codigo > 0 && client.exclus == 1) || client.codigo < 1)
              {
                //eh exclusao para inexistente ou porque o cliente ja estava excluido
                //(primeira parte da condi??o) ou porque esta posicao na verdade eh
                //vazia, foi gerada pelo sistema no processo de acesso randomico ao arquivo              
                printf("\nExclusao inexistente - cliente %d\n\n", codig); 
                erro = 1;
              }            
       if (erro == 0)
          {    
            client.exclus = 1;     
            fseek(cl, (codig - 1)*sizeof(struct dados), SEEK_SET);
            res = (fwrite(&client, sizeof(struct dados), 1, cl));
            if (!res) //se aconteceu erro de escrita
               {
                 printf("\nErro na escrita do arquivo durante exclusao\n\n");
                 erro = 2;
               }
            else
               {
                 fflush(cl); 
                 printf("\nExclusao realizada - codigo %d\n\n", codig);  
               } 
          }     
       if (erro != 2)
               {      
                 printf("1 - NovaExclusao; 0 - PararExclusoes: ");  
                 scanf("%d", &op);      
               }                         
     }                  
   while (op && (erro != 2));  
}
