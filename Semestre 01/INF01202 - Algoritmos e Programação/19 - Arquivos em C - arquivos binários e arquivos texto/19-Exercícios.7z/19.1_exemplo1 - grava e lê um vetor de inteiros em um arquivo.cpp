/*
Grava um vetor de inteiros em um arquivo,
em uma unica operacao de escrita.
Le o vetor de inteiros do arquivo
em uma unica operacao de leitura
e o apresenta.
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 5

FILE *arq;

int main ()
{
    int vet1[MAX], vet2[MAX], i;
    system("color 02");
    printf ("\n------ Inicio da Gravacao -------\n\n");
    for (i = 0; i<MAX; i++)
    {
        printf("Valor %d: ", i + 1);
        scanf("%d", &vet1[i]);
    }
    printf("\n");
    if (!(arq = fopen("int", "wb")))
    {
       printf("\nO arquivo nao pode ser aberto para escrita!");
       system ("pause");
    }      
    else
    {
        fwrite(vet1, sizeof(int), MAX, arq);
        fclose (arq);
        printf ("------ Fim da Gravacao -------");
    }
    if ((arq = fopen("int", "rb")) == NULL)
    {
       printf("\nO arquivo nao pode ser aberto para leitura!");
       system ("pause");
    }
    else
    {
        printf ("\n\nValores lidos do arquivo: ");
        fread(vet2, sizeof(int), MAX, arq);
        fclose (arq);
        for (i = 0; i<MAX;i++)
            printf("%d ", vet2[i]);
        printf("\n\n");
    }
    system("pause");
    return 0;
}
