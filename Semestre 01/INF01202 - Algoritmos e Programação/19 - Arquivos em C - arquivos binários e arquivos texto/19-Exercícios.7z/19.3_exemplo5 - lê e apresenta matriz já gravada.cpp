/*
Leitura de uma matriz gravada em 
um arquivo texto e sua apresenta��o na tela
*/

#include <stdio.h>
#include <stdlib.h>

#define MAXLIN 2
#define MAXCOL 3

void le_arq (FILE *, int  [] [MAXCOL], int, int);
void mostra_matriz (int [] [MAXCOL], int, int);

int main( )
{
    int m[MAXLIN][MAXCOL];
    FILE *arq;   
    system("color 70");
    if (!(arq = fopen("primusarq.txt","r")))  // vincula a variavel arq ao arquivo primusarq
    {
       printf("\nErro na abertura!\n"); 
       system("pause");
    }
    else
    {       
       le_arq (arq, m, MAXLIN, MAXCOL);
       mostra_matriz (m, MAXLIN, MAXCOL);
       fclose(arq);    
       system("pause"); 
       return 0;  
    }
}

void le_arq (FILE * arq, int m[] [MAXCOL], int mlin, int mcol)
{
     int i,j;
     // Leitura da matriz a partir do arquivo primusarq
     for(i=0; i<mlin; i++)
        for( j=0; j<mcol; j++)
             fscanf(arq,"%d",&m[i][j]); // leitura dos valores do arquivo para matriz m   
}

void mostra_matriz (int m[ ] [MAXCOL], int mlin, int mcol)
{
     int i,j;
     // Mostrar a matriz gravada                  
     printf("\nMatriz lida do arquivo\n");  
     for(i=0; i<mlin ; i++)
     {    
          for(j=0; j<mcol; j++)
                   printf("%d  ",m[i][j]);  
          printf("\n");
     }      
}
