/*
Altera um arquivo com dados de uma estrutura
com informacoes de atletas.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXNOME 30

FILE *arq;

struct atleta
{
       char nome[MAXNOME];
       int idade;
       float altura;
};

void AlteraIdade(FILE *, struct atleta, int);
FILE * AbreArquivo(int , char *);

int main( )
{
    struct atleta buffer; // buffer aqui eh variavel
//    system ("color 70");
    AlteraIdade (arq, buffer, MAXNOME);
    system("pause");
    return 0;
}

void AlteraIdade(FILE *arq, struct atleta buffer, int max)
{
     int encontrado = 0, atletascont = 0;
     char procurado[max];
     if(!(arq = AbreArquivo(max, "r+b")))
     {
        printf("Erro abertura");
        system("pause");
     }
     else
     {
         fflush(stdin);
         printf("Nome do procurado: ");
         fgets(procurado, sizeof(procurado), stdin);
  //       if (procurado[strlen(procurado) - 1] == '\n')
  //          procurado[strlen(procurado) - 1] = '\0';
         fflush(stdin);
         while(!feof(arq))
            if (fread(&buffer,sizeof(struct atleta),1,arq) == 1)
            {                 
               if (!(strcmp(buffer.nome,procurado)))
               {
                  printf("\nIdade cadastrada %d",buffer.idade);
                  printf("\nNova Idade: ");
                  scanf("%d",&buffer.idade);
                  fseek(arq,atletascont*sizeof(struct atleta),SEEK_SET);
                  /*posiciona o ponteiro do arquivo no ponto para substituir estrutura referente ao nome solicitado*/
                  fwrite(&buffer,sizeof(struct atleta),1,arq); /*substitui*/
                  fflush(arq); /*descarrega p/ estrutura antiga ser apagada*/
                  encontrado = 1;
               }
               atletascont++; //indica em que ocorr�ncia da estrutura do arquivo se est� no momento
            }
         if (!encontrado)
            printf("\nNenhum atleta encontrado");
         fclose(arq);
     }
}

FILE * AbreArquivo(int max, char *modo)
{
     char nomearq[max];
     printf("Nome do arquivo (com no maximo %d caracteres): ", max - 1);
     fflush(stdin);
     fgets(nomearq, sizeof(nomearq), stdin);
     if (nomearq[strlen(nomearq) - 1] == '\n')
        nomearq[strlen(nomearq) - 1] = '\0';
     return fopen(nomearq,modo);
}
