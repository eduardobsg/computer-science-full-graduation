/*
Grava uma matriz bi em um arquivo
em uma unica operacao de escrita.
Le a matriz bi do arquivo em uma
unica operacao de leitura e
e a apresenta em seguida.
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 3

FILE *arq;

int main ( )
{
    int mat1[MAX][MAX], mat2[MAX][MAX], i, j, valor;
    system("color 60");
    printf ("\n------ Inicio da Gravacao -------\n\n");
    for (i = 0; i<MAX;i++)
        for (j = 0; j < MAX; j++)
        {
            printf("Valor [%d] [%d]: ", i + 1, j + 1);
            scanf("%d", &mat1[i] [j]);
        }
    printf("\n\n");
    if (!(arq = fopen("matint", "wb"))) //wb -> habilita opera��o de escrite (write)
    {
       printf("\nO arquivo nao pode ser aberto para escrita!");
       system ("pause");
    }
    else
    {
        fwrite(mat1, sizeof (int), MAX * MAX, arq);
        fclose (arq);
        rewind (arq); /* reset the file pointer's position */
        printf ("------ Fim da Gravacao -------");
    }
    if ((arq = fopen("matint", "rb")) == NULL) //rb -> habilita opera��o de leitura (read)
    {
       printf("\nO arquivo nao pode ser aberto para leitura!");
       system ("pause");
    }
    else
    {
        printf ("\n\nValores lidos do arquivo: ");
        fread(mat2, sizeof (int), MAX * MAX, arq);
        for (i = 0; i<MAX;i++)
        {
            printf("\n\n");
            for (j = 0; j < MAX; j++)
                printf("%d   ", mat2[i] [j]);
        }
    }
    printf("\n\n");
    system("pause");
    return 0;
}
