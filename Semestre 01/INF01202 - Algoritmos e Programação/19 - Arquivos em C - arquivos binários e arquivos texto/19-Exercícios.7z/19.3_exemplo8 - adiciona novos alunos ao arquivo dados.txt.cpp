//Programa adiciona novos alunos ao arquivo dados.txt

#include<stdio.h>
#include<stdlib.h>
#include <ctype.h>      // necessario para toupper()
#include<string.h>      // necessario para strtok()

#define MAX 80

char opcao_menu() ;
void listar_notas(int);
void novo_aluno() ;  

int main( )
{   
    char op;
    do
    {    
         op=opcao_menu();
         if (op =='L')  
            listar_notas(MAX);
         if (op =='N')  
            novo_aluno();
         printf("\n");
         system("pause");
    } while (op != 'F');
    return 0;
}
   
char opcao_menu( )      //menu com as opera�oes
{    
     system("CLS");
     printf("(L)istar notas\n");
     printf("(N)ovo aluno\n");
     printf("(F)im \n");
     printf(">");
     return(toupper(getchar()));
}
    
void listar_notas(int maxim)
{    
     int num, notas;
     float n1,n2,media;
     char *nome;
     char buf[maxim];
     FILE *arq;
     arq = fopen("dados.txt","r");  
     if (arq == NULL)
     {  
        printf("Erro ao abrir arquivo \n");
        system("pause");
     }
     else
     {   
        notas=0; 
        media=0;
        printf("\n");
        printf("NUM  |          NOME            |   N1  |    N2    \n");
        printf("-----+--------------------------+-------+---------\n");
        fgets(buf,sizeof(buf),arq);
        while (!feof(arq))
        {      
            num = atoi(strtok(buf,","));
            nome = strtok(NULL,",");
            n1 = atof( strtok(NULL,","));                    
            n2 = atof( strtok(NULL,",")); 
            printf("%03d  |   %20s   |  %4.1f | %4.1f |\n",num, nome,n1,n2);
            notas = notas +2;
            media = media + n1 + n2;
            fgets(buf,sizeof(buf),arq);
        }
        printf("-----+--------------------------+-------+---------\n");
        media = media / notas;
        printf("Media das notas = %4.1f\n", media);
        fclose(arq);
     }
} 

void novo_aluno()
{ 
     int num;
     float n1,n2;
     char nome[20];
     FILE *arq;
     arq = fopen("dados.txt","a");
     if (arq ==NULL)
     { 
        printf("Erro ao abrir arquivo!\n");
        system("pause");
     }
     else
     {
         printf("\n");     
         printf("Digite os dados do novo aluno: \n");
         printf("Numero...");
         scanf("%d",&num);
         printf("Nome....");
         fflush(stdin);
         fgets(nome, sizeof(nome), stdin);
         if (nome[strlen(nome) - 1] == '\n')
            nome[strlen(nome) - 1] = '\0';
         printf(" Nota 1:...");
         scanf("%f",&n1);
         printf(" Nota 2:...");
         scanf("%f",&n2);
         fprintf(arq,"%d,%s,%.1f,%.1f,\n",num,nome,n1,n2);
         fclose(arq);
     }
}  
