//Altera de um arquivo com dados de atletas

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

#define MAXCOD 10
#define MAXNOME 31

FILE *arq;

struct atleta
{
       char nome[MAXNOME];
       int idade;
       float altura;
};

int AlteraDados(FILE *, int);
void MostraAtleta (struct atleta , char *, int);
void RecebeDadosDaAlteracao (struct atleta *, int);

int main( )  
{
    int op, codigo, resultalt;
    system ("color 02");
    char nome[MAXNOME];
    fflush(stdin);
    printf("Nome do arquivo (com no maximo %d caracteres): ", MAXNOME - 1);
    fgets(nome, sizeof(nome), stdin);
    if (nome[strlen(nome) - 1] = '\n')
       nome[strlen(nome) - 1] = '\0';
    fflush(stdin);
    if(!(arq = fopen(nome,"r+b")))
    { /*abre para leitura/escrita*/
       printf("Erro abertura");
       system("pause");              
    }
    else
    {      
           do
           {
               do
               {
                    printf("\n**Alteracao de dado de atletas**\n");
                    printf("\nCodigo do atleta: ");
                    scanf("%d", &codigo);
                    if (codigo < 1 || codigo > MAXCOD)
                    printf("\nCodigo invalido deve estar entre 1 e %d\n", MAXCOD);         
               } while (codigo < 1 || codigo > MAXCOD);
               resultalt = AlteraDados (arq, codigo);
               if (resultalt == 1)
                  printf("\nAlteracao para inexistente - codigo %d\n", codigo);
               if (resultalt == 2)
                  printf("\nAlteracao cancelada - codigo %d\n", codigo);
               printf("O que deseja fazer?\n1 - Alterar outro atleta\n0 - Encerrar programa\nCodigo: ");
               scanf("%d", &op);
           }
           while (op);
                 fclose (arq);
           system("pause");
           return 0;
    }
}

int AlteraDados(FILE *arq, int cod)
{
    int opalt;
    struct atleta buffer;
    char titul[MAXNOME];
    cod--;
    fseek(arq,cod*sizeof(struct atleta),SEEK_SET);
    if (fread(&buffer,sizeof(struct atleta),1,arq) == 1)
    {
       if (buffer.idade)
       {
           strcpy(titul, "Antes da Alteracao");
           MostraAtleta (buffer, titul, cod);                      
           do
           {
              printf("Para alterar: \n1 - nome\n2 - idade");
              printf("\n3 - altura\n4 - todos\n0 - cancelar alteracao");
              printf ("\nCodigo: ");
              scanf("%d", &opalt);
              if (opalt < 0 || opalt > 4)
                 printf("\nOpcacao invalida - deve ser entre 1 e 4!\n");
           } while (opalt < 0 || opalt > 4); 
           if (opalt)
           {
              RecebeDadosDaAlteracao (&buffer, opalt);
              fseek(arq,cod*sizeof(struct atleta),SEEK_SET); /*posiciona*/
              fwrite(&buffer,sizeof(struct atleta),1,arq); /*substitui*/
              fflush(arq); /*descarrega p/ estrutura antiga ser apagada*/
              printf("\n>>>>Alteracao do atleta %d efetuada!\n\n", cod + 1);
              fseek(arq,cod*sizeof(struct atleta),SEEK_SET); 
              /*reposiciona*/
              fread(&buffer,sizeof(struct atleta),1,arq); /*le o alterado*/
              strcpy(titul, "Depois da Alteracao");
              MostraAtleta (buffer , titul, cod);
              return 0; // alteracao ok
           }
           else 
                return 2; // alteracao cancelada -> opalt = 0
       }
       else
           return 1; //alteracao para inexistente (posicao existe mas sem dados)
    }
    else
        return 1; //alteracao para inexistente (posicao nao existe)
}

void MostraAtleta (struct atleta buffer, char *titulo, int cod)
{ 
     printf("\n***%s***\n\n", titulo);
     printf("Codigo: %d\n", cod + 1);
     printf("Nome: %s\n",buffer.nome);
     printf("Idade: %d\n",buffer.idade);
     printf("Altura: %.2f\n\n",buffer.altura);
     printf ("\n");
}

void RecebeDadosDaAlteracao (struct atleta *buffer, int op)
{
     switch (op)
     {
         case  1: printf("\nNovo Nome: ");
                  fflush(stdin);
                  fgets((*buffer).nome, sizeof((*buffer).nome), stdin);
                  if (buffer->nome[strlen(buffer->nome) - 1] == '\n')
                     (*buffer).nome[strlen((*buffer).nome) - 1] = '\0';
                  fflush(stdin);
                  break;
         case  2: printf("\nNova Idade: ");
                  scanf("%d",&(*buffer).idade);
                  break;
         case  3: printf("\nNova Altura: ");
                  scanf("%f",&buffer->altura);
                  break;
         case  4: printf("\nNovo Nome: ");
                  fflush(stdin);
                  fgets((*buffer).nome, sizeof((*buffer).nome), stdin);
                  if ((*buffer).nome[strlen((*buffer). nome) - 1] == '\n')
                     (*buffer).nome[strlen((*buffer).nome) - 1] = '\0';
                  fflush(stdin);
                  printf("\nNova Idade: ");
                  scanf("%d",&(*buffer).idade);
                  printf("\nNova Altura: ");
                  scanf("%f",&(*buffer).altura);
                  break;
     }
}
