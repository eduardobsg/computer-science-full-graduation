/*
Ler um arquivo texto e gerar uma sua c�pia.
Apresentar os arquivos original e c�pia.

Obs.:  no exemplo a seguir, o arquivo c�pia � criado linha 
a linha, e a apresenta��o na tela dos conte�dos do 
arquivo original e da c�pia s�o feitos caractere a 
caractere.
*/

#include <stdio.h>
#include <stdlib.h>

#define MAXLINHA 255

void imprimearq (FILE *);

int main( )
{
    FILE *arq1;
    FILE *arq2;
    int cont = 0;
    char linha[MAXLINHA];
    system("color 70");
    if ((arq1 = fopen("texto01.txt", "r")) == NULL)
    {
       printf("Erro ao abrir arquivo entrada - 1 \n");
       system("pause");
    }
    else
    {
        if ((arq2 = fopen("textosai1", "w")) == NULL)
        {
           printf("Erro ao abrir arquivo saida - 1 \n");
           system("pause");
        }
        else
        {    
             while (!feof(arq1))
                   if (fgets(linha, sizeof(linha), arq1)) //pega a linha que o ponteiro arq1 esta apontando e coloca em "linha"
                   {
                      cont++  ; 
                      fputs (linha, arq2); //escreve o conte�do de linha em arq2
                      fflush(arq2);
                   }
             printf("\nLinhas processadas: %d\n", cont);
             fclose (arq1);
             fclose(arq2);
             if ((arq1 = fopen("texto01.txt", "r")) == NULL)
             {
                printf("Erro ao abrir arquivo de entrada - 2 \n");
                system("pause");
             }
             else
             {
                 printf("\n***ARQUIVO DE ENTRADA***\n");                
                 imprimearq(arq1);
                 fclose(arq1);
             }
             if ((arq2 = fopen("textosai1", "r")) == NULL)
             {
                printf("Erro ao abrir arquivo de saida - 2 \n");
                system("pause");
             }
             else
             {
                 printf("\n\n***ARQUIVO DE SAIDA***\n");      
                 imprimearq(arq2);
                 fclose(arq2);
             } 
        }
    }
    printf("\n\n");       
    system("pause");
    return 0;
}

void imprimearq(FILE *arq)
{
     while (!feof(arq))
           printf ("%c", getc(arq));
} 
