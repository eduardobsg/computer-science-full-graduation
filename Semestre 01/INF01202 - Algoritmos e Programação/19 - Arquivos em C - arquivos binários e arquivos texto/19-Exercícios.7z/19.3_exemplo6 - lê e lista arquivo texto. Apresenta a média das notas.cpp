/*
Programa que l� um arquivo texto e o lista. 
Arquivo armazena codigo(int), nome(string),
2 notas(float). Apresenta a m�dia das notas
dos alunos.
*/

#include<stdio.h>
#include<stdlib.h>
#include <ctype.h>      // necessario para toupper()
#include<string.h>      // necessario para strtok()

#define MAX 80

char opcao_menu(); 
void listar_notas(int);

int main()
{   
    char op;
    system("color 70");
    do
    {    
         op = opcao_menu();
         if (op =='L')  
            listar_notas(MAX);
         printf("\n");
         system("pause");
    } while (op != 'F');
    return 0;
}

char opcao_menu ( )     //menu com as operacoes
{    
     system("CLS");
     printf("(L)istar notas\n");
     printf("(F)im \n");
     printf(">");
     return(toupper(getchar()));
}

void listar_notas(int maximo)
{    
     int num, notas;
     float n1,n2,media;
     char *nome;
     char buf[maximo];
     FILE *arq;
     arq = fopen("dados.txt","r");  // abrir arq com opcao so de leitura:  r
     if (arq == NULL)
     {  
        printf("Erro ao abrir arquivo \n");
        system("pause");
     }
     else
     {   
         printf("\n");
         printf("NUM   |          NOME            |     N1  |    N2    \n");
         printf("------+--------------------------+---------+---------\n");
         notas=0;     
         media=0;
         fgets(buf,maximo,arq); //pega valor de que o ponteiro arq aponta e coloca em buf
         while (!feof(arq))      // enquanto nao for fim de arquivo.......
         {     
               num = atoi(strtok(buf,","));  // transforma string de buf em int
               nome = strtok(NULL,","); 
               n1 =atof( strtok(NULL,","));     // transforma string de buf em float   
               n2 =atof( strtok(NULL,",")); 
               printf("%03d   |    %20s  |   %4.1f  |  %4.1f  |\n",num, nome,n1,n2);
               notas = notas +2;        
               media = media + n1 + n2; 
               fgets(buf,maximo,arq);         
         }
         printf("------+--------------------------+---------+---------\n");         
         media = media/notas;
         printf("Media das notas = %4.1f\n", media);
         fclose(arq);
     }
} 
