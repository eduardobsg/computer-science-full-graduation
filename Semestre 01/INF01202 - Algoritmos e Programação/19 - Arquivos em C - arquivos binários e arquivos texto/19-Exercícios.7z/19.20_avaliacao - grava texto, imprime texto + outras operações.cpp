/*
  Name: 
  Author: Jo�o Luiz Grave Gross
  Date: 14/06/09 11:16
  Description: Exerc�cio de Avalia��o 19.20 - enunciado

  Fazer um ou mais programas, com no m�nimo as seguintes 3 (tr�s) fun��es, para 
  resolver o problema a seguir.
  O nome do arquivo utilizado dever� ser fornecido em tempo de execu��o.
  
  Problema: 
  a) Fun��o: cria��o de um arquivo texto com seu cont�udo em min�sculas, a partir 
  de um texto digitado (entrada via teclado) em que mudan�as de linha podem ser 
  tamb�m sinalizadas pelo s�mbolo #: 
         
  Exemplo de texto de entrada:
  gigante pela propria natureza,#es belo, es forte, impavido colosso,#
  e o teu futuro espelha essa grandeza.#terra adorada,#
  entre outras mil,# es tu,brasil,#o patria amada!#
  dos filhos deste solo es mae gentil,#patria amada,#brasil!# 
  
  gigante pela propria natureza,
  es belo, es forte, impavido colosso,#
  e o teu futuro espelha essa grandeza.#terra adorada,#
  entre outras mil,# es tu,brasil,#o patria amada!#
  dos filhos deste solo es mae gentil,#patria amada,#brasil!# 
  
  Na gera��o do arquivo texto, sempre que no texto de entrada for encontrado o 
  caractere #, deve ser gerada uma mudan�a de linha. Os caracteres # n�o dever�o 
  aparecer no arquivo texto gerado. 
  
  Contabilizar o n�mero de linhas gravadas no arquivo texto e apresentar esse total 
  na fun��o main, ao final do processamento.
  
  b) Fun��o: apresenta��o do conte�do de um arquivo texto, linha a linha, com a primeira 
  letra de cada linha em mai�sculas.
  
  Apresentar ao final do processamento, na fun��o main, o n�mero de linhas lidas do arquivo texto.
  Exemplo de texto listado a partir do arquivo texto:
  
  Gigante pela propria natureza,
  Es belo, es forte, impavido colosso,
  E o teu futuro espelha essa grandeza.
  Terra adorada,
  Entre outras mil,
  Es tu,brasil,
  O patria amada!
  Dos filhos deste solo es mae gentil,
  Patria amada,
  Brasil! 
  
  c) Fun��o: apresenta��o da primeira palavra de cada linha par de um arquivo texto. 
  Apresentar ao final do processamento, na main, o n�mero de linhas lidas do arquivo texto.
  Primeira palavra das linhas pares do arquivo exemplo:
  es
  terra
  es
  dos
  brasil! 
  
  - Contar n�mero de linhas -> apresentar em main
  - fazer # = '\n'
             
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAXLIN 81
#define MAXCHAR 31

char opcao_menu (void);
int insere_texto (int, int);
FILE *AbreArquivo (int, int);
int maiusculas (int, int);
int pares (int, int);

int main()
{   
    char cod;
    int linhas_gravadas, linhas_lidas;
    do
    {    
         cod = opcao_menu();
         fflush (stdin);
         if (cod =='I')
         {  
            linhas_gravadas = insere_texto (MAXLIN, MAXCHAR);
            printf ("\nLinhas gravadas: %d", linhas_gravadas);
         }
         if (cod =='M')  
         {
            linhas_lidas = maiusculas (MAXLIN, MAXCHAR);
            printf ("\nLinhas lidas: %d", linhas_lidas);
         }
         if (cod =='P')  
         {
            linhas_lidas = pares (MAXLIN, MAXCHAR);
            printf ("\nLinhas lidas: %d", linhas_lidas);
         }
         fflush (stdin);
         printf ("\n\n");
         system ("pause");
    } while (cod != 'F');
    return 0;
}

char opcao_menu()      //menu com as opera�oes
{    
     system ("CLS");
     printf ("O que deseja fazer?");
     printf ("\n- (I)nserir Texto");
     printf ("\n- Letras (M)aiusculas");
     printf ("\n- Linhas (P)ares");
     printf ("\n- (F)im");
     printf ("\nCodigo: ");
     return (toupper(getchar()));
}

FILE *AbreArquivo (int maxchar, int codigo)
{
	char nomearq[maxchar];
	if (!codigo)
	   printf("\nSalvar arquivo com o nome (Ex.: xxx.txt) (max de %d caracteres): ", maxchar - 1);
    else
       printf("\nAbrir arquivo com o nome (Ex.: xxx.txt) (max de %d caracteres): ", maxchar - 1); 
	fgets(nomearq, sizeof(nomearq), stdin);
    if (nomearq[strlen(nomearq) - 1] == '\n')
 	   nomearq[strlen(nomearq) - 1] = '\0';
	fflush(stdin);
	if (!codigo)
	   return fopen (nomearq, "w+");
    else
	   return fopen (nomearq, "r");
}

int insere_texto (int maxlin, int maxchar)
{
    FILE *arq;
    char linha[maxlin];
    int linhas_gravadas = 0, i;
    if (!(arq = AbreArquivo (maxchar, 0)))
       printf ("\nErro ao criar o arquivo de texto\n");
    else
    {
        printf("\nDigite quantas linhas de %d caracteres desejar:\n", maxlin - 1);
        printf ("\t>>> Como inserir: \n\n\t\ta) Formato: xxx#xxxx#xxx#x#");
        printf ("\n\t\t   Onde, x: caracteres e #: quebra de linha");
        printf ("\n\t\t   Apenas o caracter # ira gerar uma quebra de linha"); 
        printf ("\n\n\t\tb) Digite FIM no inicio de uma linha para parar\n\n");
        fgets (linha, sizeof(linha), stdin);
        if (linha[strlen(linha) - 1] == '\n')
           linha[strlen(linha) - 1] = '\0';
        while ((strcmp(linha, "FIM")))
        {
              for (i = 0; i < maxlin && linha[i] != '\0'; i++)
              {
                  if (linha[i] == '#')
                  {
                     putc ('\n', arq);
                     linhas_gravadas++;
                  }
                  else
                     putc (linha[i], arq);
              }
              fgets (linha, sizeof(linha), stdin);
              if (linha[strlen(linha) - 1] == '\n')
                 linha[strlen(linha) - 1] = '\0';
        }
    }
    fseek (arq, 0, SEEK_SET);
    printf ("\nTexto salvo:\n");
    fgets (linha, sizeof (linha), arq);
    while (!(feof(arq)))
    {
       printf ("%s", linha);
       fgets (linha, sizeof (linha), arq);
    }
    fclose (arq);
    return linhas_gravadas;  
}

int maiusculas (int maxlin, int maxchar)
{
    FILE *arq;
    char linha[maxlin];
    int linhas_lidas = 0;
    if (!(arq = AbreArquivo (maxchar, 1)))
       printf ("\nErro ao abrir o arquivo de texto\n");
    else
    {
        fgets (linha, sizeof(linha), arq);
        linha[0] = toupper(linha[0]);
        while (!(feof(arq)))
        {
              printf("%s", linha);
              linhas_lidas++;
              fgets (linha, sizeof (linha), arq);
              linha[0] = toupper(linha[0]);
        }
    }
    fclose (arq);
    return linhas_lidas;   
}

int pares (int maxlin, int maxchar)
{
    FILE *arq;
    char linha[maxlin];
    int linhas_lidas = 0, i;
    if (!(arq = AbreArquivo (maxchar, 1)))
       printf ("\nErro ao abrir o arquivo de texto\n");
    else
    {
        fgets (linha, sizeof(linha), arq);
        while (!(feof(arq)))
        {
              linhas_lidas++;
              if (!(linhas_lidas % 2))
              {
                 printf ("%s", strtok(linha, " "));
                 //ou
                 //for (i = 0; i < strlen(linha) && (linha[i] != ' '); i++)                
                     //printf ("%c", linha[i]);
                 printf ("\n\n");
              }
              fgets (linha, sizeof (linha), arq);
        }
    }
    fclose (arq);
    return linhas_lidas;   
}   















