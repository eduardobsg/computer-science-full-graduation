//Programa gerador do arquivo dados.txt

#include<stdio.h>
#include<stdlib.h>
#include<string.h> 

#define MAX 80

int main (  )
{
    FILE *arq;
    char nome[MAX];
    int num, op, res;
    float n1,n2,media;
    system("color 70");
    if (!(arq = fopen("dados.txt","w")))
    {     
          printf("\nErro abertura\n");
          system("pause");
    } 
    else
    {
       do   
       {          
           printf("\nNumero: ");
           scanf("%d", &num);
           printf("\nNome: ");
           fflush(stdin);   // limpa o buffer de entrada do teclado
           fgets(nome, sizeof(nome), stdin);
           if (nome[strlen(nome) - 1] == '\n')
              (nome[strlen(nome) - 1] = '\0');
           fflush(stdin);  
           printf("\nNota 1: ");
           scanf("%f", &n1);
           printf("\nNota 2: ");
           scanf("%f", &n2);
           // gravacao dos dados em dados.txt, na chamada de fprintf a seguir
           // observar a gravacao da virgula entre os valores - como delimitador
           fprintf (arq, "%d,%s,%f,%f,\n", num, nome, n1, n2);
           printf("\nseguir 1, parar 0\n");
           scanf("%d",&op  );
       } while (op); // enquanto usuario quiser continuar
       fclose(arq);
       return 0;
    }
}
