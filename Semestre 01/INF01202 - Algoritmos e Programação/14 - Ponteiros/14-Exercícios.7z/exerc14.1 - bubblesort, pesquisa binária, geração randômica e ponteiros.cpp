/*
  Name: exerc14.1 - bubblesort, pesquisa bin�ria e ponteiros
  Author: Jo�o Luiz Grave Gross
  Date: 09/05/09 15:17
  Description: 
               
  Usando exclusivamente ponteiros,  fa�a um  programa C  que  tenha  duas 
  op��es  de  processamento,  cada  uma  implementada  como  uma  fun��o  sem 
  retorno e sem par�metros. 
  
  Op��es de processamento: 
  1) Recebido  por  leitura  um  texto  com  at�  80  caracteres,  todo  em 
  min�sculas,  contendo  uma  ou mais  palavras  separadas  por um  ou 
  mais espa�os em branco, converter a primeira letra de cada palavra 
  de  min�scula  para  mai�scula.  Escrever  o  texto  original  e  o  texto 
  transformado. 

  2) Preencher  com  valores  rand�micos  (de  1  a  500)    um  vetor  de  50 
  posi��es. Escrever o vetor. Classificar o vetor em ordem crescente. 
  Escrever  novamente  o  vetor  classificado.  Ap�s,  at�  que  o  usu�rio 
  indique que deseja parar, para n valores  fornecidos,   informar se o 
  valor  se  encontra  ou  n�o  no  vetor.  As  pesquisas  sobre  o  vetor 
  ordenado dever�o ser realizadas utilizando pesquisa bin�ria. 
  
  Caracter�sticas do programa:
  - ter menu para o usu�rio escolher o que deseja fazer;
  - duas fun��es; cada uma desempenhando uma fun��o sem retorno;
  - fun��o 1: texto[80] (min�sculo) -> ler espa�o e colocar em mai�sculo a letra sequinte 
  ao espa�o
  - fun��o 2: vet[50] -> valores rand�micos (1 a 500) -> classificar em ordem crescente
  capturar valor e ver se est� no vetor (pesquia bin�ria)
  
  Condi��es de funcionamento:
  - Fun��o 1:
      O texto inserido N�O pode come�ar com espa�o
*/


#include <stdio.h>
#include <stdlib.h>
#include <time.h>         

#define MAX 50

void menu (void);
int inserttext (void);
int testavalor (void);

int main ()
{
    int codigo;
    long int ultime;
    
    time (&ultime);
    srand ((unsigned) ultime); 
    system("color f1");
    
    do
    {
        do
        {
            menu ();
            fflush(stdin);
            scanf ("%d", &codigo);
            if (codigo > 3 || codigo < 1)
               printf ("Codigo invalido!\n\n");
        } while (codigo > 3 || codigo < 1);
    
        switch (codigo)
        {
            case 1: inserttext();
                    break;
            case 2: testavalor();
                    break;
        }
    } while (codigo != 3);
    
    printf ("\n");
    system ("pause");
    return 0;
}

int testavalor (void)
{
    int vet[MAX], *pint = vet, *x;
    int aux, i, m, k, trocou, j;      //vari�veis do m�todo bubblesort
    int inf, sup, med, med2, val, achado;   //vari�veis do m�todo de pesquisa bin�rio
    
    printf ("\nVetor:\n");
    for (i = 0; i < MAX; i++, pint++)
    {
        *pint = 1 + rand() % 500;  //intervalo de 1 a 500
        printf ("%d  ", *pint);
    }
    
    //M�todo Bubblesort
    trocou = 1; 
    m = (MAX-1); 
    k = 1; 
    while (trocou)
    {
      trocou = 0;
      pint = vet;
      x = vet + 1;
      for (i = 0; i < m; i++, pint++, x++)
          if (*pint > *x)
          {       
             aux = *pint;      
             *pint = *x;    
             *x = aux;      
             k = i;      
             trocou = 1;
          }
      m = k;
    }
    printf ("\nVetor Ordenado: \n");
    for (i = 0, pint = vet; i < MAX; i++, pint++)
        printf ("%d  ", *pint);
    
    //Pesquisa Bin�ria    
    do
    {
        printf ("\n\nForneca o valor procurado: ");
        scanf ("%d", &val);
        inf = 0; 
        sup = MAX - 1; 
        achado = 1;
        while (inf <= sup && achado)
        {
           med = (inf + sup)/2;
           pint = vet + med;
           if (val == *pint)
           {
              printf ("Valor %d encontrado na posicao %d\n", val, med);
              med2 = med;
              do
              {
                 med2--;
                 pint = vet + med2;
                 if (val == *pint)
                    printf ("Valor %d encontrado na posicao %d\n", val, med2);
                 else
                    achado = 0;
              } while (achado);
              achado = 1;
              do
              {
                 med++;
                 pint = vet + med;
                 if (val == *pint)
                    printf ("Valor %d encontrado na posicao %d\n", val, med);
                 else
                    achado = 0;
              } while (achado);
           }
           else
              if (val > *pint)
                 inf = med + 1;
              else
                 sup = med - 1;
        }    
        if (achado)
           printf ("Valor %d nao encontrado !!!\n", val);        
        printf ("\nDeseja pesquisar um novo valor? (1 - sim, 0 - nao) ");
        scanf ("%d", &val);
    } while (val);       
    printf ("\n\n");
}

int inserttext (void)
{
    char texto[81] = {}; //garante que todas as posi��es tenham '\0'
    char *pchar = texto;
    int i, j;
    
    printf ("\nInsira uma frase de ate 80 caracteres: ");
    fflush(stdin);
    gets (texto);
    
    printf ("\nA frase digitada eh: \t%s", texto);
    printf ("\nTexto alterado: \t%c", *pchar - 32);
    for (pchar = texto + 1, i = 0, j = 0; i < 79; i++, pchar++)
    {
        if (*pchar == 32)
           j = 1;
        if (*pchar != 32 && j == 1)
        {
           j = 0;
           *pchar = *pchar - 32;  //transforma letra min�scula em mai�scula
        }   
        printf ("%c", *pchar);
    }
    printf ("\n");
}

void menu (void)
{
     printf ("O que deseja fazer a seguir?");   
     printf ("\n1 - inserir texto"); 
     printf ("\n2 - testar valor");
     printf ("\n3 - parar");  
     printf ("\nCodigo: ");
}
