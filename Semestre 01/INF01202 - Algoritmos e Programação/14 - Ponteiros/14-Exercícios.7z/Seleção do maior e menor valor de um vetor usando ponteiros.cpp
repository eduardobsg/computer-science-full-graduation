/*
  Name: 
  Author: Jo�o Luiz Grave Gross
  Date: 09/05/09 14:26
  Description: 
               
    Fa�a um programa que contenha o seguinte vetor como dado inicial: 
  int v [8] = {10,5,20,9,4,1,15,1}. A seguir, crie dois ponteiros 
  para inteiros que dever�o apontar para as posi��es do vetor v 
  que cont�m o maior elemento e o menor elemento. Ao final, imprima 
  o conte�do dos elementos apontados por esses ponteiros, que 
  corresponder�o ao menor e ao maior elemento do vetor (1 e 20).
*/

#include <stdio.h>
#include <stdlib.h>

int main ()
{
    int v[8] = {10,5,20,9,4,1,15,1}, *pmaior, *pmenor, i;
    
    printf("Vetor: \n");
    for(i=0; i < 8; i++)
             printf("%d ", v[i]);
    
    for (pmaior = pmenor = v, i = 0; i < 8; i++)
    {
        if (*pmaior < v[i])
           pmaior = &v[i];
        if (*pmenor > v[i])
           pmenor = &v[i];   
    }               
    
    printf ("\n\nMaior valor: %d\nMenor valor: %d\n", *pmaior, *pmenor);
    system ("pause");
    return 0;
}
