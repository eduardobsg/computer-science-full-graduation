#include <stdio.h>
#include <stdlib.h>

int main()
{
    float v[9] = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0}, *p;
    int i;
        
    for (p = &v[0]; p < (v + 9); p++)      //ou p = &v[0]
        printf("%.1f  ", *p);
    
    printf ("\n");   
    system("pause");
    return 0;
}



/* Outra solu��o 

#include <stdio.h>
#include <stdlib.h>

int main()
{
    float v[] = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0};
    int i;
    
    for (i=0; i<9; i++) 
        printf("%.1f ", *(v+i));

    system("pause");
}


*/
