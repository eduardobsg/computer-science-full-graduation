/*
  Name: exemplo16.1.cpp
  Author: Cida Souto.
  Date: 20/05/08 00:07
  Description: Definir um novo tipo bilhete e as respectivas fun��es que permitem ler e mostrar os dados de um bilhete.
*/

#include <stdio.h>
#include <stdlib.h>

typedef struct tipohorario
{
        int hora, min;
};
typedef struct tipodata
{
        int dia, mes, ano;
};
typedef struct tipobilhete
{
        int cod_e;
        char nome_p[20];
        char origem[20], destino[20];
        tipodata data_b;
        tipohorario horario_b;
        int assento;
        float valor;     
};

int main ()
{
     tipobilhete bilhete;
     system ("color 9f");
     printf ("\n\n>>> VIAJE BEM LTDA. <<<\n\n");
     printf ("\n>>> Lendo Dados <<<\n\n");
     printf ("Cod. da Empresa: \t\t");
     scanf ("%d", &bilhete.cod_e);
     fflush(stdin);
     printf ("Nome do Passageiro: \t\t");
     gets (bilhete.nome_p);
     printf ("Origem: \t\t\t");
     gets (bilhete.origem);
     printf ("Destino: \t\t\t");
     gets (bilhete.destino);
     printf ("Data do Bilhete (dd mm aa): \t");
     scanf ("%d%d%d", &bilhete.data_b.dia, &bilhete.data_b.mes, &bilhete.data_b.ano);
     printf ("Horario do Bilhete (hh mm): \t");
     scanf ("%d%d", &bilhete.horario_b.hora, &bilhete.horario_b.min);
     printf ("Assento: \t\t\t");
     scanf ("%d", &bilhete.assento);
     printf ("Valor do Bilhete: \t\t");
     scanf ("%f", &bilhete.valor);
     printf ("\n>>> Imprimindo Dados <<<\n\n");
     system ("pause"); 
     system ("cls");
     printf ("\n---------------------------------------------------------------------\n");
     printf ("  VIACAO VIAJEBEM                                                       \n");
     printf ("                                                                        \n"); 
     printf ("  Cod. Empresa: %4d            Nome do Passageiro: %s                   \n", bilhete.cod_e, 	bilhete.nome_p);
     printf ("  Origem: %s                   Destino: %s                              \n", bilhete.origem, 	bilhete.destino);
     printf ("  Data: %2d/%2d/%2d                Horario: %2d:%2d                         \n", 	bilhete.data_b.dia, bilhete.data_b.mes, bilhete.data_b.ano, bilhete.horario_b.hora, 	bilhete.horario_b.min);
     printf ("  Assento: %2d                   Valor do Bilhete: %5.2f                  \n", bilhete.assento, 	bilhete.valor);
     printf ("-----------------------------------------------------------------------\n\n");  
     system ("pause");     
}
