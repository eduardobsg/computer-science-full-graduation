/*
  Name: exerc16.16.cpp
  Author: Jo�o Luiz Grave Gross
  Date: 21/05/09 15:17
  Description: T�pico 16 � Estruturas: introdu��o
  
  Exerc�cio de Avalia��o � Entregar em: 30/05/2009
  
  Gravar a solu��o com o nome <seunumeroufrgs>.c
  
  1. Utilizando o recurso typedef, defina em C um novo tipo denominado clinvet, o qual
  deve corresponder ao cadastro de animais em uma Cl�nica Veterin�ria, que atende
  os clientes exclusivamente de Porto Alegre. A ficha cadastral de um animal e seu
  propriet�rio deve ter as seguintes informa��es:
  
  � Nome do animal � campo a ser definido como string de no m�ximo 15
  caracteres.
  
  � Esp�cie � campo a ser definido como char, o qual dever� aceitar somente os
  c�digos �c� e �f�, correspondentes, respectivamente, �s esp�cies caninas e
  felinas.
  
  � Ra�a (boxer, labrador, lhasa apso, persa, etc.) � campo a ser definido como
  string de no m�ximo 15 caracteres.
  
  � Data de nascimento � campo a ser definido como uma estrutura
  o Dia  o M�s  o Ano
  
  � Sexo � definir como um campo int, onde 1-macho e 2-f�mea.
  
  � Nome do propriet�rio - definido como string de no m�ximo 20 caracteres.
  
  � Logradouro do propriet�rio - definido como string de no m�ximo 15
  caracteres. (rua)
  
  � Complemento (n�mero e apartamento) - definido como string de no m�ximo
  20 caracteres.
  
  � Cep � definido como inteiro longo sem sinal ou, simplesmente, como um
  string de caracteres (na pr�tica acaba sendo o mais utilizado).
  
  � Telefone residencial do propriet�rio � idem Cep.
  
  � Telefone celular do propriet�rio � idem Cep.
  
  2. Carregue na estrutura definida no item 1 os dados relativos a um determinado 
  animal. Em seguida liste as informa��es do animal a partir da estrutura. 
  Repita essas a��es para tantos animais quantos o usu�rio queira, at� que o usu�rio 
  informe que deseja encerrar o processamento. 

  Criar estrutura "clinvet" -> cadastro veterin�rio de um animal
  char nome[16], raca[16], proprietario[21], rua[16], complemento[21], cep[10], tel_res[10], tel_cel[10];
  char especie;
  tipodata data;
  int sexo;
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main ()
{
    typedef struct tipodata
    {
            char dia[2], mes[2], ano[4];
    } tipo_data;
    
    typedef struct estrutura1
    {
            char nome[16], raca[16], proprietario[21], rua[16], complemento[21], cep[10], tel_res[10], tel_cel[10];
            char especie;
            tipo_data data;
            int sexo;
    } clinvet;
    
    clinvet cadastro;
    int codigo;
    
    do
    {
        printf ("Cadastro Veterinario\n");
        printf ("- Nome do Animal: ");
        fflush (stdin);
        fgets (cadastro.nome, sizeof(cadastro.nome), stdin);
          if (cadastro.nome[strlen(cadastro.nome) - 1] == '\n')
             cadastro.nome[strlen(cadastro.nome) - 1] = '\0';     
        printf ("- Raca: ");
        fflush (stdin);
        fgets (cadastro.raca, sizeof(cadastro.raca), stdin);
          if (cadastro.raca[strlen(cadastro.raca) - 1] == '\n')
             cadastro.raca[strlen(cadastro.raca) - 1] = '\0';
        printf ("- Especie (c - canina | f - felina): ");
        fflush (stdin);
        scanf ("%c", &cadastro.especie);
        printf ("- Data de nascimento (dd mm aaaa): ");
        fflush (stdin);
        scanf ("%s%s%s", cadastro.data.dia, cadastro.data.mes, cadastro.data.ano);
        do
        {
              printf ("- Sexo (1 - macho | 2 - femea): ");
              fflush (stdin);
              scanf ("%d", &cadastro.sexo);
              if (cadastro.sexo < 1 || cadastro.sexo > 2)
                 printf ("Valor invalido!\n");
        } while (cadastro.sexo < 1 || cadastro.sexo > 2);
        printf ("- Nome do Proprietario: ");
        fflush (stdin);
        fgets (cadastro.proprietario, sizeof(cadastro.proprietario), stdin);
          if (cadastro.proprietario[strlen(cadastro.proprietario) - 1] == '\n')
             cadastro.proprietario[strlen(cadastro.proprietario) - 1] = '\0';
        printf ("- Endereco\n\tRua: ");
        fflush (stdin);        
        fgets (cadastro.rua, sizeof(cadastro.rua), stdin);
          if (cadastro.rua[strlen(cadastro.rua) - 1] == '\n')
             cadastro.rua[strlen(cadastro.rua) - 1] = '\0';
        printf ("\tComplemento: ");
        fflush (stdin);        
        fgets (cadastro.complemento, sizeof(cadastro.complemento), stdin);
          if (cadastro.complemento[strlen(cadastro.complemento) - 1] == '\n')
             cadastro.complemento[strlen(cadastro.complemento) - 1] = '\0';        
        printf ("- Cep (xxxxx-xxx): ");
        fflush (stdin);        
        fgets (cadastro.cep, sizeof(cadastro.cep), stdin);
          if (cadastro.cep[strlen(cadastro.cep) - 1] == '\n')
             cadastro.cep[strlen(cadastro.cep) - 1] = '\0';          
        printf ("- Telefone Residencial (xxxx-xxxx): ");
        fflush (stdin);            
        fgets (cadastro.tel_res, sizeof(cadastro.tel_res), stdin);
          if (cadastro.tel_res[strlen(cadastro.tel_res) - 1] == '\n')
             cadastro.tel_res[strlen(cadastro.tel_res) - 1] = '\0';              
        printf ("- Telefone Celular (xxxx-xxxx): ");
        fflush (stdin);                
        fgets (cadastro.tel_cel, sizeof(cadastro.tel_cel), stdin);
          if (cadastro.tel_cel[strlen(cadastro.tel_cel) - 1] == '\n')
             cadastro.tel_cel[strlen(cadastro.tel_cel) - 1] = '\0';         
        
        //Impress�o
        printf ("\n\nFicha cadastral do bichano\n");
        printf ("- Nome do Animal: %s\n", cadastro.nome);
        printf ("- Raca: %s\n", cadastro.raca);
        printf ("- Especie: %c\n", cadastro.especie);
        if (cadastro.sexo == 1)
           printf ("- Sexo: macho\n");
        else
           printf ("- Sexo: femea\n");
        printf ("- Nome do Proprietario: %s\n", cadastro.proprietario);
        printf ("- Endereco\n\tRua: %s\n", cadastro.rua);
        printf ("\tComplemento: %s\n", cadastro.complemento);
        printf ("- Cep: %s\n", cadastro.cep);
        printf ("- Telefone Residencial: %s\n", cadastro.tel_res);
        printf ("- Telefone Celular: %s", cadastro.tel_cel);
        
        printf ("\n\nNovo cadastro? (1 - sim | 0 - nao)\n");
        do
        {
               fflush (stdin);
               printf ("Codigo: ");
               scanf ("%d", &codigo);
               if (codigo > 1 || codigo < 0)
                 printf ("Codigo invalido!\n");
        } while (codigo > 1 || codigo < 0);
    } while (codigo);
        
    printf ("\n\n");
    system ("pause");
    return 0;
}


















