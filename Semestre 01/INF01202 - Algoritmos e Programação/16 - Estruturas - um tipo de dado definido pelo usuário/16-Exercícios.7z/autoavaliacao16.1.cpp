/*
  Name: autoavaliacao16.1
  Author: Jo�o Luiz Grave Gross
  Date: 21/05/09 15:00
  Description: Auto Avalia��o 16.1: enunciado 

  Aten��o: realizar o exerc�cio sem fun��es. 

  Utilizando o recurso typedef, fazer um programa em C que crie uma estrutura 
  com os seguintes campos: 

  Nome do Bolsista (string[30]) 
  C�digo do bolsista (inteiro entre 1 e 150) 
  Valor da bolsa (real) 
  
  O programa deve apropriar os dados de bolsistas nessa estrutura tantas vezes 
  quantas o usu�rio solicitar e em seguida apresentar o conte�do (l� e apresenta, 
  l� e apresenta, e assim sucessivamente). 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct bolsista
{
        char nome[30];
        int cod;
        float valor_bolsa;
};

int main ()
{
    bolsista bolsa;
    int i;
    
    do
    {
        printf ("Nome do bolsista: ");
        fflush (stdin);
        gets (bolsa.nome);
        do
        {
             printf ("Codigo do bolsista: ");
             scanf ("%d", &bolsa.cod);
             if (bolsa.cod < 1 || bolsa.cod > 150)
                printf ("Codigo invalido!\n");
        } while (bolsa.cod < 1 || bolsa.cod > 150);        
        do
        {
             printf ("Valor da bolsa: ");
             scanf ("%f", &bolsa.valor_bolsa);
             if (bolsa.valor_bolsa <= 0)
                printf ("Valor invalido!\n");
        } while (bolsa.valor_bolsa <= 0);
        printf ("\n\nInformacoes do bolsista: \n");
        printf ("Nome do bolsista: %s\n", bolsa.nome);
        printf ("Codigo do bolsista: %d\n", bolsa.cod);
        printf ("Valor da bolsa: %.2f\n", bolsa.valor_bolsa);
        do
        {
             printf ("\nDeseja inserir novos dados? (1 - sim | 0 - nao) ");
             scanf ("%d", &i);
             if (i < 0 || i > 1)
                printf ("Codigo invalido!");
        } while (i < 0 || i > 1);  
        printf ("\n");     
    } while (i);
    
    printf ("\n\n");
    system ("pause");
    return 0;
}
