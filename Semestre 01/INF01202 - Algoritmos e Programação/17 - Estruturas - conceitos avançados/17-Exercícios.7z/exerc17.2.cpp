/*
  Name: 
  Author: Jo�o Luiz Grave Gross
  Date: 03/06/09 20:46
  Description: 
               
  Os dados relativos a 50 produtos comercializados em uma papelaria devem ser armazenados 
  em um arranjo cujos elementos correspondam � estrutura tipo produto (a seguir).

  Fazer um programa em C para preencher o arranjo com dados e listar seu conte�do.

  Usar no programa as seguintes defini��es:

  #define MAXDIAS 3 // nao alterar
  #define MAXPROD 2 // variavel em tempo de teste

  struct data
  {
         int dia;

 int mes;

 int ano;

 };

struct produto

 {

 int codigo;

 char tipo; // valores validos: p � pequeno, m � medio, g - grande

 struct data data_compra;

 float media;

 float vol_vendas[MAXDIAS]; //volume de vendas de tres dias

 };

   O programa dever� ler por ordem crescente de c�digo (1 a n) os dados dos produtos. 
   
   Os c�digos n�o precisam ser lidos, mas devem ser armazenados na estrutura. Dever�o 
ser consistidos quanto � corre��o apenas o campo tipo e vol_vendas (que n�o poder� ser negativo).

    data_compra armazenar� a data em que a �ltima partida do produto foi adquirida.

    Em vol_vendas ser�o armazenados os totais, em reais, das vendas dos produtos da papelaria em 
tr�s dias (quaisquer, escolhidos pelo usu�rio) da semana anterior ao processamento. Ser�o fornecidos 
j� totalizados os volumes de vendas dos produtos, por dia da semana.

   Ap�s o preenchimento do arranjo com dados dos produtos, calcular a m�dia de vendas da semana para 
cada produto. E ap�s apresentar um relat�rio com os dados de todos os produtos (c�digo e m�dia inclusive).

Cada uma das tarefas a seguir dever� ser desenvolvida sobre forma de fun��o, usando apenas par�metros e vari�veis locais:

� leitura dos dados;

� c�lculo da m�dia;

� apresenta��o do relat�rio.

Uma fun��o pelo menos dever� utilizar a nota��o *( ) e uma pelo menos a nota��o -> (operador seta).   

    Estrutura:
    - vol_vendas: valor em reais n�o negativo
              
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAXDIAS 3 // nao alterar
#define MAXPROD 2 // variavel em tempo de teste

struct data
{
       int dia;
       int mes;
       int ano;
};

struct produto
{
       int codigo;
       char tipo; //valores validos: p � pequeno, m � medio, g - grande
       struct data data_compra;
       float media;
       float vol_vendas[MAXDIAS]; //volume de vendas de tres dias
};

void le_dados (produto []);

int main ()
{
    produto produtos[MAXPROD];
    long int ultime;
    time (&ultime);
    srand ((unsigned) ultime); 
    
    le_dados(produtos);
    
    printf ("\n\n");
    system ("pause");
    return 0;
}

void le_dados (produto produtos [])
{
     int i, j;
     printf ("Preencha o que eh pedido");
     for (i = 0; i < 2; i++)
     {
         printf ("\n\nCadastro %d:", i+1);
         (produtos + i)->codigo = (rand() % 10001) + 1000; //ou produto->codigo[i]
         do
         {
             printf ("\nTipo (p-pequeno | m-medio | g-grande): ");
             fflush (stdin);
             scanf("%c", &(produtos + i)->tipo);
             if (produtos[i].tipo != 'p' && produtos[i].tipo != 'm' && produtos[i].tipo != 'g')
                printf("Tipo invalido!");
         } while (produtos[i].tipo != 'p' && produtos[i].tipo != 'm' && produtos[i].tipo != 'g');
         printf ("Data da compra (dd mm aa): ");
         scanf ("%d%d%d", &(produtos + i)->data_compra.dia, &(produtos + i)->data_compra.mes, &(produtos + i)->data_compra.ano); 
         for (j = 0; j < MAXDIAS; j++)
         {
             printf ("Volume de vendas (dia %d): ", j+1);
             scanf ("%f", &(produtos + i)->vol_vendas[j]);
         }
     }
     
     for (i = 0; i < 2; i++)
     {
         printf ("\n\nCadastro %d:", i+1);
         printf ("\nCodigo: %d", (produtos + i)->codigo);
         printf ("\nTipo: ", (produtos + i)->tipo);
         switch ((produtos + i)->tipo)
         {
                case 'p': printf("pequeno");
                          break;
                case 'm': printf("medio ");
                          break;
                case 'g': printf("grande ");
                          break;
}
         printf ("\nData da compra: %d %d %d", (produtos + i)->data_compra.dia, (produtos + i)->data_compra.mes, (produtos + i)->data_compra.ano); 
         for (j = 0; j < MAXDIAS; j++)
             printf ("\nVolume de vendas (dia %d): %.f", j+1, (produtos + i)->vol_vendas[j]);
     }
     
}


















