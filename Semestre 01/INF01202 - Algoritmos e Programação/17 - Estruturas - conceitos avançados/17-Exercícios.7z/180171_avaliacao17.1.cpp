/*
  Name: 180171_avaliacao17.1 - 
  Author: Jo�o Luiz Grave Gross
  Date: 04/06/09 13:47
  Description: 
               
  Problema:
    
  Implemente um programa C para gerar o Boletim de Desempenho dos candidatos ao
concurso p�blico do Centro de Processamento de Dados do Senado, Edital No. 007/2009,
para preencher as vagas de:
    
    � Analista de Sistemas (inicial de R$ 9.700,00);
    � Programador Java (inicial de R$ 3.800,00);
    � Administrador de Banco de Dados (inicial de R$ 7.580,00).
  
  Os candidatos dever�o realizar 5 provas, cada uma com 30 quest�es objetivas:
    
    � Portugu�s
    � Ingl�s
    � Matem�tica
    � Conhecimentos gerais de inform�tica
    � Racioc�nio l�gico.
    
  Detalhamento:
                 
    1. Criar um tipo estrutura (tipo_candidato) com os seguintes campos:
    � Nome do candidato � campo a ser definido como string de no m�ximo 25
    caracteres.
    � RG � campo a ser definido como string, com 10 caracteres.
    � Data de nascimento do candidato � campo a ser definido como uma estrutura
    o Dia
    o M�s
    o ano
    � Provas � arranjo de 5 elementos, o qual deve armazenar os escores brutos de
um candidato em cada uma das provas. Vamos considerar que a posi��o
destes escores neste arranjo, a partir da primeira, correspondem
respectivamente, �s provas de portugu�s, ingl�s, matem�tica, etc.
    
    2. Criar um arranjo de estruturas tipo tipo_candidato, com MAXCANDIDATOS = 5, por
exemplo.   
    
    3. Implemente a fun��o lecandidatos (candidato *, int), onde o primeiro par�metro
corresponde ao endere�o da estrutura e o segundo ao n�mero de candidatos, e cujo
prop�sito � permitir a adi��o dos dados de um novo candidato ao arranjo de
candidatos.          

    4. Implemente a fun��o geraboletim (candidato *, int), cujo prop�sito � permitir a
emiss�o dos Boletins de Desempenho de todos os candidatos.

    5. O Boletim de Desempenho dever� conter as seguintes informa��es:

    Informa��o Interpreta��o
    
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAXCANDIDATOS 5

typedef struct data_nascimento
{
       int dia, mes, ano;
} nascimento;

typedef struct tipo_candidato
{
       char nome[26], rg[11];
       nascimento data;
       int provas[5];
} candidato;

void lecandidatos (candidato [], int);
void geraboletim (candidato [], int);
void media_b (candidato [], int, double []);
void desvio_p (candidato [], int, double [], double [], double []);
void escore_padronizado (candidato [], int, double [], double [], double [MAXCANDIDATOS][5]);
void media_hamonica (double *, int);

int main ()
{
    candidato candidatos[MAXCANDIDATOS];
    double nova_media[MAXCANDIDATOS], media_bruta[MAXCANDIDATOS], desvio_padrao[MAXCANDIDATOS], escore_padro[MAXCANDIDATOS][5];
    printf ("CONCURSO PUBLICO do CPDS, Edital No. 007/2009:");
    
    lecandidatos (candidatos, MAXCANDIDATOS);
    geraboletim (candidatos, MAXCANDIDATOS);
    media_b (candidatos, MAXCANDIDATOS, media_bruta);
    desvio_p (candidatos, MAXCANDIDATOS, media_bruta, nova_media, desvio_padrao);   
    escore_padronizado (candidatos, MAXCANDIDATOS, nova_media, desvio_padrao, escore_padro);
    media_hamonica (escore_padro[0], MAXCANDIDATOS);
    
    printf ("\n\n");
    system ("pause");
    return 0;
}

void lecandidatos (candidato candidatos[], int n_candidatos)
{
     int i, j;
     printf ("\n\nPreencha os dados dos candidatos\n");
     for (i = 0; i < n_candidatos; i++)
     {
         printf ("\nCandidato %d", i+1);
         printf ("\nNome: ");
         fflush (stdin);
         fgets ((candidatos + i)->nome, sizeof ((candidatos + i)->nome), stdin);
         if ((candidatos + i)->nome[strlen((candidatos + i)->nome) - 1] == '\n')
               (candidatos + i)->nome[strlen((candidatos + i)->nome) - 1] = '\0';
         printf ("RG: ");
         fflush (stdin);
         fgets ((candidatos + i)->rg, sizeof ((candidatos + i)->rg), stdin);
         if ((candidatos + i)->rg[strlen((candidatos + i)->rg) - 1] == '\n')
               (candidatos + i)->rg[strlen((candidatos + i)->rg) - 1] = '\0';
         printf ("Data de nascimento (dd mm aa): ");
         scanf ("%d%d%d", &(candidatos + i)->data.dia, &(candidatos + i)->data.mes, &(candidatos + i)->data.ano);
         printf ("Provas (de 0 a 30 acertos):\n");
         for (j = 0; j < 5; j++)
         {
             do
             {
                if (j == 0)
                   printf ("\tPortugues: ");
                if (j == 1)
                   printf ("\tIngles: ");
                if (j == 2)
                   printf ("\tMatematica: ");             
                if (j == 3)
                   printf ("\tInformatica: ");
                if (j == 4)   
                   printf ("\tRaciocinio Logico: ");             
                scanf ("%d", &(candidatos + i)->provas[j]);
                if ((candidatos + i)->provas[j] < 0 || (candidatos + i)->provas[j] > 30)
                   printf ("\t\tValor invalido! (de 0 a 30)\n");
             } while ((candidatos + i)->provas[j] < 0 || (candidatos + i)->provas[j] > 30);   
         }
     }
}

void geraboletim (candidato candidatos [], int n_candidatos)
{
     int i, j;
     printf ("\n\nBoletim de desempenho dos candidatos");
     for (i = 0; i < n_candidatos; i++)
     {
         printf ("\n\nCandidato %d", i+1);
         printf ("\nNome: %s", (candidatos + i)->nome);
         printf ("\nRG: %s", (candidatos + i)->rg);
         printf ("\nData de nascimento (dd mm aa): %d %d %d", (candidatos + i)->data.dia, (candidatos + i)->data.mes, (candidatos + i)->data.ano);
         printf ("\nProvas (de 0 a 30 acertos): ");
         for (j = 0; j < 5; j++)
         {
                if (j == 0)
                   printf ("\n\tPortugues: %d", (candidatos + i)->provas[j]);
                if (j == 1)
                   printf ("\n\tIngles: %d", (candidatos + i)->provas[j]);
                if (j == 2)
                   printf ("\n\tMatematica: %d", (candidatos + i)->provas[j]);             
                if (j == 3)
                   printf ("\n\tInformatica: %d", (candidatos + i)->provas[j]);
                if (j == 4)   
                   printf ("\n\tRaciocinio Logico: %d", (candidatos + i)->provas[j]);             
         }
     }
}

void media_b (candidato candidatos [], int numero_cand, double media_bruta [])
{
     int i, j;
     printf ("\n\nMedia Bruta: ");
     for (i = 0; i < 5; i++)
     {
         media_bruta[i] = 0;
         for (j = 0; j < numero_cand; j++)
             media_bruta[i] += (candidatos + j)->provas[i]; 
         media_bruta[i] /= numero_cand;
         if (i == 0)
            printf ("\n\tPortugues: %.3lf", media_bruta[i]);
         if (i == 1)
            printf ("\n\tIngles: %.3lf", media_bruta[i]);
         if (i == 2)
            printf ("\n\tMatematica: %.3lf", media_bruta[i]);             
         if (i == 3)
            printf ("\n\tInformatica: %.3lf", media_bruta[i]);
         if (i == 4)   
            printf ("\n\tRaciocinio Logico: %.3lf", media_bruta[i]); 
     }
}

void desvio_p (candidato candidatos [], int numero_cand, double media_bruta [], double nova_media [], double desvio_padrao [])
{
     int i, j;
     double soma_dif_media; //soma das diferen�as entre os escores das provas e a m�dia 
     printf ("\n\nDesvio Padrao:");  
     for (i = 0; i < 5; i++)
     {
         nova_media[i] = media_bruta[i];
         soma_dif_media = 0;
         for (j = 0; j < numero_cand; j++)
             soma_dif_media += pow (((candidatos + j)->provas[i] - *(media_bruta + i)), 2);
         desvio_padrao[i] = sqrt (soma_dif_media / (numero_cand - 1));    
         if (i == 0)
            printf ("\n\tPortugues: %.3lf", desvio_padrao[i]);
         if (i == 1)
            printf ("\n\tIngles: %.3lf", desvio_padrao[i]);
         if (i == 2)
            printf ("\n\tMatematica: %.3lf", desvio_padrao[i]);             
         if (i == 3)
            printf ("\n\tInformatica: %.3lf", desvio_padrao[i]);
         if (i == 4)   
            printf ("\n\tRaciocinio Logico: %.3lf", desvio_padrao[i]); 
         //problema: media_bruta � alterada nos campos de i = 2, 3 e 4 ap�s sair do la�o for
         //motivo: mist�rio
         //solu��o: declara��o da vari�vel nova_media, que copia os campos de media_bruta
     } 
}

void escore_padronizado (candidato candidatos [], int numero_cand, double media_bruta [], double desvio_padrao [], double escore_padro[][5])
{
     //Para o escore padronizado funcionar o desvio padr�o precisa ser maior que zero, ou seja, as notas dos candidatos em uma mesma prova n�o podem ser iguais
     int i, j, k;
     printf ("\n\nEscores Padronizados:\n");
     for (i = 0, k = 0; i < numero_cand; i++)
     {
         printf ("\nCandidato %d:", i + 1); 
         for (j = 0; j < 5; j++)
         {
             escore_padro[i][j] = (((candidatos + i)->provas[j] - media_bruta[j]) * 100) / desvio_padrao[j] + 500;             
             if (j == 0)
                printf ("\n\tPortugues: %.3lf", escore_padro[i][j]);
             if (j == 1)
                printf ("\n\tIngles: %.3lf", escore_padro[i][j]);
             if (j == 2)
                printf ("\n\tMatematica: %.3lf", escore_padro[i][j]);             
             if (j == 3)
                printf ("\n\tInformatica: %.3lf", escore_padro[i][j]);
             if (j == 4)   
                printf ("\n\tRaciocinio Logico: %.3lf\n", escore_padro[i][j]); 
         }
     } 
}

void media_hamonica (double *escore_padro, int numero_cand)
{
     int i, j, k;
     double somatorio;     
     for (i = 0, k = 0; i < numero_cand; i++)
     {
         somatorio = 0;
         printf ("\nCandidato %d: ", i + 1); 
         for (j = 0; j < 5; j++)
         {
             somatorio += 1 / *(escore_padro + k);
             k++;
         }
         somatorio = 5 / somatorio;
         printf ("%.3lf", somatorio);
     } 
}












