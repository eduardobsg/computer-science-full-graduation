#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main ()
{
     int i, j;
     double desvio_padrao[2], media_bruta[2] = {10, 20}, provas[5][2] = {{12, 23}, {13, 24}, {21, 24}, {14, 18}, {21, 30}};
     double soma_dif_media, desvio; //soma das diferen�as entre os escores das provas e a m�dia 
     printf ("\n\nDesvio Padrao:");
     for (i = 0; i < 5; i++)
     {
         soma_dif_media = 0;
         for (j = 0; j < 2; j++)
             soma_dif_media += pow ((provas[i][j] - media_bruta[i]), 2);
         desvio = soma_dif_media / 1;
         desvio_padrao[i] = sqrt (desvio);
//         desvio_padrao[i] = pow ((soma_dif_media / (numero_cand - 1)), (1/2));    
         if (i == 0)
            printf ("\n\tPortugues: %.3lf", desvio_padrao[i]);
         if (i == 1)
            printf ("\n\tIngles: %.3lf", desvio_padrao[i]);
         if (i == 2)
            printf ("\n\tMatematica: %.3lf", desvio_padrao[i]);             
         if (i == 3)
            printf ("\n\tInformatica: %.3lf", desvio_padrao[i]);
         if (i == 4)   
            printf ("\n\tRaciocinio Logico: %.3lf", desvio_padrao[i]); 
     } 
     
     system ("pause");
}
