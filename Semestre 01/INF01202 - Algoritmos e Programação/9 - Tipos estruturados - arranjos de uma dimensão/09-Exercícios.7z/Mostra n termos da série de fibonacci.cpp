//Mostra n termos da s�rie de fibonacci

#include<stdlib.h>
#include<stdio.h>

int main ()
{
    char v1[20];
    int n, i, j, num1=1, num2=1, soma, flag1=1, flag2;
    while (flag1)
    {
       printf ("Digite a quantidade de termos (de 1 a 19): ");
       scanf ("%d",&n);
       flag2 = 1;
       if (n < 1 || n > 19)
       {
          printf ("Valor invalido. Tente novamente.\n");
          flag2=0;
       }
       else
          if (n == 1)
          {
             v1[0] = 1;
             printf ("\nSerie de Fibonacci:\n1 ");
             flag2 = 0; 
          }
          else
              if (n == 2)
              {
                 v1[0] = 1;
                 v1[1] = 1;  
                 printf ("\nSerie de Fibonacci:\n1 1");
                 flag2 = 0;    
              }
              else 
              {
                 v1[0] = 1;
                 v1[1] = 1;  
                 printf ("\nSerie de Fibonacci:\n1 1");
                 i = 2;
              }
       j = n - 2;
       while (flag2 && j > 0)
       {
          soma = num1 + num2;
          num1 = num2;
          num2 = soma;
          printf (" %d", soma);
          v1[i] = soma;         
          i++;
          j--;
       }
       printf ("\n");
       flag1 = 0;
    }
    for (i = 0; i < n; i++)
        printf ("%d ", v1[i]);
    system("pause");
    return 0;
}
