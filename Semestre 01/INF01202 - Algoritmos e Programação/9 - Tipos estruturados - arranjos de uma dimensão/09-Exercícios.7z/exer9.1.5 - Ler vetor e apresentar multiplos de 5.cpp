/*
  Name: exerc9.1.5 - Ler vetor e apresentar multiplos de 5
  Author: Jo�o Luiz Grave Gross
  Date: 26/03/09 13:54
  Description: Ler um vetor e apresent�-lo. Na seq��ncia contar os valores 
  m�ltiplos de 5, apresentar esses valores e o total calculado.
*/

#include<stdlib.h>
#include<stdio.h>
#define MAX 5

int main ()
{
    int vetor[MAX], var_teste, i, cont=0;
    for (i=0; i < MAX; i++)
    {
        printf ("Digite um valor inteiro: ");
        scanf ("%d",&vetor[i]);
        var_teste = vetor[i] / 5;
        var_teste *= 5;
        if (var_teste == vetor[i])
           cont++;
    }    
    printf ("\n");
    printf ("Valores digitados: \n");
    for (i=0; i < MAX; i++)
        printf ("Valor %d: %d\n", (i+1), vetor[i]);
    printf ("\nNumero de multiplos de 5: %d\n\n", cont);
    printf ("Multiplos de 5: \n");
    for (i=0; i < MAX; i++) 
    {
        var_teste = vetor[i] / 5;
        var_teste *= 5;
        if (var_teste == vetor[i])
           printf ("Valor %d: %d\n", (i+1), vetor[i]);
    }
    system ("pause");
    return 0;
}
