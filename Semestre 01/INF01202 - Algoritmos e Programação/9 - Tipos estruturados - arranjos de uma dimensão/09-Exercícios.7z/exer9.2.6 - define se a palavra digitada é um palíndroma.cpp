/*
  Name: exer9.2.6 - define se a palavra digitada � um pal�ndroma
  Author: Jo�o Luiz Grave Gross
  Date: 29/03/09 14:22
  Description: Resolver atrav�s de um programa em C se um dado (lido de teclado)
  string pal � ou n�o uma pal�ndroma. Exemplos de pal�ndroma:
  12321 , ovo, arara, ...

  # N�mero par de caracteres:
  Palavra: esse
  1) N�mero de caracteres = 4 -> 4/2 = 2 -> segundo caractere (nome[1])
  2) 2+1 = 3 -> terceiro caractere (nome[2])
  3) compara nome[1] com nome[2]
  4) compara nome[1-1] e nome[2+1], ou seja, nome[0] com nome[3]
  5) se forem iguais -> palavra � um pal�ndroma
  
  # N�mero �mpar de caracteres:
  Palavra: arara
  1) N�mero de caracteres = 5 -> 5/2 = 2 -> segundo caractere (nome[1])
  2) 2+2 = 4 -> quarto caractere (nome[3])
  3) compara nome[1] com nome[3]
  4) compara nome[1-1] e nome[3+1], ou seja, nome[0] com nome[4]
  5) se forem iguais -> palavra � um pal�ndroma
*/

#include<stdlib.h>
#include<stdio.h>
#include<string.h>

int main ()
{
    char palavra[10];
    int n, i, flag=1;
    printf ("Digite uma palavra: ");
    gets(palavra);
    n = strlen(palavra);
    if (n % 2)
       n = 1;                                 //se (n % 2 == 1) a palavra tem n�mero �mpar de caracteres
    else
       n = 0;
    switch (n)
    {
           //Par
           case 0: n = (strlen(palavra) / 2) - 1;
                   i = n + 1;
                   while (flag)
                   {
                       if (palavra[n] == palavra[i])
                       {
                          if (n == 0)
                          {
                             flag = 0;            
                             printf ("A palavra \"%s\" eh um palindroma!\n\n", palavra);
                          }
                          n--;
                          i++;
                       }     
                       else
                       {
                          printf ("A palavra \"%s\" nao eh um palindroma!\n\n", palavra);
                          flag = 0;  
                       }    
                   }
                   break;      
           //�mpar        
           case 1: n = (strlen(palavra) / 2) - 1;
                   i = n + 2;
                   while (flag)
                   {
                       if (palavra[n] == palavra[i])
                       {
                          if (n == 0)
                          {
                             flag = 0;            
                             printf ("A palavra \"%s\" eh um palindroma!\n\n", palavra);
                          }
                          n--;
                          i++;
                       }     
                       else
                       {
                          printf ("A palavra \"%s\" nao eh um palindroma!\n\n", palavra);
                          flag = 0;  
                       }    
                   }
                   break;      
    }
    system("pause");
    return 0;    
}



