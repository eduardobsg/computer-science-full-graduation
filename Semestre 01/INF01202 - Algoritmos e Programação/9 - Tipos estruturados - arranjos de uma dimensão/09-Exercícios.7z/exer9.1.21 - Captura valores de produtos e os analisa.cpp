/*
  Name: 9.1.21 - Captura valores de produtos e os analisa
  Author: Jo�o Luiz Grave Gross
  Date: 03/04/09 12:51
  Description: Uma empresa vende 30 artigos. Cada artigo � identificado por um c�digo e os
  artigos possuem pre�os variados. Usando vari�veis indexadas para armazenar
  estas informa��es, determine:
  a) o c�digo e o pre�o dos tr�s artigos mais caros;
  b) m�dia dos pre�os destes artigos;
  a) quais os c�digos dos artigos com pre�o superior � m�dia.
  
  preco_artigos[MAX]
  cod_artigos[MAX]
  artigos_caros[4]
  media
  1) Capturar a entrada dos MAX valores e c�digos
  2) Armazena os 3 artigos mais caros no vetor artigos_caros -> exib�-los
  3) Calcula a m�dia dos MAX artigos -> exibir m�dia
  4) testar todos os valores de perco_artigos -> valores maiores que a m�dia devem ter seu c�digo exibido
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 10

int main ()
{
    float preco_artigos[MAX], preco2[MAX], artigos_caros[4],  media = 0, valor = 0;
    int cod_artigos[MAX], i, j, k;
    for (i = 0; i < MAX; i++)
    {
        printf ("(%d) Informe o preco do produto: ", (i+1));
        scanf ("%f", &preco_artigos[i]);
        if (preco_artigos[i] <= 0)
        {
           printf ("Preco invalido!!\n");
           i--;
        }
        else 
        {  
           printf ("(%d) Informe o codigo: ", (i+1));
           scanf ("%d", &cod_artigos[i]);  
           printf ("\n");
        }
    }
    printf ("Valores inseridos\n");
    for (i = 0; i < MAX; i++)
    {
        printf ("(%d) Preco: %.2f\tCodigo: %d\n", (i+1), preco_artigos[i], cod_artigos[i]);
        preco2[i] = preco_artigos[i];
        media = media + preco_artigos[i];         //calcula a soma de todos os precos
    }
    
    //Calcula M�dia dos pre�os:
    media = media / MAX; 
    //Mostra os pre�os maiores que a m�dia
    printf ("\nMedia = %.2f\n", media);
    for (i = 0; i < MAX; i++)
        if (preco_artigos[i] > media)
           printf ("(%d) Preco: %.2f\tCodigo: %d\n", (i+1), preco_artigos[i], cod_artigos[i]);              
    
    //3 valores maiores    
    for (j = 0; j < 3; j++)
    {
        for (i = 0; i < MAX; i++)    
            if (valor < preco2[i])
            {
               valor = preco2[i];
               k = i;
            }
        artigos_caros[j] = valor;
        valor = 0;
        preco2[k] = 0;
    }     
    printf ("\nTres maiores precos: ");
    for (i = 0; i < 3; i++)        
        printf ("%.2f  ", artigos_caros[i]);          
    printf ("\n\n");    
    system ("pause");
    return 0;
}
