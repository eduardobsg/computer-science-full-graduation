/*
  Name: exer9.1.6 - Mostrar m�dia e numero dos alunos
  Author: Jo�o Luiz Grave Gross
  Date: 26/03/09 14:06
  Description: Ler e armazenar em dois vetores os n�meros e as notas de uma 
  turma de alunos. Calcular a m�dia da turma e apresentar o n�mero dos alunos 
  com nota final inferior � m�dia, bem como os dois vetores lidos.
  
  Sa�da: n�mero do aluno, nota final inferior � m�dia, dois vetores lidos, 
  media da turma
*/

#include<stdlib.h>
#include<stdio.h>
#define MAX 5

int main ()
{
    int numero[MAX], i;
    float media[MAX], media_turma=0;
    for (i=0; i < MAX; i++)
    {
        printf ("Digite o numero do aluno: ");
        scanf ("%d",&numero[i]);
        printf ("Digite a media do aluno: ");
        scanf ("%f",&media[i]);
        media_turma += media[i];
        if (media[i] < 0 || media[i] > 10)
        {
           printf ("\nAVISO: media menor que 0 ou maior do que 10!\n\n");
           i--;
           media_turma -= media[i];
        }
    }    
    printf ("\n");
    printf ("Numero e media dos alunos: \n");
    for (i=0; i < MAX; i++)
        printf ("Numero: %d\tMedia: %.f\n", numero[i], media[i]);
    for (i=0; i < MAX; i++) 
        if (media[i] < 6)
           printf ("Aluno numero %d reprovado.\nMedia: %.f\n", numero[i], media[i]);
    system ("pause");
    return 0;
}
