/*
  Name: exer9.9 - Captura e apresenta��o de strings
  Author: Jo�o Luiz Grave Gross
  Date: 31/03/09 12:27
  Description: Exerc�cio de Avalia��o 9.9
  
  Fazer um programa em C que solicite o nome completo de um usu�rio (Nome e o 
  Sobrenome) e o apresente na telinha como Sobrenome, Nome e C�digo. 

  C�digo � uma string que ser� uma transforma��o a partir do nome do usu�rio, 
  conforme a regra: substituir todos as vogais por #.

  O programa deve repetir o processo at� encontrar o string terminar ou TERMINAR 
  ou Terminar.
  
  1) Capturar Nome e Sobrenome
  2) Transformar nome em c�digo -> substituir vogais por #
  3) Apresentar Sobrenome, Nome e C�digo
  4) Repetir 1, 2 e 3 at� encontrar a string terminar, Terminar ou TERMINAR
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main ()
{
    char nome[20] = {}, sobrenome[40], codigo[20] = {};           //preenche com zeros
    int flag = 1, i, n;   
    while (flag)
    {
          printf ("Digite seu nome: ");
          gets(nome);
          printf ("Digite seu sobrenome: "); 
          gets(sobrenome);  
          n = strlen(nome);
          if (nome[0] == 't' && nome[1] == 'e' && nome[2] == 'r' && nome[3] == 'm' && nome[4] == 'i' && nome[5] == 'n' && nome[6] == 'a' && nome[7] == 'r')
             flag = 0;
          else
             if (nome[0] == 'T' && nome[1] == 'e' && nome[2] == 'r' && nome[3] == 'm' && nome[4] == 'i' && nome[5] == 'n' && nome[6] == 'a' && nome[7] == 'r')
                flag = 0;
             else           
                if (nome[0] == 'T' && nome[1] == 'E' && nome[2] == 'R' && nome[3] == 'M' && nome[4] == 'I' && nome[5] == 'N' && nome[6] == 'A' && nome[7] == 'R')
                   flag = 0;
                else
                   if (sobrenome[0] == 't' && sobrenome[1] == 'e' && sobrenome[2] == 'r' && sobrenome[3] == 'm' && sobrenome[4] == 'i' && sobrenome[5] == 'n' && sobrenome[6] == 'a' && sobrenome[7] == 'r')
                      flag = 0;
                    else
                      if (sobrenome[0] == 'T' && sobrenome[1] == 'e' && sobrenome[2] == 'r' && sobrenome[3] == 'm' && sobrenome[4] == 'i' && sobrenome[5] == 'n' && sobrenome[6] == 'a' && sobrenome[7] == 'r')
                         flag = 0;
                      else
                         if (sobrenome[0] == 'T' && sobrenome[1] == 'E' && sobrenome[2] == 'R' && sobrenome[3] == 'M' && sobrenome[4] == 'I' && sobrenome[5] == 'N' && sobrenome[6] == 'A' && sobrenome[7] == 'R')  
                            flag = 0;
                         else
                         {  
                            while (flag)
                            { 
                              for (i = 0; i < n; i++)
                              {
                                  if (nome[i] == 'a' || nome[i] == 'A' || nome[i] == 'e' || nome[i] == 'E' || nome[i] == 'i' || nome[i] == 'I' || nome[i] == 'o' || nome[i] == 'O' || nome[i] == 'u' || nome[i] == 'U')
                                     codigo[i] = '#';                                
                                  else
                                     codigo[i] = nome[i];
                              }                   
                              printf ("\nSobrenome: %s\nNome: %s\nCodigo: %s\n\n", sobrenome, nome, codigo);
                              flag = 0;
                            }
                            flag = 1;
                         } 
    }
    printf ("\nFinalizando o programa.\n\n");
    system("pause");
    return 0;
}
