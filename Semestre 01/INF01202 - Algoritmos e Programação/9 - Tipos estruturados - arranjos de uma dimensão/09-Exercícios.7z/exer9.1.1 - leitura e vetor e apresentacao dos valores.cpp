/*
  Name: exer9.1.1 - leitura e vetor e apresentacao dos valores
  Author: Jo�o Luiz Grave Gross
  Date: 26/03/09 12:30
  Description: Ler um vetor de inteiros e apresent�-lo. Calcular a m�dia dos valores lidos e apresent�-la.
*/

#include<stdlib.h>
#include<stdio.h>
#define MAX 5

int main ()
{
    int valores[MAX], i;
    float media=0;
    for (i=0; i < MAX; i++)
    {
        printf ("(%d) Digite um valor inteiro de nota (de 0 a 10): ", (i+1));
        scanf ("%d", &valores[i]);
        if (valores[i] > 10 || valores[i] < 0)
        {
           printf ("\nAVISO: Nota inferior a zero ou maior do que 10!\n\n");
           i--;
        }
    }
    printf ("\n");
    for (i=0; i < MAX; i++)
    {
        printf ("Nota %d = %d\n", (i+1), valores[i]);
        media = media + valores[i];
    }
    media /= i;
    printf ("\nMedia dos %d valores apresentados: %.2f\n", i, media);
    system ("pause");
    return 0;   
}
