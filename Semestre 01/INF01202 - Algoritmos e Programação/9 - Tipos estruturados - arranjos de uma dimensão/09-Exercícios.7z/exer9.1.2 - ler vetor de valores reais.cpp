/*
  Name: exer9.1.2 - ler vetor de valores reais
  Author: Jo�o Luiz Grave Gross
  Date: 26/03/09 12:56
  Description: Ler um vetor de reais e apresent�-lo. Contar e apresentar o 
  n�mero de valores positivos existentes no vetor.
*/

#include<stdlib.h>
#include<stdio.h>
#define MAX 5

int main ()
{
    float vetor[MAX];
    int i, cont=0;
    for (i=0; i < MAX; i++)
    {
        printf ("(%d) Digite um valor real: ", (i+1));
        scanf ("%f", &vetor[i]);
        if (vetor[i] > 0)
        {
           cont++;
           printf ("\tValor positivo: %.2f\n", vetor[i]);
        }
    }
    printf ("\n");
    printf ("Valores digitados: \n");
    for (i=0; i < MAX; i++)
        printf ("Valor %d = %.2f\n", (i+1), vetor[i]);
    printf ("\nNumero de valores positos: %d", cont);
    system ("pause");
    return 0;
}
