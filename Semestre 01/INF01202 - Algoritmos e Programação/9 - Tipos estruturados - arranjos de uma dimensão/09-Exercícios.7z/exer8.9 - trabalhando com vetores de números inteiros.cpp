/*
  Name: exer8.9 
  Author: Jo�o Luiz Grave Gross
  Matr�cula: 180171
  Date: 29/03/09 14:59
  Description: Elaborar um programa em C que implemente um algoritmo para o enunciado a seguir:
               
  1) Criar um vetor de nome V1 atrav�s da inser��o dos N primeiros elementos da s�rie de Fibonacci. 
  O valor para N deve ser inteiro, maior que zero e menor ou igual a 19, lido de tecladoe rejeitado 
  caso n�o satisfazer, sendo sempre solicitado um novo valor at� o seu aceite.
  
  S�rie de Fibonacci: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 
  
  2) Criar um vetor V2 de inteiros, m�ltiplos de 3, a partir de 1 at� 26. 
  
  M�ltiplos de 3: 3, 6, 9, 12, 15, 18, 21, 24   
  
  3) Criar um vetor V3, com somente os n�meros �mpares da tabuada de 3 at� completar 13 elementos. 
  
     a) Calcular o m�ltiplo de 3
     b) ver se � �mpar
        b.1) se for �mpar n++
        b.2) repete a) e b) at� n == 13 (n declarado como n=0)
  
  4) O programa deve gerar um vetor VFinal que representa a express�o:

  [(V1 uni�o com V2) interse��o com V3]
  
    a) Uniao de V1 com V2
       a.1) Pegar V1[i], com i=0 inicialmente e comparar com todos os elementos de V2
            a.1.1) Se for diferente coloca V1[i] ao final de V2 e faz i++
            a.1.2) Se for igual apenas faz i++
       a.2) repete a.1) at� V1[i] = '\0'     

  Apresentar todos os vetores gerados e Vfinal com mensagens elucidativas.
*/

#include<stdlib.h>
#include<stdio.h>
#include<string.h>

int main ()
{
    int v1[20], v2[30], v3[14], vfinal[10] = {'\0'}; 
    int nv1, nv2=0, nv3=0, i, j, k, num1=1, num2=1, soma, flag1=1, flag2;
    //v1 - s�rie de fibonacci
    while (flag1)
    {
       printf ("Digite a quantidade de termos (de 1 a 19): ");
       scanf ("%d",&nv1);
       flag2 = 1;
       if (nv1 < 1 || nv1 > 19)
       {
          printf ("Valor invalido. Tente novamente.\n");
          flag2=0;
       }
       else
          if (nv1 == 1)
          {
             v1[0] = 1;
             printf ("\nSerie de Fibonacci: \t\t 1");
             flag2 = 0; 
             flag1 = 0;
          }
          else
              if (nv1 == 2)
              {
                 v1[0] = 1; 
                 v1[1] = 1;  
                 printf ("\nSerie de Fibonacci: \t\t 1 1");
                 flag2 = 0;    
                 flag1 = 0;
              }
              else 
              {
                 v1[0] = 1;
                 v1[1] = 1;  
                 printf ("\nSerie de Fibonacci: \t\t 1 1");
                 i = 2;
              }
       j = nv1 - 3;
       while (flag2 && j >= 0)
       {
          flag1 = 0;
          soma = num1 + num2;
          num1 = num2;
          num2 = soma;
          printf (" %d", soma);
          v1[i] = soma;
          i++;
          j--;
       }
       printf ("\n");
    } 
    
    // v2
    printf ("\nv2 - Multiplos de 3:\t\t");
    soma = 0;
    for (i = 0; soma < 24; i++)
    {
        soma = soma + 3;
        printf (" %d", soma);
        v2[i] = soma;   
        nv2++;
    }
   
    //v3
    printf ("\n\nv3 - Multiplos impares de 3:\t");
    soma = 0;
    j = 13;
    for (i = 0; i <= j; i++)
    {
        soma = soma + 3;
        if (soma % 2)
        {
           printf (" %d", soma);
           v3[i] = soma;   
           nv3++;      
        }   
        else
           i--;     
    }
    
    //Uni�o de v1 com v2  
    for (i = 0; i < nv1; i++)
    {
        for (j = 0; j < nv2; j++)    //nv2 = 8 (referente aos 8 valores de v2, por�m o oitavo valor encontr-as ena posi��o v2[7],
                                     //por isso j < nv2 no la�o for
        {
            if (v1[i] != v2[j])       
               flag1 = 1;   
            else
            {
               flag1 = 0;   
               j = nv2;
            }               
        }
        if (flag1 == 1)
        {
           v2[nv2] = v1[i];
           nv2++;
        }
    }
    printf ("\n\nv1 uniao com v2: \t\t ");
    for (i = 0; i < nv2; i++)
        printf ("%d ", v2[i]);


    //Interse��o de (v1 U v2) com v3
    soma = 0;
    for (i = 0; i < nv2; i++)
    {
        for (j = 0; j < nv3; j++)  
        {
            if (v2[i] == v3[j])       
            {
               flag1 = 1;   
               j = nv3;
            }
            else
               flag1 = 0;              
        }
        if (flag1 == 1)
        {
            vfinal[soma] = v2[i];
            soma++;
        }
        if ((i+1) == nv2)
            vfinal[soma] = 0;
    }
        
    printf ("\n\n(v1 U v2) intersecao com v3: \t ");
    for (i = 0; vfinal[i] != 0; i++)
        printf ("%d ", vfinal[i]);    
        
    printf ("\n\n\n");
    system ("pause");
    return 0;    
}

















