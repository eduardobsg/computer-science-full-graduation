/*
  Name: exer9.2.4 - devolve o n-en�simo caractere de uma string
  Author: Jo�o Luiz Grave Gross
  Date: 29/03/09 11:10
  Description: Fazer um programa em C que devolve o n-en�simo caractere de uma
  string s lido.
*/

#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#define MAX 20

int main ()
{
    char s[MAX];
    int n=0;
    printf ("Digite o texto: ");
    gets(s);             //coloca o texto digitado em "s"
    while (s[n] != '\0')
          n++;
    n--;
    printf ("Ultimo caractere digitado: %c\n", s[n]);
    system("pause");
    return 0;
}
