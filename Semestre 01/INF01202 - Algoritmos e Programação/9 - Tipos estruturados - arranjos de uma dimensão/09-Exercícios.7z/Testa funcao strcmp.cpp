//testa funcao strcmp
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(  )
{
  int i;
  char string_primeiro[40], string_segundo[40];
  for (i = 1; i <=3; i++)
    {
     printf("Forneca um texto: ");
     gets(string_primeiro);
     printf("Forneca um texto: ");
     gets(string_segundo);
     printf("Resultado da comparacao de %s com %s: %d\n\n", 
            string_primeiro, string_segundo, 
            strcmp(string_primeiro, string_segundo) ); 
    }
  system("pause");  
  return 0;
}
