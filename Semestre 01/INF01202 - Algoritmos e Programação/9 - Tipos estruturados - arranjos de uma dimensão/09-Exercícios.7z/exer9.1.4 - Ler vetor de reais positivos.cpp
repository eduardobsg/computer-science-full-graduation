/*
  Name: exerc9.1.4 - Ler vetor de reais positivos
  Copyright: 
  Author: 
  Date: 26/03/09 13:32
  Description: Ler um vetor de reais (s� fornecer na leitura valores positivos 
  ou iguais a zero). Apresentar o vetor e ap�s substituir os valores iguais a 
  zero por -99. Escrever novamente o vetor.
*/

#include<stdlib.h>
#include<stdio.h>
#define MAX 5

int main ()
{
    float vetor[MAX];
    int i;
    for (i=0; i < MAX; i++)
    {
        printf ("Digite um valor real (positvo ou igual a zero): ");
        scanf ("%f",&vetor[i]);
        if (vetor[i] < 0)
        {
           printf ("\nAVISO: Valor menor que zero!\n\n");
           i--;
        }
    }    
    printf ("\n");
    printf ("Valores digitados: \n");
    for (i=0; i < MAX; i++)
    {   
        printf ("Valor %d: %.2f\n", (i+1), vetor[i]);
        if (vetor[i] == 0)
           vetor[i] = -99;
    }
    printf ("\nNovos valores: \n");
    for (i=0; i < MAX; i++) 
        printf ("Valor %d: %.2f\n", (i+1), vetor[i]);
    system ("pause");
    return 0;
}
