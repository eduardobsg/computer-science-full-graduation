/*
  Name: exer9.2.5 - Ler nome e sobrenome e imprimir na tela
  Author: Jo�o Luiz Grave Gross
  Date: 29/03/09 14:05
  Description: Fazer um programa em C que leia o Nome e o Sobrenome de um usu�rio
  e o apresente na telinha como Sobrenome, Nome. O programa deve
  repetir o processo at� encontrar o string SAIR ou sair.
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main ()
{
    char nome[20], sobrenome[40];
    int flag = 1;
    while (flag)
    {
          printf ("Digite seu nome: ");
          gets(nome);
          printf ("Digite seu sobrenome: "); 
          gets(sobrenome);
          if (nome[0] == 's' && nome[1] == 'a' && nome[2] == 'i' && nome[3] == 'r')
             flag = 0;
          else
             if (nome[0] == 'S' && nome[1] == 'A' && nome[2] == 'I' && nome[3] == 'R')
                flag = 0;
             else           
                if (sobrenome[0] == 's' && sobrenome[1] == 'a' && sobrenome[2] == 'i' && sobrenome[3] == 'r')
                   flag = 0;
                else
                    if (sobrenome[0] == 'S' && sobrenome[1] == 'A' && sobrenome[2] == 'I' && sobrenome[3] == 'R')
                       flag = 0;
                    else
                    {
                       printf ("Sobrenome\tNome\n");
                       printf ("%s\t%s\n\n", sobrenome, nome);
                    } 
    }
    printf ("Finalizando o programa.\n\n");
    system("pause");
    return 0;
}

