//testa funcao getchar

#include <stdio.h>
#include <stdlib.h>

#define MAXIMO 20
int main(  )
{
  char ch;
  system("color 71");
  printf("Forneca um caractere: ");
  ch = getchar( );
  printf("O caractere digitado: %c\n",ch);
  system("pause");  
  return 0;
} 
