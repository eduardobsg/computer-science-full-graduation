//testa funcao puts
#include <stdio.h>
#include <stdlib.h>

int main(  )
{
  char nome[10];
  system("color 71");
  printf("Digite um nome: ");
  gets(nome);
  puts("A seguir o nome digitado:"); 
  puts (nome); 
  system("pause");  
  return 0;
} 
