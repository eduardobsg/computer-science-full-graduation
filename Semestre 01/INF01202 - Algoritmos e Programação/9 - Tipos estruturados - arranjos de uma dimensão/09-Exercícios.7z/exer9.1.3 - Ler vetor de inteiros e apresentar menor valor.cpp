/*
  Name: exer9.1.3 - Ler vetor de inteiros e apresentar menor valor
  Author: Jo�o Luiz Grave Gross
  Date: 26/03/09 13:22
  Description: Ler um vetor de inteiros e apresent�-lo. Achar o seu menor valor e apresent�-lo.
*/

#include<stdlib.h>
#include<stdio.h>
#define MAX 5

int main ()
{
    int valores[MAX], i, menor;
    for (i=0; i < MAX; i++)
    {
        printf ("(%d) Digite um valor inteiro: ", (i+1));
        scanf ("%d", &valores[i]);
    }
    printf ("\n");
    menor = valores[i];
    for (i=0; i < MAX; i++)
    {
        printf ("Nota %d = %d\n", (i+1), valores[i]);
        if (menor > valores[i])
           menor = valores[i];
    }
    printf ("\nMenor valor: %d", menor);
    system ("pause");
    return 0;   
}

