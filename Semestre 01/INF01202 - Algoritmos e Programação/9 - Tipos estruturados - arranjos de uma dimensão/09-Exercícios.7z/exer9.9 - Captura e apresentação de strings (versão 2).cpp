/*
  Name: exer9.9 - Captura e apresenta��o de strings
  Author: Jo�o Luiz Grave Gross
  Date: 31/03/09 12:27
  Description: Exerc�cio de Avalia��o 9.9
  
  Fazer um programa em C que solicite o nome completo de um usu�rio (Nome e o 
  Sobrenome) e o apresente na telinha como Sobrenome, Nome e C�digo. 

  C�digo � uma string que ser� uma transforma��o a partir do nome do usu�rio, 
  conforme a regra: substituir todos as vogais por #.

  O programa deve repetir o processo at� encontrar o string terminar ou TERMINAR 
  ou Terminar.
  
  1) Capturar Nome e Sobrenome
  2) Transformar nome em c�digo -> substituir vogais por #
  3) Apresentar Sobrenome, Nome e C�digo
  4) Repetir 1, 2 e 3 at� encontrar a string terminar, Terminar ou TERMINAR
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main ()
{
    char nome[20] = {}, sobrenome[40], codigo[20] = {};           //preenche com zeros
    int flag = 1, i, n, teste;   
    do
    {
          printf ("Digite seu nome: ");
          gets(nome);
          printf ("Digite seu sobrenome: "); 
          gets(sobrenome);  
          n = strlen(nome);
          
          teste = strcmp (nome, "Terminar");
          if (teste == 0)
             flag = 0;
          else
          {
              teste = strcmp (nome, "terminar");
              if (teste == 0)
                 flag = 0;
              else  
              { 
                 teste = strcmp (nome, "TERMINAR");
                 if (teste == 0)
                    flag = 0;   
                 else
                 {
                    teste = strcmp (sobrenome, "Terminar");
                    if (teste == 0)
                       flag = 0;
                    else   
                    {
                       teste = strcmp (sobrenome, "terminar");
                       if (teste == 0)
                          flag = 0;
                       else   
                       {
                          teste = strcmp (sobrenome, "TERMINAR");
                          if (teste == 0)
                             flag = 0;      
                       }
                    }
                 }
              }
          }
             
          while (flag)
          { 
            for (i = 0; i < n; i++)
            {
                if (nome[i] == 'a' || nome[i] == 'A' || 
                    nome[i] == 'e' || nome[i] == 'E' || 
                    nome[i] == 'i' || nome[i] == 'I' || 
                    nome[i] == 'o' || nome[i] == 'O' || 
                    nome[i] == 'u' || nome[i] == 'U')
                   codigo[i] = '#';                                
                else
                   codigo[i] = nome[i];
            }                   
            printf ("\nSobrenome: %s\nNome: %s\nCodigo: %s\n\n", sobrenome, nome, codigo);
            flag = 0;
          }
          flag = 1;
    } while (teste != 0);
    printf ("\nFinalizando o programa.\n\n");
    system("pause");
    return 0;
}
