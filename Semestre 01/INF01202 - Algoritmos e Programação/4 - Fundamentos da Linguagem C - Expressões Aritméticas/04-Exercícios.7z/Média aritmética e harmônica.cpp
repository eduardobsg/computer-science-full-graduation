/*
  Name: Jo�o Luiz Grave Gross
  Copyright: 
  Date: 15/03/09 11:28
  Description: Calcula m�dia aritm�tica e harm�nica. Proibido notas iguais a zero.
*/

#include<stdlib.h>
#include<stdio.h>
#include<math.h>

int main ()
{
    float a1, a2, a3, media_a, media_h;
    printf ("Digite as 3 notas: ");
    scanf ("%f%f%f",&a1,&a2,&a3);
    media_a = (a1*3+a2*5+a3*2)/10;
    media_h = 3/((1/a1)+(1/a2)+(1/a3));
    printf ("Media aritm�tica: %.2f\n",media_a);
    printf ("Media harmonica: %.2f\n",media_h);
    system ("pause");
    return 0;
}

