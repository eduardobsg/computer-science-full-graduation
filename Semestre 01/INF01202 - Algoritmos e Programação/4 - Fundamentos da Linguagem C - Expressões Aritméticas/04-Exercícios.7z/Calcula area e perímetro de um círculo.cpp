//Dado o raio de uma circunfer�ncia, calcula o per�metro desta e a �rea do c�rculo //correspondente
#include <stdlib.h>
#include<stdio.h>
int main()
{
    float raio, area, perimetro;
    printf("Raio:");
    scanf("%f",&raio);
    area=3.14*raio*raio;
    perimetro=2*3.14*raio;
    printf("Area: %f \n",area);
    printf("Perimetro: %f\n",perimetro);
    system("PAUSE");
    return 0;
}
