/*
  Name: Jo�o Luiz Grave Gross   
  Copyright: 
  Author: 
  Date: 15/03/09 12:36
  Description: Fazer um programa em C que solicite ao usu�rio seu nome e os n�meros inteiros 
  relativos ao dia e m�s de seu anivers�rio. Mostre ao usu�rio que o programa sabe o nome dele, 
  bem como o resto da divis�o do dia de anivers�rio por 2 e o valor do m�s elevado a pot�ncia 3.
*/

#include<stdlib.h>
#include<stdio.h>
#include<math.h>

int main ()
{
    char nome[20];
    int dia, mes;
    printf ("Digite seu nome: ");
    scanf ("%s",&nome);
    printf ("seu nome �: %s\n",nome);
    printf ("Digite o dia e mes: ");
    scanf ("%d%d",&dia,&mes);
    dia = dia%2;
    mes = pow(mes,3);
    printf ("Mes: %d\n",mes);
    printf ("Dia: %d\n",dia);
    system ("pause");
    return 0;
}
