/*
  Name: Jo�o Luiz Grave Gross           
  Copyright: 
  Author: 
  Date: 15/03/09 11:48
  Description: Define as ra�zes de uma equa��o de segundo grau. Proibido colocar a=0 ou equa��es de segundo grau com raiz imagin�ria
*/

#include<stdlib.h>
#include<stdio.h>
#include<math.h>

int main ()
{
    int a,b,c;
    float r1,r2;
    printf ("Digite os coeficientes a, b e c da equa��o: ");
    scanf ("%d%d%d",&a,&b,&c);
    r1=(-b+sqrt(b*b-4*a*c))/(2*a);
    r2=(-b-sqrt(b*b-4*a*c))/(2*a);
    printf ("\nRaiz 1: %f\nRaiz 2: %f\n",r1,r2);
    system ("pause");
    return 0;
}
