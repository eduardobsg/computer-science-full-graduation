/*
  Name: Jo�o Luiz Grave Gross
  Copyright: 
  Date: 15/03/09 11:28
  Description: Conversor de Graus Fahenrit para Graus Celsius
*/

#include<stdlib.h>
#include<stdio.h>
#include<math.h>

int main ()
{
    float grausfa, grausc=0;
    printf ("Graus Fahenrit: ");
    scanf ("%f",&grausfa);
    grausc=(5*(grausfa-32))/9;
    printf ("Graus Celsius: %f\n",grausc);
    system ("pause");
    return 0;
}
