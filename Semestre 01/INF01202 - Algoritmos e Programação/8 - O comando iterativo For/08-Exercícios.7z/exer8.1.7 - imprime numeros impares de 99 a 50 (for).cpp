/*
  Name: exer8.1.7 - imprime numeros impares de 99 a 50 (for)
  Author: Jo�o Luiz Grave Gross
  Date: 22/03/09 13:30
  Description: Faca um programa C que imprime os n�meros �mpares entre 99 e 50.
*/

#include<stdlib.h>
#include<stdio.h.>

int main ()
{
    int i;
    for (i = 99; i >= 50; i -= 2)
           printf ("%3d", i);           
    printf ("\n");
    system ("pause");
    return 0;
}
