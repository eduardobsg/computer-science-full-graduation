/*
  Name: exer8.20 - amostra de a�o
  Author: Jo�o Luiz Grave Gross
  Date: 02/04/09 15:07
  Description: Um a�o � classificado de acordo com o resultado de tr�s testes, 
  que devem verificar se o mesmo satisfaz �s seguintes especifica��es:
      
  Teste 1 - conte�do de carbono abaixo de 7%;
  Teste 2 - dureza Rokwell maior que 50;
  Teste 3 - resist�ncia � tra��o maior do que 80.000 psi.
  
  Ao a�o � atribu�do o grau:
  10, se passa pelos tr�s testes; 
  9, se passa apenas nos testes 1 e 2; 
  8, se passa no teste 1; 
  7, em todos os demais casos. 
  
  Lidas as informa��es de amostras: n�mero da amostra, conte�do de carbono (em %), 
  a dureza Rokwell e a resist�ncia � tra��o (em psi) 
  
  Fazer um programa que d� a classifica��o de uma amostra at� que o n�mero de 
  amostra fornecido seja negativo. 
  
  Escrever para cada amostra: n�mero da amostra e grau obtido.

*/

#include <stdio.h>
#include <stdlib.h>

int main ()
{
    int num_amostra, conteudo_carbono, dureza_rokwell, res_tracao, i, flag = 1, grau;
    while (flag)
    {
          printf ("Informe\nNumero da amostra: ");
          scanf ("%d", &num_amostra);
          if (num_amostra >= 0)
          {
             printf ("Conteudo de Carbono: ");
             scanf ("%d", &conteudo_carbono);
             printf ("Dureza Rokwell: ");
             scanf ("%d", &dureza_rokwell);
             printf ("Resistencia a tracao: ");
             scanf ("%d", &res_tracao);
             if ((conteudo_carbono < 7) && (dureza_rokwell > 50) && (res_tracao > 80000))
                grau = 10;
             else   
                if ((conteudo_carbono < 7) && (dureza_rokwell > 50))
                   grau = 9;
                else
                   if (conteudo_carbono < 7)
                      grau = 8;   
                   else
                      grau = 7;
             printf ("\nGrau: %d\n\n", grau);  
          }
          else
             flag = 0;
    }
    system ("pause");
    return 0;
}














