/*
  Name: exer8.1.5 - Tabela de conversao de celsius para fahenrit (for)
  Author: Jo�o Luiz Grave Gross
  Date: 22/03/09 13:30
  Description: Faca um programa C que apresente na tela uma tabela de convers�o de graus Celsius
  para Fahrenheit, de -100 �C a 100 �C. Use um incremento de 10� C.
*/

#include<stdlib.h>
#include<stdio.h.>

int main ()
{
    int gcelsius;
    float gfa;
    printf ("Celsius\tFahenrit\n");
    for (gcelsius = -100; gcelsius <= 100; gcelsius += 10)
    {
        gfa = ((gcelsius*9)/5)+32;
        printf ("%7d\t%8.f\n", gcelsius, gfa);
    }
    system ("pause");
    return 0;
}
