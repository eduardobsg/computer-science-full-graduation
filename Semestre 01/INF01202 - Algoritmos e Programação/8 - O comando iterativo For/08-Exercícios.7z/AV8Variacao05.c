/*
  Name: AV8Variacao05.c
  Copyright: 
  Author: As professoras.
  Date: 25/03/08 14:09
  Description: usando for aninhado.
*/

#include <stdio.h>
#include <stdlib.h>
int main ()
{
  int vezes, numero;
  for (numero = 5; numero <= 6; numero++) 
    {
     for (vezes = 1 ; vezes <=10; vezes++)
        printf("%2d * %2d = %2d\n", numero, vezes, numero*vezes);
    }
  printf ("\n\n");
  system ("pause");
  return 0;
}
