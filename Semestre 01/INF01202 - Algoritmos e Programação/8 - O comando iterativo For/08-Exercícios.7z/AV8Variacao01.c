/*
  Name: 
  Copyright: 
  Author: As professoras.
  Date: 25/03/08 14:09
  Description: usando expressoes no cabecalho do for.
*/

#include <stdio.h>
#include <stdlib.h>
int main ()
{
   int i, a, b;
   float lido, soma;
   soma = 0;
   printf ("Forneca dois valores inteiros: ");
   scanf ("%d%d", &a, &b);
   for (i = a; i <= b+7; i++)
    {
      printf ("\nForneca um valor real: ");
      scanf ("%f", &lido);
      soma = soma + lido;
    }
   printf ("\nSoma = %10.2f", soma);
   system ("pause");
   return 0;
}
