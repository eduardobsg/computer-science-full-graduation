/*
  Name: AV8Variacao04.c
  Copyright: 
  Author: As professoras.
  Date: 25/03/08 14:09
  Description: usando variavel de controle tipo caractere.
*/

#include <stdio.h>
#include <stdlib.h>
int main ()
{
  char caract;
  for(caract = 'a'; caract <= 'e'; caract++)
     printf("%3c", caract);
  printf ("\n\n");   
  system ("pause");
  return 0;
}
