/*
  Name: AV8Exemplo01.c
  Copyright: 
  Author: As professoras.
  Date: 25/03/08 12:01
  Description: imprime na tela a tabuada de multiplicacao do 7.
*/

#include <stdio.h>
#include <stdlib.h>
int main ()
{
   int n;
   for (n = 1; n <= 10; n++)
      printf ("7 * %2d = %2d\n", n, 7*n);
   system ("pause");
   return 0;
}
