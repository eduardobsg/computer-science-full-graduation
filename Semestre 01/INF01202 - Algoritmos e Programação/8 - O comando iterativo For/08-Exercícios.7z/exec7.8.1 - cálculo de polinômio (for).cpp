/*
  Name: exec7.8.1 - c�lculo de polin�mio (for - avaliacao)
  Exerc�cio de Avalia��o 7.8
  Author: Jo�o Luiz Grave Gross
  Date: 22/03/09 14:14
  Description: Fazer um programa que leia um valor X e depois calcule e escreva
  o resultado do seguinte somat�rio:
            
  x^25/1 - x^24/2 + x^23/3 - x^22/4 ...
*/

#include<stdlib.h>
#include<stdio.h>
#include<math.h>

int main ()
{
    double x, soma=0;
    int i=1, j=25;
    printf ("Digite um coeficiente: ");
    scanf ("%lf",&x);
    printf ("\nSoma = ");
    for (i = 1, j = 25; i <= 25; i++, j--)
    {
        if (i % 2)
        {
           printf (" (%.2lf^%d)/%d -", x, j, i);      //i = �mpar
           soma += (pow (x, j)) / i;      //pow (base,expoente)
           //printf ("\n[(pow(%.2lf,%d)/%d] = %lf\n", x, j, i, ((pow (x, j)) / i)); -> valor de cada termo
        }
        else
        {
           printf (" (%.2lf^%d)/%d +", x, j, i);      //i = par
           soma -= (pow (x, j)) / i;      //pow (base,expoente)
        }
    }
    printf ("\b= %lf\n\n", soma);
    system ("pause");
    return 0;
}
