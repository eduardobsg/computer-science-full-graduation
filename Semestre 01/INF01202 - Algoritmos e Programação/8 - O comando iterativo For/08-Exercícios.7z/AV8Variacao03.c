/*
  Name: AV8Variacao03.c
  Copyright: 
  Author: As professoras.
  Date: 25/03/08 14:09
  Description: usando duas vari?veis de controle.
*/

#include <stdio.h>
#include <stdlib.h>
int main ()
{
  int i, j;
  for (i = 1, j = 10; i <= 10; i++, j--)
	  printf("\ni = %4d \tj = %4d", i , j);
  printf("\n\n");
  system ("pause");
  return 0;
}
