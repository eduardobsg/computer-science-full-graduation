/*
  Name: exer8.16
  Author: Jo�o Luiz Grave Gross
  Date: 02/04/09 15:26
  Description: Dois jogadores lan�am ao mesmo tempo um dado. O jogador que 
  tem o maior resultado marca um ponto. O jogo termina quando um dos jogadores 
  obtiver 11 pontos. Escrever um programa que simule este jogo de dados.
*/

#include <stdlib.h>
#include <stdio.h>

int main ()
{
    int dado1, dado2, pontos1 = 0, pontos2 = 0, flag = 1;
    while (pontos1 < 11 && pontos2 < 11)
    {
          while (flag)
          {
             printf ("Digite os valores do dado dos dois jogadores: \n");
             scanf ("%d%d", &dado1, &dado2);
             if (dado1 < 1 || dado1 > 6 || dado2 < 1 || dado2 > 6)
                printf ("Valores invalidos. Entradas devem ser de 1 a 6.\n\n");
             else 
                flag = 0;
          }
          if (dado1 > dado2)
             pontos1++;
          if (dado1 < dado2)
             pontos2++;
          printf ("Jogador 1: %d pontos\nJogador 2: %d pontos\n", pontos1, pontos2);
          flag = 1;                
    }
    printf ("\nFim do jogo.\n\n");
    system ("pause");
    return 0;
}
