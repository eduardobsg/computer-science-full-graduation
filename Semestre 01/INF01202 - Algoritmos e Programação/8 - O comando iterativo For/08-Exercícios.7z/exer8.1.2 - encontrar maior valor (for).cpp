/*
  Name: exer8.1.2 - encontrar maior valor (for)
  Copyright: 
  Author: Jo�o Luiz Grave Gross
  Date: 22/03/09 13:16
  Description: Fa�a um programa C que, primeiramente, leia o total de valores inteiros a serem lidos
(n) e, a seguir, leia os n valores e encontre o maior valor do conjunto de valores lidos.
*/

#include<stdlib.h>
#include<stdio.h.>

int main ()
{
    int n, valor, maior, i=1;
    printf ("Quantidade de valores: ");       //deve ser maior que zero
    scanf ("%d",&n);                          //captura o n�mero de valores que ser�o teclados    
    printf ("(%d) Digite um valor: ", i);
    scanf ("%d",&valor);                      //captura o primeiro valor
    maior = valor;
    for (i = 2; i <= n; i++)                  //captura do segundo valor at� n
    {
        printf ("(%d) Digite um valor: ", i);
        scanf ("%d",&valor);
        if (valor > maior)
           maior = valor;
    }
    printf ("Maior valor: %d\n\n", maior);
    system ("pause");
    return 0;
}
