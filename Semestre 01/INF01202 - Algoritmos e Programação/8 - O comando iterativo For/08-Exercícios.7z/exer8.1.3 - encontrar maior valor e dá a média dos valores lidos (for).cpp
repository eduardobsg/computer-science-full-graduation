/*
  Name: exer8.1.3 - encontrar maior valor e d� a m�dia dos valores lidos (for)
  Copyright: 
  Author: Jo�o Luiz Grave Gross
  Date: 22/03/09 13:27
  Description: Estenda o programa 2 para que o mesmo tamb�m forne�a a m�dia dos valores lidos.
*/

#include<stdlib.h>
#include<stdio.h.>

int main ()
{
    int n, valor, maior, i=1;
    float media=0;
    printf ("Quantidade de valores: ");       //deve ser maior que zero
    scanf ("%d",&n);                          //captura o n�mero de valores que ser�o teclados    
    printf ("(%d) Digite um valor: ", i);
    scanf ("%d",&valor);                      //captura o primeiro valor
    maior = valor;
    media += valor;
    for (i = 2; i <= n; i++)                  //captura do segundo valor at� n
    {
        printf ("(%d) Digite um valor: ", i);
        scanf ("%d",&valor);
        media += valor;
        if (valor > maior)
           maior = valor;
    }
    printf ("\nMaior valor: %d\n", maior);
    printf ("Media dos valores: %.2f\n\n", (media/n));
    system ("pause");
    return 0;
}
