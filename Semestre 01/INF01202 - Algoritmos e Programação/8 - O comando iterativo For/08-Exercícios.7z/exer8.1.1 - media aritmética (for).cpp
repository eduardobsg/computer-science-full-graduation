/*
  Name: exer8.1.1 - media aritm�tica (for)
  Copyright: 
  Author: Jo�o Luiz Grave Gross
  Date: 22/03/09 13:10
  Description: Fa�a um programa C que leia 5 valores e calcula e imprime a sua 
  m�dia aritm�tica.
*/

#include<stdlib.h>
#include<stdio.h.>

int main ()
{
    int i;
    float nota, media=0;
    for (i = 1;i <= 5;i++)
    {
        printf ("(%d) Digite um valor: ",i);
        scanf ("%f",&nota);
        media += nota;
    }
    printf ("Media = %.2f\n\n", (media/5));
    system ("pause");
    return 0;
}
