/*
  Name: AV8Variacao02.c
  Copyright: 
  Author: As professoras.
  Date: 25/03/08 14:09
  Description: usando expressoes no cabecalho do for com incremento diferente de 1.
*/

#include <stdio.h>
#include <stdlib.h>
int main ()
{
   int i, num;
   printf ("Forneca um numero inteiro: ");
   scanf ("%d", &num);
   for (i = num; i <= num+10; i += 2)
         printf ("\ni = %4d\n\n", i);
   system ("pause");
   return 0;
}
