/*
  Name: exec7.8.2_avaliacao - apuracao de votos (for)
  Exerc�cio de Avalia��o 7.8
  Author: Jo�o Luiz Grave Gross
  Date: 22/03/09 15:31
  Description: 

  Fazer um programa que calcule o resultado final das elei��es para a
  presid�ncia de um clube de futebol, sabendo-se que:
  
  a) existem tr�s chapas concorrendo;
  b) os eleitores votaram fornecendo o n�mero da chapa escolhida;
  c) votar�o ao todo 700 membros do clube.
  
  O programa dever� processar os votos recebidos e fornecer o total de
  votos de cada uma das chapas, o total de votos em branco e o total de
  votos nulos.
  
  Al�m disso, o programa dever� verificar se a chapa mais votada �
  vencedora no primeiro turno da elei��o (mais de 50% dos votos
  v�lidos) ou se dever� ocorrer um segundo turno, e fornecer uma
  mensagem adequada em cada caso.
  
  Obs.: votos inv�lidos s�o os votos brancos ou nulos. Para informar
  voto em uma das chapas, o usu�rio deve digitar 1, 2 ou 3; para voto em
  branco, 0; e para voto nulo, 4.
  
  Aten��o: sugere-se o uso de uma constante (#define ...) para definir o
  n�mero de eleitores (ver as solu��es dos exerc�cios de auto avalia��o).
  
  Sa�da: total de votos de cada chapa, total de votos brancos, total de votos nulos, 
  vencedor ou segundo turno

*/

#include<stdlib.h>
#include<stdio.h>
#define n_votos 700

int main ()
{
    int chapa1=0, chapa2=0, chapa3=0, brancos=0, nulos=0, voto, i;
    for (i = 1; i <= n_votos; i++)
    {
        printf ("(voto %d) VOTACAO PRIMEIRO TURNO:", i);
        printf ("\n0 - Voto em branco\n1 - Chapa 1\n2 - Chapa 2\n3 - Chapa 3\n4 - Voto nulo\nCodigo: ");
        scanf ("%d",&voto);
        printf ("\n");
        switch (voto)
        {
               case 0: brancos++;      //voto em branco
                       break;
               case 1: chapa1++;       //chapa 1
                       break;
               case 2: chapa2++;       //chapa 2
                       break;
               case 3: chapa3++;       //chapa 3
                       break;
               case 4: nulos++;        //votos nulos
                       break;
               default: printf ("Codigo invalido!\n\n");
                        i--;         
        }
    }
    printf ("Votos:\nChapa 1: %d\nChapa 2: %d\nChapa 3: %d\n", chapa1, chapa2, chapa3);
    printf ("Votos Brancos: %d\nVotos Nulos: %d", brancos, nulos);
    voto = n_votos - nulos;    //voto = 100% dos votos validos
    if (((100*chapa1)/voto) > 50)
       printf ("\n\nChapa 1 eh a vencedora com %d porcento dos votos validos!\n", ((100*chapa1)/voto));
    else
       if (((100*chapa2)/voto) > 50)
          printf ("\n\nChapa 2 eh a vencedora com %d porcento dos votos validos!\n", ((100*chapa2)/voto));
       else   
          if (((100*chapa3)/voto) > 50)
             printf ("\n\nChapa 3 eh a vencedora com %d porcento dos votos validos!\n", ((100*chapa3)/voto));
          else   
             printf ("\n\nVotacao tera segundo turno! Nenhuma atingiu mais 50 porcento dos votos\n");                   
    system ("pause");
    return 0;
}











