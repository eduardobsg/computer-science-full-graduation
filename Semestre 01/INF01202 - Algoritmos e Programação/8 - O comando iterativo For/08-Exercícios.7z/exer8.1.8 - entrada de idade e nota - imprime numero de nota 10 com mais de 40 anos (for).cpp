/*
  Name: exer8.1.8 - entrada de idade e nota - imprime numero de nota 10 com mais de 40 anos (for)
  Author: Jo�o Luiz Grave Gross
  Date: 22/03/09 13:30
  Description: Fa�a um programa C que leia a idade e a nota sobre o filme �O segredo�, 
  fornecidas por espectadores, e conta quantos espectadores maiores de 40 anos que atribu�ram
  nota 10 ao filme.
*/

#include<stdlib.h>
#include<stdio.h.>

int main ()
{
    int idade, nota, i, n_10=0, n;
    printf ("Quantidade de notas: ");       //deve ser maior que zero
    scanf ("%d",&n);                          //captura o n�mero de valores que ser�o teclados    

    for (i = 1; i <= n; i++)                  //captura do segundo valor at� n
    {
        printf ("(%d) Digite sua idade e nota: ", i);
        scanf ("%d%d", &idade, &nota);
        if (idade > 40 && nota == 10)
           n_10++;
    }
    printf ("Numero de notas 10 de espectadores com mais de 40 anos: %d\n", n_10);
    system ("pause");
    return 0;
}
