/*
  Name: exer8.1.6 - imprime numeros pares de 50 a 99 (for)
  Author: Jo�o Luiz Grave Gross
  Date: 22/03/09 13:30
  Description: Faca um programa C que imprime os n�meros pares entre 50 e 99.
*/

#include<stdlib.h>
#include<stdio.h.>

int main ()
{
    int i;
    for (i = 50; i <= 99; i += 2)
           printf ("%3d", i);           
    printf ("\n");
    system ("pause");
    return 0;
}
