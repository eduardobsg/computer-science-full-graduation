/*
  Name: exer8.1.4 - conta e imprime os valores negativos teclados (for)
  Author: Jo�o Luiz Grave Gross
  Date: 22/03/09 13:30
  Description: Fa�a um programa C que leia valores inteiros e conta e imprime quantos valores
  negativos foram lidos.
*/

#include<stdlib.h>
#include<stdio.h.>

int main ()
{
    int n, valor, n_neg=0, i=1;
    printf ("Quantidade de valores: ");       //deve ser maior que zero
    scanf ("%d",&n);                          //captura o n�mero de valores que ser�o teclados    
    for (i = 1; i <= n; i++)                  //captura do segundo valor at� n
    {
        printf ("(%d) Digite um valor: ", i);
        scanf ("%d",&valor);
        if (valor < 0)
        {
           printf ("Valor negativo: %d\n", valor);
           n_neg++;
        }
    }
    printf ("Numero de valores negativos %d\n\n", n_neg);
    system ("pause");
    return 0;
}
