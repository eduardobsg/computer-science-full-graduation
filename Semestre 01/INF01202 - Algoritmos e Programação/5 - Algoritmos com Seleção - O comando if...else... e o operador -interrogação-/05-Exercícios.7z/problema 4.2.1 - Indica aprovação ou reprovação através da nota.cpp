/*
  Name: Jo�o Luiz Grave Gross
  Copyright: 
  Author: 
  Date: 15/03/09 15:44
  Description: Recebida uma nota, fornecer uma das seguintes mensagens:
  0 a 6: Reprovado: 
  7 a 9: Aprovado.
  10: Aprovado com louvor. 
*/

#include<stdlib.h>
#include<stdio.h>

int main ()
{
    float nota;
    printf ("Digite a nota: ");
    scanf ("%f",&nota);
    if (nota<=6)
       printf ("Reprovado\n");
    if (nota>6 && nota<=9)
       printf ("Aprovado\n");
    if (nota>9)
       printf ("Aprovado com louvor\n");
    system ("pause");
    return 0;
}
