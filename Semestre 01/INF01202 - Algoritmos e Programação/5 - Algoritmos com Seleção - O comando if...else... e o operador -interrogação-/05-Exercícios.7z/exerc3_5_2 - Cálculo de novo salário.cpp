/*
  Disciplina de Algoritmos de Programa��o (INF01202) - Turma H
  Aluno: Jo�o Luiz Grave Gross 	
  Matr�cula: 180171
  Atividade: Exerc�cio de Avalia��o 3.5.2
  Date: 15/03/09 16:30
  Description: 
  Date: 15/03/09 17:54
  Description: Uma empresa decidiu dar aumento escalonado a seus funcion�rios, de acordo com a seguinte regra: 
  
  13% para os sal�rios inferiores ou iguais a R$500,00; 
  14% para os sal�rios inferiores ou iguais a R$500,00, e cujos funcion�rios tenham no m�nimo 2 filhos; 
  10% para os sal�rios situados acima de R$500,00 at� R$1000,00, inclusive; 
  11% para os sal�rios situados acima de R$500,00 at� R$1000,00, inclusive, e cujos funcion�rios que tenham no m�nimo 2 filhos ou; 
  9% para os demais sal�rios. 

  Fazer um programa em C que, dados o sal�rio atual de um funcion�rio e o seu n�mero de filhos, retorne o valor de seu novo sal�rio. 
*/

#include<stdlib.h>
#include<stdio.h>

int main ()
{
    float salario, save;
    int filhos;
    printf ("Digite seu salario: ");
    scanf ("%f",&salario);
    printf ("Numero de filhos: ");
    scanf ("%d",&filhos);
    save=salario;    
    if (salario<=500)
    {
       if (filhos<2)
       {
          salario = salario+salario*0.13;
          printf ("Novo Salario: %.2f\n\n",salario);
       }
       else 
       {
          salario = salario+salario*0.14;
          printf ("Novo Salario: %.2f\n\n",salario);
       }
    }
    salario=save;   
    if (salario>500 && salario<=1000)
    {
       if (filhos<2)
       {
          salario = salario+salario*0.10;
          printf ("Novo Salario: %.2f\n\n",salario);
       }
       else 
       {
          salario = salario+salario*0.11;
          printf ("Novo Salario: %.2f\n\n",salario);
       }           
    }
    salario=save;
    if (salario>1000)
    {
        salario = salario+salario*0.09;
        printf ("Novo Salario: %.2f\n\n",salario);
    }
    system ("pause");
    return 0;
}
