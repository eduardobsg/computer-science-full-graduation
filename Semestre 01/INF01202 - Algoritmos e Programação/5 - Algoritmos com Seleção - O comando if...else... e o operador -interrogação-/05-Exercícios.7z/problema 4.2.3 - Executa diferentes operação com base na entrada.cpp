/*
  Name: Jo�o Luiz Grave Gross
  Copyright: 
  Author: 
  Date: 15/03/09 15:44
  Description: Recebido um valor, apresent�-lo t�o logo lido, bem como:
  se valor estiver entre 6 e 9 (limites considerados), calcular e apresentar o produto de valor por 9;
  se valor for < 5, informar se o valor lido � par ou �mpar;
  se valor for igual a 5, elev�-lo ao cubo;
  se valor for igual a 10, extrair sua raiz quadrada.
*/

#include<stdlib.h>
#include<stdio.h>
#include<math.h>

int main ()
{
    int valor;
    float valor_f;
    printf ("Digite o valor: ");
    scanf ("%d",&valor);
    if (valor>=6 && valor<=9)
    {
       valor *= 9;                 //valor = valor*9
       printf ("Valor: %d\n",valor);
    }
    if (valor<5)
    {
       valor %= 2;                //valor = valor%2           
       if (valor)
          printf ("Valor eh impar\n");
       else 
          printf ("Valor eh par\n");
    }
    if (valor==5)
    {
       valor = pow(valor,3);
       printf ("Valor: %d\n",valor);                //valor = 124
       valor = 5; 
       printf ("Valor: %.2f\n",pow(valor,3));       //valor = 125
    }
    if (valor==10)
    {
       valor_f = (float)sqrt(10);
       printf ("Valor: %.2f\n",valor_f);
    }
    system ("pause");
    return 0;
}
