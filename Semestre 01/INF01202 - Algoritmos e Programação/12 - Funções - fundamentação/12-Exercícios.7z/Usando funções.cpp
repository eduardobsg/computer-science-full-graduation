/*
  Name: Usando fun��es
  Author: Jo�o Luiz Grave Gross
  Date: 19/04/09 12:14
  Description: 
  Fazer um ou mais programas com as seguintes fun��es void
  e sem par�metros:

  a) fun��o que apresenta os m�ltiplos de 5 
   entre 1 e um n (inteiro e positivo) informado;
  b) fun��o que solicita as coordenadas 
   de dois pontos no plano cartesiano (valores float) 
   e apresenta a dist�ncia entres esses dois pontos;
  c) fun��o que solicita um caractere 
   e o apresenta  50 vezes em uma linha.
  d) mais uma vers�o da fun��o anterior, em que o usu�rio
   define o tamanho da linha a ser apresentada.

  Todas as informa��es necess�rias �s tarefas devem 
  ser solicitadas internamente �s fun��es.

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void multiplos5 ()
{
     int n, valor, i;
     do
     {
         printf ("Quantos multiplos de 5 deseja saber? (1 a 100) ");
         scanf ("%d", &n);
         if (n < 1 || n > 100)
            printf ("\tValor fora dos limeites!\n");
     } while (n < 1 || n > 100);
     valor = 0;
     for (i = 0; i < n; i++)
     {
         valor += 5;
         printf ("%d  ", valor);
     }
     printf ("\n\n");
}

void distancia_2pontos ()
{
     int x[2], y[2], i;
     double distancia;
     for (i = 0; i < 2; i++) 
     {
          printf ("Coordenada x%d: ", i+1);
          scanf ("%d", &x[i]);
          printf ("Coordenada y%d: ", i+1);
          scanf ("%d", &y[i]);
     }
     //f�rmula: distancia = [(x1 - x2)� + (y1 - y2)�]^(1/2)
     distancia = sqrt (pow((x[0] - x[1]), 2) + pow((y[0] - y[1]), 2));
     printf ("Distancia entre (%d,%d) e (%d,%d): %.3lf\n\n", x[0], y[0], x[1], y[1], distancia);
}

void show_char ()
{
     char c;
     int i;
     printf ("Digite um caractere: ");
     fflush(stdin);
     scanf ("%c", &c);
     printf ("\n");
     for (i = 0; i < 50; i++)
         printf ("%c", c);
     printf ("\n\n");    
}

void show_n_char ()
{
     char c;
     int i, n;
     printf ("Digite um caractere: ");
     fflush(stdin);
     scanf ("%c", &c);
     do 
     {
          printf ("Tamanho da linha (1 a 1000):  ");
          scanf ("%d", &n);
          if (n < 1 || n > 1000)
             printf ("\tTamanho fora do limite permitido!\n");
     } while (n < 1 || n > 1000);
     printf ("\n");
     for (i = 0; i < n; i++)
         printf ("%c", c);
     printf ("\n\n");    
}

int main ()
{
    int operacao;
    do
    {
        do
        {
            printf ("Defina a operacao:  ");
            printf ("\n1 - n multiplos de 5");
            printf ("\n2 - distancia entre dois pontos");
            printf ("\n3 - mostrar caractere 50 veses");
            printf ("\n4 - mostrar caractere n vezes");
            printf ("\n0 - sair\n");
            scanf ("%d", &operacao);
            printf ("operacao: %d\n", operacao);
        } while (operacao < 0 || operacao > 4);
        switch (operacao)
        {
            case 1:      multiplos5 ();
                         break;
            case 2:      distancia_2pontos ();
                         break;
            case 3:      show_char ();
                         break;
            case 4:      show_n_char ();
                         break;                                                    
        }
    } while (operacao != 0);
    
    printf ("\n\n");
    system ("pause");
    return 0;
}
