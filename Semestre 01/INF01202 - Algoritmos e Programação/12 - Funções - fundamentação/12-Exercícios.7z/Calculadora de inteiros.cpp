#include <stdio.h>
#include <stdlib.h> 

void soma()
{
	int n ,m;
	float x;
	printf ("Digite 1o. valor inteiro: ");
	scanf ("%d",&n);
	printf ("Digite 2o. valor inteiro: ");
	scanf("%d",&m);
	x = n + m;
	printf("A soma : %1.f \n",x);
}

void multiplica()
{
	int n, m;
	float x;
	printf("Digite 1o. valor inteiro: ");
	scanf("%d",&n);
	printf("Digite 2o. valor inteiro: ");
	scanf("%d",&m);
	x= n * m;
	printf("O produto : %1.f \n",x); 
}

void subtrae()
{
	int n ,m;
	float x;
	printf("Digite 1o. valor inteiro: ");
	scanf("%d",&n);
	printf("Digite 2o. valor inteiro: ");
	scanf("%d",&m);
	x= n - m;
	printf("A subtra��o : %1.f \n",x); 
}

void divisao()
{
	int n, m;
	float x;
	printf("Digite 1o. valor inteiro: ");
	scanf("%d",&n);
	printf("Digite 2o. valor inteiro: ");
	scanf("%d",&m);
	if (m == 0)
	printf(" Impossivel realizar! Divisao por zero!\n");
	else
	{
		x= (float)n / m;
		printf("O resultado da divisao: %4.2f \n", x); 
	}
}

int main ()
{
	char r;
	do
	{
		system ("CLS"); // limpa tela
		printf("1. Somar\n");
		printf("2. Subtrair\n");
		printf("3. Multiplicar\n");
		printf("4. Dividir\n");
		printf("9. FIM \n");
		printf("\nO que deseja? ");
		scanf("%c",&r);
		if (r != '9')
		{
			switch (r)
			{
				case '1': soma();system("PAUSE"); break;
				case '2': subtrae();system("PAUSE"); break;
				case '3': multiplica();system("PAUSE"); break;
				case '4': divisao(); system("PAUSE");break;
			}
		}
	}
	while (r != '9');
	system("pause");
	return 0;
} 
