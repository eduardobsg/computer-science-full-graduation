/*
  Name: exercavalia12
  Author: Jo�o Luiz Grave Gross
  Date: 19/04/09 14:49
  Description:
  Fazer um programa em C que utilize fun��es sem retorno e sem par�metrospara implementar 
  uma m�quina de calcular para operar com fra��es. As opera��es s�o: soma, subtra��o, divis�o 
  e multiplica��o de fra��es, onde cada fra��o, d� entrada a 2 valores sempre: um para o 
  numerador e o outro para o denominador.

  As opera��es devem sempre manipular fra��es.

  O programa implementa fun��es para cada opera��o e uma para o menu de opera��es.

  Cuidados devem ser tomados com valores de entrada que possam invalidar as opera��es e, nesses 
  casos, novos valores devem ser solicitados.

  O t�rmino do programa se realiza atrav�s do menu, com um item espec�fico.
  
  Gravar o c�digo-fonte do programa em um arquivo .zip, cujo nome deve ter o seguinte formato: 
  seusobresome_nroidentificacao na UFRGS.  Por exemplo: chankaichek_29068998.
*/

#include <stdio.h>
#include <stdlib.h> 

void soma()
{
	int n1, n2, m1, m2, x1, x2, i;
	printf ("Digite o numerador do 1o. valor: ");
	scanf ("%d",&n1);
	printf ("Digite o denominador do 1o. valor: ");
    scanf ("%d",&n2);
	printf ("Digite o numerador do 2o. valor: ");
	scanf ("%d",&m1);
	printf ("Digite o denominador do 2o. valor: ");
    scanf ("%d",&m2);
    if (n2 == m2)
    {
        x1 = n1 + m1;
        x2 = n2;   
       	printf("A soma de %d/%d com %d/%d = %d/%d\n\n", n1, n2, m1, m2, x1, x2);
    }
    if (n2 != 0 && m2 != 0)
    {
        x2 = n2 * m2;
        x1 = n1 * m2 + m1 * n2;
      	printf("A soma de %d/%d com %d/%d = %d/%d\n\n", n1, n2, m1, m2, x1, x2);
    }
    else
    	printf("Impossivel realizar! Divisao por zero!\n\n");
}

void subtracao()
{
	int n1, n2, m1, m2, x1, x2, i;
	printf ("Digite o numerador do 1o. valor: ");
	scanf ("%d",&n1);
	printf ("Digite o denominador do 1o. valor: ");
    scanf ("%d",&n2);
	printf ("Digite o numerador do 2o. valor: ");
	scanf ("%d",&m1);
	printf ("Digite o denominador do 2o. valor: ");
    scanf ("%d",&m2);
    if (n2 == m2)
    {
        x1 = n1 - m1;
        x2 = n2;   
       	printf("A subtracao %d/%d por %d/%d = %d/%d\n\n", n1, n2, m1, m2, x1, x2);
    }
    if (n2 != 0 && m2 != 0)
    {
        x2 = n2 * m2;
        x1 = n1 * m2 - m1 * n2;
      	printf("A subtracao %d/%d por %d/%d = %d/%d\n\n", n1, n2, m1, m2, x1, x2);
    }
    else
    	printf("Impossivel realizar! Divisao por zero!\n\n");
}

void produto()
{
	int n1, n2, m1, m2, x1, x2;
	printf ("Digite o numerador do 1o. valor: ");
	scanf ("%d",&n1);
	printf ("Digite o denominador do 1o. valor: ");
    scanf ("%d",&n2);
	printf ("Digite o numerador do 2o. valor: ");
	scanf ("%d",&m1);
	printf ("Digite o denominador do 2o. valor: ");
    scanf ("%d",&m2);
    if ((n1 == 0 && n2 == 0) || (n1 == 0 && n2 != 0) || (m1 == 0 && m2 == 0) || (m1 == 0 && m2 != 0))
    {
       x1 = n1 * m1;
       x2 = n2 * m2; 
       printf("O produto de %d/%d com %d/%d = %d/%d\n\n", n1, n2, m1, m2, x1, x2);
    }
    else
    	printf("Impossivel realizar! Divisao por zero!\n\n");
}

void divisao()
{
	int n1, n2, m1, m2, x1, x2;
	printf ("Digite o numerador do 1o. valor: ");
	scanf ("%d",&n1);
	printf ("Digite o denominador do 1o. valor: ");
    scanf ("%d",&n2);
	printf ("Digite o numerador do 2o. valor: ");
	scanf ("%d",&m1);
	printf ("Digite o denominador do 2o. valor: ");
    scanf ("%d",&m2);
	if (m2 == 0 || m1 == 0 || (n2 == 0 && n1 != 0))
	   printf("Impossivel realizar! Divisao por zero!\n\n");
	else
	{
        x1 = n1 * m2;
        x2 = n2 * m1; 
		printf("A divisao de de %d/%d por %d/%d = %d/%d\n\n", n1, n2, m1, m2, x1, x2);
	}
}

int main ()
{
	int r;
	do
	{
        do 
        { 
		     printf("1 - Somar\n");
		     printf("2 - Subtrair\n");
		     printf("3 - Multiplicar\n");
		     printf("4 - Dividir\n");
		     printf("0 - Sair");
		     printf("\nOperacao: ");
		     scanf("%d", &r);
		     printf ("\n");
		     if (r < 0 || r > 4)
		        printf ("Operacao invalida!\n\n");
       } while (r < 0 || r > 4); 
	   switch (r)
	   {
             case 1: soma();
                     break;
             case 2: subtracao();
                     break;
             case 3: produto();
                     break;
             case 4: divisao(); 
                     break;
       }
	} while (r != 0);
	system("pause");
	return 0;
} 
