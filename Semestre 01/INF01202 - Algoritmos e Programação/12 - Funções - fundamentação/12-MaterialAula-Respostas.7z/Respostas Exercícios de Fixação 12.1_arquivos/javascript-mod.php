// Javascript from Moodle modules
