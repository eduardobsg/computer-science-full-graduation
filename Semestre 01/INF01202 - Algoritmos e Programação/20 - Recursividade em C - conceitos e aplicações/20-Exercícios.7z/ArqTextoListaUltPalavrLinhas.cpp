/*
Problema:

 Gera��o de um arquivo texto (uma fun��o), com o seu conte�do digitado pelo usu�rio em 
 tempo de execu��o (como textos de teste sugere-se trechos dos  hinos Nacional, Riograndense, ou de times).
 O n�mero de linhas fornecidas em uma particular execu��o poder� ser maior ou igual a 1.
Sugere-se na digita��o do texto:  colocar apenas um espa�o separador entre cada palavra; colocar os sinais de 
pontua��o sempre encostados na palavra que os precede, com o espa�o inserido a seguir (ex.: Isso eh um teste. 
So para entender o que foi dito.). 
Apresentar ao final da gera��o do arquivo, na fun��o main,  o total de linhas gravadas.

Ap�s cria��o completa do arquivo, apresenta��o da �ltima palavra de cada linha do arquivo texto rec�m gerado (uma fun��o).

Apresentar ao final do processamento, na fun��o main, o n�mero de linhas processadas nessa segunda etapa.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 80

FILE *arq;
FILE* AbreArquivo(char [ ], int);
void GravaArq(FILE *, int*);
void LeArq(FILE *, int*);
void ApresentArq(FILE *, int *);

int main (  ) 
{
    char nomearq[MAX];
    int gravs = 0, lidas = 0;
    system("color f1"); 
    printf("Gravar dados no arquivo:\n");
    if(!(arq = AbreArquivo("w", MAX)))     
       {
         printf("\nErro na gravacao do arquivo\n"); 
         system ("pause");   
       }
    else
       {
         GravaArq(arq, &gravs);  
         fclose(arq);
         printf("\nLinhas gravadas = %d\n", gravs); 
         printf("\nLer dados no arquivo:\n");      
         if(!(arq = AbreArquivo("r", MAX)))
            {
             printf("\nErro na gravacao do arquivo\n"); 
             system ("pause");   
            }
         else
            {
              LeArq(arq, &lidas);
              printf("\nLinhas lidas (apresentacao das ultimas palavras)= %d\n\n", lidas);   
              rewind(arq);
              lidas = 0;
              ApresentArq(arq, &lidas);
              printf("\nLinhas lidas (apresentacao do texto) = %d\n", lidas);               
              system("pause");
              return 0;   
            }   
        }      
}
FILE * AbreArquivo(char qualarq [ ], int max)
  {
     char nomearq[max];
     printf("Nome do arquivo: ",  max - 1);
     fgets(nomearq, sizeof(nomearq), stdin);
     if (nomearq[strlen(nomearq) - 1] == '\n')
         nomearq[strlen(nomearq) - 1] = '\0';
     fflush(stdin);
     return fopen(nomearq,qualarq);
  } 
  
void GravaArq(FILE *arq1, int *gravadas)
{
    char linha[80]; 
    printf("\nForneca as linhas de texto, para parar linha so com @ no inicio.");
    printf("\nEntre palavras um so espaco em branco, e apos a ultima so o enter\n\n"); 
    while (linha[0] != '@')
     {
       fgets(linha, sizeof(linha), stdin);
       if (linha[0] != '@')
        {
         fputs(linha, arq1);
         *gravadas = *gravadas + 1; 
        }  
     }
 }

void ApresentArq(FILE *arq1, int *lids)
{
     char caract;
     while ((caract = getc(arq1)) != EOF)
      {
        if (caract == '\n')
           *lids = *lids + 1;
        putc(caract, stdout);
       
      }
}
void LeArq(FILE *arq1, int *lids)
{
     char linha[80];
     int i, j;
     if (fgets(linha, sizeof(linha), arq1) != NULL)
         (*lids)++;
     while (!(feof(arq1)))
      {
        if (linha[strlen(linha) - 1] == '\n')
            linha[strlen(linha) - 1] = '\0';
        printf("\n");    
        for (i = strlen(linha) - 1; i > 0 && linha[i] != ' '; i--);
        if (i == 0)
            j = 0;
        if (linha[i] == ' ')
            j = i + 1;
        for ( ;j < strlen(linha); j++)
              putc(linha[j], stdout);
         printf("\n");  
         if (fgets(linha, sizeof(linha), arq1) != NULL)  
            (*lids)++;     
      }
}
