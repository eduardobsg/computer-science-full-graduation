/*
  Name: 
  Copyright: 
  Author: 
  Date: 15/06/09 14:58
  Description: 

	Fa�a um programa que ative, quantas vezes o usu�rio desejar, e em 
	qualquer ordem, as duas fun��es inteiras recursivas a seguir:
		
    a)  verifica se um n�mero � capicua 
       (o mesmo que pal�ndromo, s� que para n�meros);
    b)  calcula um termo solicitado da s�rie de    	Fibonacci:
                      f0 = 1 
                      f1 = 1
                      fn = fn-1 + fn-2	
		
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 20

int ve_se_eh_capicua (char *, int, int);
int determina_elem_fibo (int, int, int);

int main ()
{
	int cod, valor;
	char numero[MAX];
	do
	{
		printf ("O que dseja fazer?");
		printf ("\n1 - Ver se numero eh capicua");
		printf ("\n2 - Determinar elemento fibonacci");
		printf ("\n0 - Para parar");
		printf ("\nCodigo: ");
		scanf ("%d", &cod);
		if (cod == 1)
		{
			printf ("\nInsira um valor: ");
			fflush (stdin);
			fgets (numero, sizeof (numero), stdin);
			if (numero[strlen(numero) - 1] == '\n')
				numero[strlen(numero) - 1] == '\0';
			if ((ve_se_eh_capicua (numero, 0, strlen(numero) - 2)) == 1)	
				printf ("\nNumero eh capicua\n\n");
			else
				printf ("\nNumero nao eh capicua\n\n");
		}
		if (cod == 2)
		{
			//0 -> primeiro elemento
			//1 -> segundo elemento
			printf ("\nExibir elemento da s�rie de Fibonacci de posicao (maior que 0): ");
			scanf ("%d", &valor);
			printf ("Elemento %d: %d\n\n", valor, determina_elem_fibo (1, 1, valor - 1) );
		}
	} while (cod != 0);
	printf ("\n\n");	
	system ("pause");
	return 0;
}

int ve_se_eh_capicua (char *vet, int inicio , int fim)
{
   if (inicio > fim)
       return 1;
   else
        {
          if (vet[inicio] == vet[fim])
            return ve_se_eh_capicua(vet, inicio + 1, fim - 1);
          else 
            return 0;         
        }
}
 
int determina_elem_fibo (int prim, int seg, int num_limite)
{
   if (num_limite == 0)
       return prim;
   else
       return determina_elem_fibo(seg , prim + seg, num_limite - 1);   
}
