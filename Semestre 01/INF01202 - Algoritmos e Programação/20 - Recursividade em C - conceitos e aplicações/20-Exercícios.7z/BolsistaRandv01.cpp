/*
   Cria um arquivo binario de forma randomica a partir
   de outro ja existente, que foi gerado sequencialmente.
   Lista o arquivo randomico gerado.
*/
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>
#define MAXSTR 31
#define MAXCODIGO 25
struct bolsistas_orig
   {
	 int codigo;
     char nome[MAXSTR];
	 int tipo_bolsa;
	 char e_mail[MAXSTR];
    };
struct bolsistas_novo
   {
	 int codigo;
     char nome[MAXSTR];
	 int tipo_bolsa;
	 char e_mail[MAXSTR];
	 int mes;
	 int ano;
    };
FILE *arq_orig; 
FILE *arq_novo;
FILE * AbreArquivo(char [ ], int);
void GeraArqNovo(FILE *, struct bolsistas_orig, FILE * , struct bolsistas_novo, int*);
int ler_dados(FILE *, struct bolsistas *, int, int);
void ListaArqNovo(FILE *arq_novo, struct bolsistas_novo);   
    
int main()
 {
   struct bolsistas_orig bolsis_orig;
   struct bolsistas_novo bolsis_novo;
   int lidos = 0;
   system("color 71");
   if(!(arq_orig = AbreArquivo("rb", MAXSTR)))
         { 
          printf("Erro na abertura do arquivo original\n");
          system("pause");
         }
     else
         {
           if (!(arq_novo = AbreArquivo("wb+", MAXSTR)))
              { 
                printf("Erro na abertura do arquivo novo para gravacao\n");
                system("pause");
              }
           else
              { 
                GeraArqNovo(arq_orig, bolsis_orig, arq_novo, bolsis_novo, &lidos);
                printf("\nBolsistas lidos: %d\n", lidos);
                fclose(arq_orig);
                rewind(arq_novo);
                ListaArqNovo(arq_novo, bolsis_novo);  
                fclose(arq_novo);
                system("pause");
                return 0;             
              }  
         }
  }
void GeraArqNovo(FILE *arq_orig2, struct bolsistas_orig bolsis_orig2,FILE *arq_novo2, 
     struct bolsistas_novo bolsis_novo2, int *lids)
 {
  int mes_aux = 0, ano_aux = 0;
  while (!feof(arq_orig2))
      {
        if (fread(&bolsis_orig2, sizeof(struct bolsistas_orig), 1, arq_orig2) == 1)
            {
              (*lids)++;
              fseek(arq_novo2, (bolsis_orig2.codigo - 1) * sizeof(struct bolsistas_novo), SEEK_SET);
              fwrite(&bolsis_orig2, sizeof(struct bolsistas_orig), 1, arq_novo);
              fwrite(&mes_aux, sizeof (int), 1, arq_novo);
              fwrite(&ano_aux, sizeof (int), 1, arq_novo);                     
            }                                    
       }
}     
void ListaArqNovo(FILE *arq_novo, struct bolsistas_novo bolsis_novo2)   
 {
   while (!feof(arq_novo))
      {
        if (fread(&bolsis_novo2, sizeof(struct bolsistas_novo), 1, arq_novo) == 1)
            {   
	          if (bolsis_novo2.codigo != 0)
	             {
                  printf("\nCodigo: %d",bolsis_novo2.codigo);
	              printf("\nNome: ");
	              puts(bolsis_novo2.nome);
	              fflush(stdin);
	              printf("Tipo da bolsa: ");
                  switch (bolsis_novo2.tipo_bolsa)
                     {
                       case 1:  printf("%d - trabalho", bolsis_novo2.tipo_bolsa);  
                                break;
                       case 2:  printf("%d - iniciacao", bolsis_novo2.tipo_bolsa);  
                                break;
                       case 3:  printf("%d - pesquisa", bolsis_novo2.tipo_bolsa);  
                                break;
                     }
	              fflush(stdin);
                  printf("\nE-mail: ");
                  //a linha seguinte tira, antes de apresentar na tela,
                  // o \n que ficou armazenado no campo e-mail
                  bolsis_novo2.e_mail[strlen(bolsis_novo2.e_mail) - 1] = '\0';
                  puts(bolsis_novo2.e_mail);
                  printf("Mes de inicio da bolsa: %d\n", bolsis_novo2.mes);
	              printf("Ano de inicio da bolsa: %d\n\n", bolsis_novo2.ano);
                }      
           }
      }
  }    
FILE * AbreArquivo(char qualarq [ ], int max)
  {
     char nomearq[max];
     printf("Forneca o nome do arquivo  (com no maximo %d caracteres): ",  max - 1);
     fgets(nomearq, sizeof(nomearq), stdin);
     if (nomearq[strlen(nomearq) - 1] == '\n')
         nomearq[strlen(nomearq) - 1] = '\0';
     fflush(stdin);
     return fopen(nomearq,qualarq);
  } 
