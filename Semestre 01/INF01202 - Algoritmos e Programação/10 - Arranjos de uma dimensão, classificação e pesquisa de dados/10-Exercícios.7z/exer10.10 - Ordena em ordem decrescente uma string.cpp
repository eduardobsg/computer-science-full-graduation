/*
  Name: 
  Author: Jo�o Luiz Grave Gross
  Date: 01/04/09 21:06
  Description: Criar por leitura um vetor inteiro de 160 posi��es.
  Os valores dever�o ser fornecidos de forma desordenada.
  Imprimir o vetor lido (mais de um valor por linha, at� um m�ximo de 20 valores por linha).
  Classificar o vetor em ordem descendente e apresent�-lo classificado.
  Uma vez criado e listado o vetor (vers�o original e vers�o classificada), atender a um n�mero indeterminado de 
  solicita��es do usu�rio.
  Solicita��es do usu�rio: para cada valor inteiro informado (valores extras, al�m daqueles que preencheram o vetor), 
  at� que o usu�rio informe que deseja parar, apresentar (em ordem decrescente) todos os valores maiores que o valor 
  informado que existem no vetor.
  Se um valor informado n�o pertencer ao vetor lido, s� retornar uma mensagem dando conta desse fato.
  Cada um(a) poder� definir � sua vontade a marca de parada dessa fase do processamento (que dever� processar n solicita��es).
  Para a pesquisa sobre o vetor dever� ser usada pesquisa bin�ria.
  IMPORTANTE: Solicita-se que seja usada uma constante para definir o tamanho do vetor, e sugere-se que na fase de testes 
  seja utilizado um vetor de tamanho reduzido.
  
  Resumo:
  1) Capturar n valores em uma string       
  2) Classificar os n valores em ordem decrescente 
  3) Exibir os n valores da string na ordem digitada e decrescente
  4) Capturar um valor extra -> exibir todos os valores maiores do que o valor digitado em ordem decrescente
  5) Repetir 4) at� o usu�rio decidir finalizar o programa
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 6

int main ()
{
   int vet[MAX], aux, i, m, k, trocou, passo = 0, j = 0, inf, sup, med, val, achado;
   char solic[3];     //solicitacao
   system("color f1");
   
   //1) Capturar "MAX" valores e armazena na string vet
   printf("Forneca os %d elementos do vetor\n", MAX);
   for (i = 0; i < MAX; i++)
   {
      printf("Elemento [%d]: ", (i+1)); 
      scanf("%d", &vet[i]);                  
   }   
   printf("\nVetor lido:\n");
   for (i = 0; i < MAX; i++)
   {
      printf("%d  ", vet[i]);    
      j++;
      if (j == 20)
         printf ("\n");
   }
   
   //2) Classifica os "MAX" valores armazenados em vet, na ordem decrescente, pelo m�todo bubblesort
   trocou = 1; 
   m = (MAX-1); 
   k = 1; 
   while (trocou)
   {
      trocou = 0;
      //printf("\nPasso%d:\n", passo);
      for (i = 0; i < m; i++)
          if (vet[i] <  vet[i+1])
          {
             aux = vet[i+1];
             vet[i+1] = vet[i];              //vet[i+1] pega um valor menor do que vet[i]
             vet[i] = aux;
             k = i;                      //posteriormente m � igualado a k, reduzindo o n�mero de itera��es do la�o for aos poucos
                                         //torna a classifica��o mais r�pida
             trocou = 1;
             //for (j = 0; j < MAX; j++)
             //    printf("%3d", vet[j]); 
             //printf ("\n");
          }
      m = k;
      passo++;
   }  
   
   //3) Exibir os "MAX" valores de vet classificados
   printf ("\n\nVetor classificacao - ordem decrescente:\n");
   for (i = 0; i <= MAX - 1; i++)
      printf ("%d  ", vet[i]);   

   //4) Capturar um valor extra -> exibir todos os valores maiores do que o valor digitado em ordem decrescente
   trocou = 1;
   while (trocou)
   {
      printf ("\n\n");   
      for (i = 0; i < 1; i++)
      { 
         printf ("Inserir solicitacao (sim | nao): ");    
         scanf ("%s", solic);
         if ((solic[0] == 's' && solic[1] == 'i' && solic[2] == 'm') || (solic[0] == 'S' && solic[1] == 'I' && solic[2] == 'M'))
            j = 1;
         else   
            if ((solic[0] == 'n' && solic[1] == 'a' && solic[2] == 'o') || (solic[0] == 'N' && solic[1] == 'A' && solic[2] == 'O'))
            {
               j = 0;
               trocou = 0;
            }
            else 
            {
               printf ("A resposta deve ser \"sim\" ou \"nao\". Tente denovo.\n\n");
               i--;
            }
      } 
      while (j)
      {
         //M�todo de Pesquisa Bin�ria   
         printf ("\nDigite um valor: ");
         scanf ("%d", &val);              
         inf = 0; 
         sup = MAX - 1; 
         achado = 1;
         while (inf <= sup && achado)
         {
             med = (inf + sup) / 2;
             if (val == vet[med])
                achado = 0; 
             else
                if (val < vet[med])
                    inf = med + 1;
                else
                    sup = med - 1;
         }      
         j = 0;      
         if (!achado)
         {
            printf ("Valores maiores que %d:", val);
            for (i = 0; i < med; i++)
               if (vet[i] != val)
                  printf (" %d  ", vet[i]);
         }
         else
            printf ("Valor %d nao encontrado !!!\n", val);    
      }   
   }

   printf ("\nFinalizando Programa.");
   printf("\n\n");         
   system ("pause");
   return 0;
}
