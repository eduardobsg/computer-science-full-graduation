//pesquisa sequencial sobre o arranjo a

#include <stdio.h>
#include <stdlib.h>

#define MAX 5

int main ()
{
   int a[MAX] = {28, 26, 30, 24, 25};
   int i, val, achou;
   printf ("\t>>> PESQUISA SEQUENCIAL <<<\n\n");
   printf ("Imprimindo o arranjo com os dados\n\n");
   for (i = 0; i < MAX; i++)
          printf ("%d\t", a[i]);
   printf ("\n\nForneca valor procurado: ");
   scanf ("%d", &val);
   printf ("\nPesquisando . . .\n\n");
   i = 0; 
   achou = 0;
   while (i < MAX && !achou)
       if (a[i] == val)
            achou = 1;
       else
            i++;
   if (!achou)
      printf ("Valor %d nao encontrado!!!\n\n", val);
   else
      printf ("O valor %d foi encontrado na posicao %d\n\n", val, i);
   system ("pause");
   return 0;
}
