//M�todo Bolha (bubblesort) -> Classifica��o Crescente

#include <stdio.h>
#include <stdlib.h>
#define MAX 5

int main ( )
{
   int a [MAX], aux, i, m, k, trocou, passo = 0, j;
   //system("color f1");
   printf ("\t>>> BUBBLESORT <<<\n");
   printf ("\t(em ordem crescente)\n\n");
   printf("Forneca os %d elementos do vetor\n", MAX);
   for (i = 0; i < MAX; i++)
   {
      printf("Elemento [%d]: ", i + 1); 
      scanf("%d", &a[i]);                  
   }   
   printf("\nVetor lido\n");
   for (i = 0; i < MAX; i++)
      printf("%6d", a[i]);    
   trocou = 1; 
   m = (MAX-1); 
   k = 1; 
   while (trocou)
   {
      trocou = 0;
      printf("\nPasso%d:\n", passo);
      for (i = 0; i < m; i++)
          if (a[i] >  a[i+1])
          {
             aux = a[i];
             a[i] = a[i+1];
             a[i+1] = aux;
             k = i;                      //posteriormente m � igualado a k, reduzindo o n�mero de itera��es do la�o for aos poucos
                                         //torna a classifica��o mais r�pida
             trocou = 1;
             for (j = 0; j < MAX; j++)
                 printf("%6d", a[j]); 
             printf ("\n");
          }
      m = k;
      //printf("\nPasso %d\n", passo);
      //for (j = 0; j < MAX; j++)
          //printf("%6d", a[j]); 
      passo++;
   }   
   printf ("\n\nImpressao do arranjo classificado\n");
   for (i = 0; i <= MAX - 1; i++)
          printf ("%d\t", a[i]);
   printf("\n");         
   system ("pause");
   return 0;
}
