//pesquisa bin�ria sobre o arranjo a

#include <stdio.h>
#include <stdlib.h>

#define MAX 15

int main ()
{
   int a[MAX] = {2, 15, 17, 30, 32, 34, 40, 50, 80, 90, 95, 97, 99, 101, 105};
   int i, inf, sup, med, val, achado;
   system ("color f1");
   printf ("\t>>> PESQUISA BINARIA <<<\n\n");
   printf ("Imprimindo o arranjo classificado\n\n");
   for (i = 0; i < MAX; i++)
          printf ("%d  ", a[i]);
   printf ("\n\nForneca valor procurado: ");
   scanf ("%d", &val);
   printf ("\nPesquisando . . .\n\n");
   inf = 0; 
   sup = MAX - 1; 
   achado = 1;
   while (inf <= sup && achado))
   {
         med = (inf + sup)/2;
         if (val == a[med])
             achado = 0; 
         else
             if (val > a[med])
                inf = med + 1;
             else
                sup = med - 1;
   }            
   if (!achado)
      printf ("Valor %d encontrado na posicao %d\n\n", val, med);
   else
      printf ("Valor %d nao encontrado !!!\n\n", val);
   system ("pause");
   return 0;
}   
