#include <stdio.h>
#include <stdlib.h>
#define MAXVET 5

int main (  )
 { 
   int vet[MAXVET]; 
   int i, j, k, aux; 
   system("color f1");
   //leitura do vetor
   printf("Forneca os %d elementos do vetor\n", MAXVET);
   for (i=0;i<MAXVET;i++)
    {
      printf("Elemento [%d]: ", i + 1); 
      scanf("%d", &vet[i]);                  
    }   
   printf("\n\nVetor lido\n");
   for (i=0;i<MAXVET;i++)
     printf("%6d", vet[i]); 
   printf("\n\n"); 
   //trecho da classificacao 
   for (i =0;i < MAXVET;i++)
     {
       for (j=0;j<MAXVET;j++)
         if (i!=j)
            if (vet[i] < vet[j])
               {
                 aux = vet[i];
                 vet[i] =vet[j];
                 vet[j] = aux;
                 printf ("\n%d   %d   %d   %d   %d",vet[0],vet[1],vet[2],vet[3],vet[4]);
               }
     }
   printf("\n\nVetor classificado\n");
   for (i=0;i<MAXVET;i++)
     printf("%6d", vet[i]);  
   printf("\n\n");               
   system("pause");  
   return 0;  
 }
