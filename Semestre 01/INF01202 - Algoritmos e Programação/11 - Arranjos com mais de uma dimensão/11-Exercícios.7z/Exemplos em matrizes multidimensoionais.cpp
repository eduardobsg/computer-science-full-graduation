/*
  Name: 
  Author: 
  Date: 18/04/09 14:56
  Description: Dada uma matriz M (MAXLIN, MAXCOL), preench�-la por leitura e imprimir:
  - o maior elemento de cada linha da matriz;
  - a m�dia dos elementos de cada coluna;
  - o produto de todos os elementos diferentes de zero;
  - quantos elementos s�o negativos;
  - posi��o ocupada (linha-coluna) por um elemento cujo valor ser� lido pelo programa.

*/
// Inserir cabecalho �#include <stdio.h>

#include <stdlib.h>
#include <stdio.h>
#define MAXLIN 10
#define MAXCOL 3

int main ()
{  
   int m [MAXLIN] [MAXCOL]; 	//declaracao da matriz
   int lin, col; //indices de linha e coluna
   int maior, somacol, negativos, valor, achou;
   double produto;
   float mediacol;
   
   //inicializacao da matriz
   for (lin = 0; lin < 10; lin++) 	
        for (col = 0; col < 3; col++)
        {    
             printf ("Forneca valor inteiro m [%d] [%d]: ", lin, col);
             scanf ("%d", &m[lin] [col]);
        }
        
   //impress�o da matriz
   for (lin = 0; lin < 10; lin++) 	
     {  
        printf ("Linha %d\t", lin);    
        for (col = 0; col < 3; col++)
              printf ("\t%d", m[lin] [col]);
        printf ("\n\n");       
     }

   //procurando o maior valor de cada linha     
   for (lin = 0; lin < 10; lin++) 
     {    
        maior = m [lin] [0]; //sup�e que o 1�. Eh o maior
        for (col = 1; col < 3; col++)
             if (maior < m[lin] [col]) //compara maior com os outros
                 maior = m[lin] [col]; //se existir algum > que maior, troca
        printf ("\n\nMaior valor da linha %d eh %d", lin, maior);
     }
     
   //calculando a media da coluna  
   for (col = 0; col < 3; col++) 
     {
        somacol = 0; //a cada coluna, inicializa somacol
        for (lin = 1; lin < 10; lin++)
             somacol += m[lin] [col]; //acumula valores da coluna
        printf ("\n\nA media da coluna %d eh %.2f", col, (float)somacol/MAXLIN);
     }  
   
   //calculando o produto dos valores != 0  
   produto = 1; //inicializa em 1, pois eh produto!
   for (lin = 0; lin < 10; lin++) 
       for (col = 0; col < 3; col++)
            if ( m[lin] [col] != 0 )
                 produto *= m[lin] [col];
   printf ("\n\nO produto dos valores != 0 eh: %e", produto);
   
   //calculando o total de negativos
   negativos = 0; //inicializa em 0, pois eh contador!
   for (lin = 0; lin < 10; lin++) 
        for (col = 0; col < 3; col++)
             if ( m[lin] [col] < 0 )
                  negativos++;
   printf ("\n\nO total de valores < 0 eh: %d", negativos);  
      printf ("\n\nForneca valor a ser procurado: ");
   scanf ("%d", &valor);
   achou = 0;
   
   //procurando o valor fornecido �
   for (lin = 0; lin < 10; lin++) 
        for (col = 0; col < 3; col++)
             if ( m[lin] [col] == valor )
             {
                  achou = 1;
                  printf ("\n\nValor estah em: [%d] [%d]",lin, col);
             }
   if (!achou)
       printf ("\n\nValor n�o encontrado!");
   printf ("\n\n");
   system ("pause");
} 
