/*
  Name: exerc12.1.4 - Define se a matriz � triangular
  Author: 
  Date: 18/04/09 19:19
  Description: Uma matriz quadrada � dita triangular se os elementos situados acima de sua diagonal 
  principal s�o todos nulos. Escreva um programa C que  receba uma matriz quadrada 
  com ordem de no m�ximo 30, atrav�s de uma vari�vel e determine se ela � triangular 
  ou n�o.
*/

#include <stdlib.h>
#include <stdio.h>

#define ORDEM 30

int main ()
{
    int matriz[ORDEM] [ORDEM], i, j, n;
    printf ("Defina o tamanho na matriz (2 a 30): ");
    scanf ("%d", &n);
    
    //montando a matriz[n] [n]
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
        {
            printf ("matriz[%d] [%d]: ", i, j);
            scanf ("%d", &matriz[i] [j]);
        }   
        
   //mostra matriz
    for (i = 0; i < n; i++)
    {
        printf ("\n");
        for (j = 0; j < n; j++)    
            printf ("%d\t", matriz[i] [j]);
    }
        
   //ver se a matriz � triangular
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            if (i == j)
            {
               for (j = j+1; j < n; j++)
                   if (matriz[i] [j] != 0)
                      i = n+1;      
            }
   if (i >= n+1)
      printf ("\nMatriz nao eh triangular!");
   else
      printf ("\nMatriz eh triangular!");            
    
    printf ("\n\n");
    system ("pause");
    return 0;
}
