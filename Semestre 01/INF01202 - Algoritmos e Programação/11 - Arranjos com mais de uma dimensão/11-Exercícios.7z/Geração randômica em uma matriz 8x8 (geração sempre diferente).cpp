/*
  Name: 
  Copyright: 
  Author: 
  Date: 18/04/09 17:06
  Description:  Gerar uma matriz 8X8 de valores aleat�rios no intervalo [1,200] 
  e mostrar a soma dos elementos da diagonal principal
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>         // biblioteca para fun��es de tempo, necess�ria para usar time

#define LIMINTERVALO 200

int main ( )
{
  int lin, col,i,j,soma;
  int m[8][8];

  long int ultime;
  time(&ultime);
  srand( (unsigned) ultime);
  
  //gerando os valores aleat�rios no [1,200]
  for (lin = 0; lin < 8; lin++)        
  for (col = 0; col < 8; col++)
       m[lin] [col] = 1 + rand() % LIMINTERVALO;
  
  // mostrar a matriz gerada
  printf("Matriz gerada com valores entre 1 e 200\n");
    for (i = 0; i < 8; i++)
      {
       printf("\n");
       for (j = 0; j < 8; j++)
            printf("%5d", m[i][j]);
       }
  printf("\n");	
  
  //calculando a soma dos valores da diagonal
  soma = 0;                                 //inicializa em 0, pois eh soma!
  for (lin = 0; lin < 8; lin++)             
       for (col = 0; col < 8; col++)
            if ( lin == col )
                 soma= soma + m[lin] [col];
  printf ("\n\n A soma dos elementos da diagonal principal vale: %d \n", soma);
  system("pause");
  return 0;
}
