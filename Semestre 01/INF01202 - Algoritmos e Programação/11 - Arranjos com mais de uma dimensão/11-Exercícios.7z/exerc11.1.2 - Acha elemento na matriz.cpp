/*
  Name: exerc12.1.2 - Acha elemento na matriz
  Author: Jo�o Luiz Grave Gross
  Date: 18/04/09 17:24
  Description: Fazer um programa C que localiza o elemento Minimax de uma matriz quadrada 4 x 4, 
i.e., o menor elemento da linha que contem o maior elemento da matriz.
*/

#include <stdio.h>
#include <stdlib.h>

#define MAXLIN 4
#define MAXCOL 4

int main ()
{
    int matriz[MAXLIN] [MAXCOL], minimax, maior, menor, i, j, linha, coluna;
    printf ("Insira o valor de Minimax: ");
    scanf ("%d", &minimax);
    
    //Captura os valores da matriz
    for (i = 0; i < MAXLIN; i++)
        for (j = 0; j < MAXCOL; j++)
        {
            printf ("Matriz [%d] [%d]: ", i, j);
            scanf ("%d", &matriz[i] [j]);
        }
    
    //Procura minimax
    for (i = 0; i < MAXLIN; i++)
        for (j = 0; j < MAXCOL; j++)
            if (minimax == matriz[i] [j])
               printf ("Minimax encontrado: Matriz [%d] [%d]\n", i, j);
             
    //mostrar matriz
    for (i = 0; i < MAXLIN; i++)
    {
        printf ("\nLinha %d:", i);
        for (j = 0; j < MAXCOL; j++)
            printf ("\t%d", matriz[i] [j]);
    }          
               
   //Procura maior valor
   maior = matriz[0] [0];
   for (i = 0; i < MAXLIN; i++)
        for (j = 0; j < MAXCOL; j++)
            if (maior < matriz[i] [j])
            {
               maior = matriz[i] [j];
               linha = i;
            }          
   
   //Procura menor valor da linha com o maior
   i = linha;
   menor = matriz [i] [0];
   for (j = 0; j < MAXCOL; j++)
            if (menor > matriz[i] [j])
            {
               menor = matriz[i] [j];
               coluna = j;
            }
   
   printf ("\n\nMaior valor (linha %d): %d", linha, maior);             
   printf ("\nMenor valor de linha %d: %d", linha, matriz[linha] [coluna]);
   
   printf ("\n\n");
   system ("pause");
   return 0;
}
                                                   
               















