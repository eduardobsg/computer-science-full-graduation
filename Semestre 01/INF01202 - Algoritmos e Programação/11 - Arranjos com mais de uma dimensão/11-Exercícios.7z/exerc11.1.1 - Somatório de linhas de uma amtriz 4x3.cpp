/*
  Name: exerc12.1.1 - Somat�rio de linhas de uma amtriz 4x3
  Author: Jo�o Luiz Grave Gross
  Date: 18/04/09 17:12
  Description: Ler uma matriz 4 x 3 de inteiros. Calcula e apresenta os somat�rios dos
  valores da primeira linha da matriz e da �ltima coluna. Apresenta a matriz. 
*/

#include <stdio.h>
#include <stdlib.h>

#define MAXLIN 4
#define MAXCOL 3

int main ()
{
    int matriz[MAXLIN] [MAXCOL], somatorio, i, j;
    printf ("Insira os valores na matriz: \n");
    for (i = 0; i < MAXLIN; i++)
        for (j = 0; j < MAXCOL; j++)
        {
            printf ("Matriz [%d] [%d]: ", i, j);
            scanf ("%d", &matriz[i] [j]);
        }
    
    //somat�rio da primeira linha
    somatorio = 0;
    i = 0;
    for (j = 0; j < MAXCOL; j++)
            somatorio = somatorio + matriz[i] [j];
    printf ("\nSomatorio linha 1: %d\n", somatorio);
    
    //somat�rio da �ltima linha
    somatorio = 0;
    i = MAXLIN - 1;
    for (j = 0; j < MAXCOL; j++)
            somatorio = somatorio + matriz[i] [j];
    printf ("\nSomatorio linha %d: %d\n", (MAXLIN-1), somatorio);
    
    //mostrar matriz
    for (i = 0; i < MAXLIN; i++)
    {
        printf ("\nLinha %d:", i);
        for (j = 0; j < MAXCOL; j++)
            printf ("\t%d", matriz[i] [j]);
    }
    printf ("\n\n");
    system ("pause");
    return 0;
}











