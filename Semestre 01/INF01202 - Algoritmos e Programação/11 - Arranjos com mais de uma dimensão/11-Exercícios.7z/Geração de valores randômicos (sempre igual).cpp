/*
  Name: 
  Author: 
  Date: 18/04/09 16:52
  Description: Exemplo de gera��o de valores em um intervalo [0,n-1]
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 10

int main ()
{
  int n,l,x, flag=1;
  while (flag)
  {
  printf("Entre com um numero inteiro limitador do intervalo de geracao, maior que zero e menor que 200: ");
  scanf("%d",&n);
  printf("\nGeracao de %d valores no intervalo de [0, %d]\n", MAX, n-1);
  printf("\n");
  for (l = 1; l <= MAX ; l++)
  {
      x = rand() % n; //  x ter� um valor de 0 at� n-1
      printf("Iteracao %d -> Valor %d \n",l,x);
  }
  printf ("\nContinuar\? (1 - sim | 0 - nao)\n");
  scanf ("%d", &flag);
  }
  system("pause");
  return 0;
}




























        
