/*
  Name: Gross_180171_avaliacao11.11 - sistema de emiss�o de bilhetes de companhia a�rea
  Author: Jo�o Luiz Grave Gross
  Date: 18/04/09 21:28
  Description: Desenvolva um programa para simular o sistema de emiss�o de bilhetes 
  de uma companhia a�rea. A companhia possui N voos onde, em cada um dos quais, existe M lugares 
  dispon�veis. Os primeiros M/2 lugares de cada voo est�o reservados para especiais, que s�o 
  adultos com mais de 70 anos e pessoas com necessidades especiais. 
  
  C�digos:
  c�digo para pessoas com mais de 70 anos = 70
  c�digo para pessoas com necessidades especiais = 00
  lugares restantes de cada v�o est�o reservados para os demais (c�digo = 50). 
  
  Fa�a uma solu��o em linguagem C que simule a reserva de v�os e que apresente as seguintes estat�sticas:

  - o n�mero m�dio de passageiros por v�o; (ok)
  - o n�mero m�dio de passageiros por �rea no avi�o; (ok)
  - o n�mero m�dio de passageiros n�o embarcados por falta de assento (notar que pode haver 
  lugar no avi�o, mas n�o haver na �rea correspondente); (ok)
  - o n�mero m�dio de passageiros especiais, discriminados em suas subclasses. (ok)

  Os valores que seguem devem ser gerados aleatoriamente,:

  - n�mero do v�o (ok)
  - n�mero de passageiros do v�o; (ok)
  - c�digo do tipo do passageiro. (ok)

  Apresentar a tabela gerada e as estat�sticas. Os valores de N est�o no intervalo [1 , 25 ] 
  e M no intervalo [50 , 200] . Criar uma matriz de N linhas, onde a linha representa cada voo 
  e M colunas para representar os assentos e inicialize os elementos desta matriz com zeros 
  para indicar que todos os assentos de cada um dos v�os est�o dispon�veis. � medida que os
  assentos forem sendo ocupados atribua o valor 1 ao elemento correspondente da matriz.
 
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 25
#define M 151

int main ()
{
    int voo[N] [M], numero_voo[N], passageiros [M], numero_passageiros, i, j, k, n, m, x, conta_especiais, conta_normais;
    int media_pass_voo, media_pass_area_especial, media_pass_area_normal, media_pass_not_in, media_pass_area_especial_70, media_pass_area_especial_00;     
    
    //define gera��o rand�mica de valores sempre diferente
    long int ultime;
    time(&ultime);
    srand( (unsigned) ultime);

    printf ("########################################\n");
    printf ("############   RELATORIO   #############\n");
    printf ("########################################\n\n\n");
    //gera��o rand�mica de N (n�meors de v�os), M (Poltronas por v�o)
    n = 1 + rand () % N;
    printf ("Numero de voos: %d\n", n);
    m = 50 + rand () % M;
    printf ("Numero maximo de passageiros por voo: %d\n", m);
    
    //gera��o rand�mica do n�mero dos v�os 
    for (i = 0; i < n; i++)
        numero_voo[i] = 1000 + rand () % 9000;
       
    //inicializa��o de vari�veis para a realiza��o das m�dias
    media_pass_area_especial = 0;
    media_pass_area_normal = 0;    
    media_pass_not_in = 0;
    media_pass_area_especial_00 = 0;
    media_pass_area_especial_70 = 0;
    media_pass_voo = 0;
    printf ("\n");
    
    for (i = 0; i < n; i++)
    {
        printf ("-------------------------------------\n-------------------------------------\nVoo %d (codigo %d): \n", i, numero_voo[i]);
        conta_especiais = 0;
        conta_normais = 0;
        numero_passageiros = rand () % m;      //numero de passageiros em cada voo
        
        printf ("\nTotal de assentos: %d\n", m);
        
        //Gera os c�digos rad�micos dos passageiros
        for (j = 0; j < numero_passageiros; j++)
        {
            x = rand () % 3;
            if (x == 0)
               passageiros[j] = 00;
            if (x == 1)
               passageiros[j] = 50;
            if (x == 2)
               passageiros[j] = 70;   
        }
        
        //V� a quantidade de c�digos de cada tipo   
        for (j = 0; j < numero_passageiros; j++)
        {
            if (passageiros[j] == 00)
            {
               media_pass_area_especial++;
               media_pass_area_especial_00++;
               conta_especiais++;
               if (conta_especiais > (m/2))
                  media_pass_not_in++;      
            }
            if (passageiros[j] == 70)
            {
               media_pass_area_especial++;
               media_pass_area_especial_70++;
               conta_especiais++;
               if (conta_especiais > (m/2))
                  media_pass_not_in++;      
            }
            if (passageiros[j] == 50)            
            { 
               media_pass_area_normal++;
               conta_normais++;
               if (conta_normais > (m/2 + m % 2))        //utilizei o m%2 em caso de m ser �mpar, ou seja, n�mero de lugares no avi�o ser �mpar
                   media_pass_not_in++; 
            }
            media_pass_voo++;
        }
        printf ("\t%d assentos especiais disponiveis\n\t%d assentos normais disponiveis\n", (m/2), (m/2 + m % 2));        
        printf ("Demanda por assentos no voo (passageiros no voo): %d / %d", conta_especiais + conta_normais, m);       
        printf ("\n\t%d para assentos especiais\n\t%d para assentos normais", conta_especiais, conta_normais);     
            
        //Define a quantidade de vagas dispon�veis para cada �rea (normal e especial)
        if (conta_especiais < (m/2))
           conta_especiais = m/2 - conta_especiais ;   //n�mero de vagas dispon�veis para passageiros especiais 
        else
           conta_especiais = 0; 
        if (conta_normais < (m/2 + m % 2))  
           conta_normais = (m/2 + m % 2) - conta_normais;  //n�mero de vagas dispon�veis para passageiros normais
        else
           conta_normais = 0;  
            
        printf ("\nAssentos disponiveis no voo: \n\t%d - especiais\n\t%d - normais\n", conta_especiais, conta_normais);                         
    }  
    printf ("-------------------------------------\n-------------------------------------\n");
            
    //c�lculo das m�dias
    media_pass_voo /= n;
    printf ("\nMedia de passageiros por voo: %d\n", media_pass_voo);
    media_pass_area_especial /= n;
    printf ("\nMedia dos assentos especiais ocupados em cada voo: %d", media_pass_area_especial);
    media_pass_area_normal /= n;    
    media_pass_area_especial_00 /= n;
    printf ("\n\tEspeciais para deficientes: %d", media_pass_area_especial_00);
    media_pass_area_especial_70 /= n;
    printf ("\n\tEspeciais para idosos: %d", media_pass_area_especial_70);
    printf ("\n\nMedia dos assentos normais ocupados em cada voo: %d", media_pass_area_normal);
    media_pass_not_in /= n;
    printf ("\n\nMedia da quantidade de passageiros nao embarcados por voo: %d", media_pass_not_in);
        
    printf ("\n\n");    
    system ("pause");
    return 0;    
} 
    











