/*
  Name: exerc12.1.3 - Gera��o de matriz a partir de 2 vetores (gera��o rand�mica)
  Author: Jo�o Luiz Grave Gross
  Date: 18/04/09 17:41
  Description: Fazer um programa em C, com L linhas, L<=20, que a partir de 2 vetores A e B gere 
  uma  matriz  AB  tal  que  a  1�.  coluna  de  AB  seja  formado  pelos  valores  de  A  e  a 
  segunda  coluna  de  AB  seja  formada  pelos  elementos  de  B.  O  vetor  A  �  gerado 
  randomicamente  com  valores  entre  0  e  12. O  vetor B  �  formado pelos  fatoriais  dos 
  valores de A, respectivamente. Mostrar o vetor gerado AB. 
  
  Estruturas:
  - matriz: ab[L] [2]
  - vetores: 
    -> a[L] -> gera��o rand�mica d evalores
    -> b[L] -> fatoriasis de a
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define L 10

int main ()
{
    int ab[L] [2], a[L], b[L], i, j, fatorial, valor;
    
    //define gera��o rand�mica de valores sempre diferente
    long int ultime;
    time(&ultime);
    srand( (unsigned) ultime);
    
    //montando vetor a
    for (i = 0; i < L; i++)
        a[i] = rand() % 13; //intervalo de 0 a 12
        
    //montando vetor b
    for (i = 0; i < L; i++)
    {
        fatorial = 1;
        valor = a[i];        
        do 
        {    
             fatorial *= valor;  
             valor -= 1;
        } while (valor > 1);
        b[i] = fatorial;
    }
    
    //mostrando vetores a e b
    printf ("Vetor a: ");
    for (i = 0; i < L; i++)
        printf ("%d  ", a[i]);

    printf ("\nVetor b: ");
    for (i = 0; i < L; i++)
        printf ("%d  ", b[i]);    
        
    //montando matriz ab
    for (i = 0; i < 2; i++)
        for (j = 0; j < L; j++)
            if (i == 0)
               ab[j] [i] = a[j];
            else
               ab[j] [i] = b[j];
               //ao escrever na segunda coluna de ab, a coluna 1 tamb�m sofre altera��o
               //a partir do terceiro elemento
                             
    //mostrando matriz ab
    printf ("\n\nMatriz ab:");
    for (i = 0; i < 2; i++)
    {
        printf ("\nLinha %d: ", i);
        for (j = 0; j < L; j++)
            printf ("%d  ", ab[j] [i]);  
    }   
        
    printf ("\n\n");
    system ("pause");
    return 0;
}
