/*
  Name: exerc11.2.5 - matriz esparsa
  Author: Jo�o Luiz Grave Gross
  Date: 30/04/09 13:27
  Description: 
    Uma matriz esparsa � uma matriz que tem aproximadamente 2/3 de seus elementos
    iguais a zero. Fazer um programa que l� (linha a linha) uma matriz esparsa matesp
    [10] [10], contendo valores inteiros, e forma uma matriz condensada matcon, de
    apenas tr�s colunas, contendo os elementos n�o nulos de matesp, de forma que:
        a. A primeira coluna contenha um valor n�o nulo de matesp;
        b. A segunda coluna contenha a linha de matesp onde foi encontrado o valor
        armazenado na coluna 1 e;
        c. A terceira coluna contenha a coluna de matesp onde foi encontrado o valor
        armazenado na coluna 1.
    � Imprimir as duas matrizes, AP�S o preenchimento da matriz condensada.
    � Como determinar o n�mero de linhas de matcon?
    o dim*dim/3 linhas (+- 1/3 de dim*dim) ou simplesmente fazer o n�mero de
    linhas = dim. Neste caso, a matriz n�o seria t�o esparsa assim ;-)
*/

#include <stdio.h>
#include <stdlib.h>

#define TAMANHO 5

int main ()
{
    int matesp [TAMANHO] [TAMANHO], matcon [(TAMANHO*TAMANHO/3)+1] [3], i, j, dif_zero=0, flag=1, a=0;
    
    //Preenchendo matriz matesp
    printf ("Digite os valores da matriz esparsa\n");
    for (i = 0; i < TAMANHO; i++)
        for (j = 0; j < TAMANHO; j++)
        {
            printf ("Linha %d, Coluna %d: ", i, j);
            scanf ("%d", &matesp[i] [j]);
            //N�mero de elementos iguais a zero
            if (matesp[i] [j] != 0)
            {
               matcon[a] [0] = matesp[i] [j];
               matcon[a] [1] = i;
               matcon[a] [2] = j;           
               a++;
               dif_zero++;
            } 
        }
    
    //Imprime matriz esparsa
    printf ("\nMatriz esparsa:\n\n");
    printf ("\tC0\tC1\tC2\tC3\tC4");
    j = 0;
    for (i = 0; i < TAMANHO; i++)
    {
        printf ("\nL%d\t%d", i, matesp[i] [j]);        
        for (j = 0; j < TAMANHO; j++)
            printf ("\t%d", matesp[i] [j]);
    }       
        
    if (dif_zero > ((TAMANHO*TAMANHO*1/3)+1))
    {
       printf ("\n\nMatriz inserida nao eh esparca");      
       flag = 0;                                     
    }
    
    
    
    //Imprime matriz condensada
    while (flag)
    {
          printf ("\n\nMatriz condensada:\n\n");
          printf ("\t\tColuna 0\tColuna 1\tColuna 2\n");
          for (i = 0; i < dif_zero; i++)
          {
              printf ("Linha %d\t\t%d", i, matcon[i] [0]);
              printf ("\t\t%d\t\t%d\n", matcon[i] [1], matcon[i] [2]);
          }    
    flag = 0;
    }
    printf ("\n\n");
    system ("pause");
    return 0;
}
