/*
  Name: 
  Copyright: 
  Author: 
  Date: 12/05/09 21:15
  Description: 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NOMES 26
#define SIGLAS_ESTADOS 2
#define TAMNOMES 20

int main ()
{
    char nomes[NOMES][SIGLAS_ESTADOS][TAMNOMES];
    char sigla[SIGLAS_ESTADOS];
    int i, j, k, nnomes;
    
    do
    {
        printf ("Quantos estados ira inserir (1 a 26): ");
        scanf ("%d", &nnomes); 
        if (nnomes < 1 || nnomes > 26)
           printf ("Valor fora dos limites!\n");
    } while (nnomes < 1 || nnomes > 26);
    
    for (i = 0, j = 0; i < nnomes; i++)
    {
        printf("\nDigite o nome do estado %d com no maximo %d caracteres: ", (i+1), TAMNOMES);
        fflush(stdin);
        fgets(nomes[i][0], sizeof(nomes[i][0]), stdin);
        if (nomes[i][0][strlen(nomes[i][0]) - 1] == '\n')
            nomes[i][0][strlen(nomes[i][0]) - 1] = '\0';
        j++;
        printf("Sigla do estado %d com maximo de 2 caracteres: ", i);
        fflush(stdin);
        fgets(nomes[i][j], sizeof(nomes[i][j]), stdin);
        if (nomes[i][j][strlen(nomes[i][j]) - 1] == '\n')
            nomes[i][j][strlen(nomes[i][j]) - 1] = '\0';
        j--;
    } 
    
    printf("\nNomes lidos\n");
    for (i = 0; i < nnomes; i++) 
    {  
       printf("\n");
       for (j = 0; j < 2; j++)
           printf("nome[%d][%d] = %s\n", i, j, nomes[i][j]);  
    }
    
    printf ("\nDigite uma sigla: ");
    scanf ("%s", sigla);
    for (i = 0; i < nnomes; i++) 
        if (!(strcmp (sigla, nomes[i][1])))
        {
           printf ("Sigla: %s\nEstado: %s", sigla, nomes[i][0]);
           i = nnomes + 1;
        }
    if (i == nnomes)
       printf ("Sigla %s nao existente", sigla);
    
    printf ("\n");
    system ("pause");
    return 0;
}

