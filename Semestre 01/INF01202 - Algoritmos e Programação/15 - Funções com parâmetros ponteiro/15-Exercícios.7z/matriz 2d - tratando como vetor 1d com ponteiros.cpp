/*
Exemplo 4:
Matriz bidimensional 
tratada como unidimensional
(com nota��o de ponteiro)
*/

#include <stdio.h>
#include <stdlib.h>

long soma_matriz(int *, int );
long soma_matriz2(int *, int, int );

int main ( )
    {
      int a[10]    =  {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
      int b[2][10] = {{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
                      {11, 12, 13, 14, 15, 16, 17, 18, 19,20}};
      int c[3][10] = {{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
                      {11, 12, 13, 14, 15, 16, 17, 18, 19, 20},
                      {21, 22, 23, 24, 25, 26, 27, 28, 29, 30}};
      system("color 70");
      printf("\nSoma dos elementos da primeira matriz = %d\n", 
          soma_matriz(a, 10 ));
      printf("\nSoma dos elementos da segunda matriz = %d\n", 
          soma_matriz2(b[0], 2, 10 ));
      printf("\nSoma dos elementos da terceira matriz = %d\n", 
          soma_matriz2(c[0], 3, 10 ));
      printf("\n\n");
      system("pause");
      return 0;
    }

long soma_matriz(int matriz[ ], int elementos)
//ou long soma_matriz(int *matriz, int elementos)
 {
      long soma = 0;
      int i;
      for (i = 0; i < elementos; i++)
         soma  +=  *(matriz + i);      
      return soma;

 }
 
 long soma_matriz2(int *matriz, int el1, int el2)
 //ou long soma_matriz(int matriz[ ], int el1, int el2)
 {
      long soma = 0;
      int i;
      for (i = 0; i < el1 * el2; i++)
         soma  +=  *(matriz + i); 
      return soma;
 }
