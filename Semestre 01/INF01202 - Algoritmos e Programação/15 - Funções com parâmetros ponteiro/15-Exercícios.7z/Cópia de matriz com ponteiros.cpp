/*
Exemplo 2:
Gera a matriz1. 
Apresenta a matriz1.
Copia a matriz1 para a matriz2.
Gera em matriz2 uma c�pia elemento a elemento das duas matrizes.
Apresenta a matriz2.
*/

#include <stdio.h>
#include <stdlib.h>

#define MAXCOL 10
#define MAXLIN 3

void exibe_matriz(int [ ][MAXCOL], int , int );
void copiamatriz(int [ ] [MAXCOL], int [ ] [MAXCOL],  int, int);
void somamatrizeselementoaelemento(int [ ] [MAXCOL], int [ ] [MAXCOL], int, int);

int main ( )
     {
       int matriz1 [MAXLIN][MAXCOL] = {{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
                                       {11, 12, 13, 14, 15, 16, 17, 18, 19, 20},
                                       {21, 22, 23, 24, 25, 26, 27, 28, 29, 30}};
       int matriz2 [MAXLIN][MAXCOL];      
                     
       system("color 1F");
       printf("\nMatriz 1\n");
       exibe_matriz(matriz1, MAXLIN, MAXCOL);

       printf("\n\n");
       copiamatriz(matriz1, matriz2, MAXLIN, MAXCOL); 
        printf("\nMatriz 2\n");
       exibe_matriz(matriz2, MAXLIN, MAXCOL);
       printf("\n\n");
       system("pause");
       return 0;
     }
     
void exibe_matriz(int matriz[ ][MAXCOL], int linhas, int colunas)
  {
       int i, j;
       for (i = 0; i < linhas; i++)
       {
         printf("\n\n");
         for (j = 0; j < colunas; j++)
           printf("%6d", matriz[i][j]);
       }
  }
  
void copiamatriz(int matriz1[ ] [MAXCOL], int matriz2[ ] [MAXCOL], int linhas, int colunas)
  {
       int i, j;
       for (i = 0; i < linhas; i++)
         for (j = 0; j < colunas; j++)
           matriz2[i][j] = 2 * matriz1[i] [j];
  }
