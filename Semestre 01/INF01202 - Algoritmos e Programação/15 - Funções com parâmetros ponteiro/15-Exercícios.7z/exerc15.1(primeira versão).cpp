/*
  Name: 15.1teste2
  Author: Jo�o Luiz Grave Gross
  Date: 11/05/09 15:02
  Description: 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAMLIN 3
#define TAMCOL 2
#define TAMNOME 20

void preenchematriz (int, int, char *);
void pegasigla (char *);

int main ()
{
	char mat[TAMLIN][TAMCOL][TAMNOME], texto[TAMNOME], *ptexto;
	int i, k, cod;
	
	ptexto = texto;
    printf ("Insira os dados solicitados: \n");
    for (i = 0; i < TAMLIN; i++)
    {
        preenchematriz (i, 0, ptexto);
        for (k = 0; k < TAMNOME; k++)
            mat[i][0][k] = texto[k];    
  	    printf ("Estado %d: %s", i, mat[i][0]); 
        preenchematriz (i, 1, ptexto);
        for (k = 0; k < TAMNOME; k++)
        {
            if (texto[k] == '\n')
               mat[i][1][k] = '\0';
            else
               mat[i][1][k] = texto[k];  
        }
        printf ("Sigla do Estado %d: %s\n", i, mat[i][1]);
    }
    
    printf ("\n");
    do
    {
        pegasigla (ptexto);
        for (i = 0; i < TAMLIN; i++)
            if (!strcmp (mat[i][1], texto))
            {
               printf ("Estado da sigla: %s", mat[i][0]);
               i = TAMLIN + 1;
            }
        if (i == TAMLIN)
           printf ("Sigla %s nao encontrada\n", texto);
        do
        {
           printf ("Inserir nova sigla? (1 - sim | 0 - nao) ");
           scanf ("%d", &cod);
           if (cod < 0 || cod > 1)
              printf ("Codigo invalido!\n");
        } while (cod < 0 || cod > 1);
    } while (cod);
    		
    		
	printf ("\n\n");
	system ("pause");
	return 0;
}

void pegasigla (char *ptexto)
{
     char texto[TAMCOL+1];
     int i;
     fflush (stdin);
     printf ("\nDigite uma sigla: ");
     fgets(texto, sizeof(texto), stdin); 
     for (i = 0; i < TAMCOL+1; i++, ptexto++)
     {
         if (texto[i] == '\n')
            *ptexto = '\0';
         else
            *ptexto = texto[i];
     }
}

void preenchematriz (int i, int j, char *ptexto)
{    
    char texto[TAMNOME];
    if (j)
        printf ("Sigla do Estado %d: ", i);
    else
   	    printf ("Estado %d: ", i);
    fgets(texto, sizeof(texto), stdin);    	    
    for (i = 0; i < TAMNOME; i++, ptexto++)
        *ptexto = texto[i];
}
