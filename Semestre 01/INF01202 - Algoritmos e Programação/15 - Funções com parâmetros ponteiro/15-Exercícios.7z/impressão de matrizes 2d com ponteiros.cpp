//Exemplo 1: apresenta matrizes

#include <stdio.h>
#include <stdlib.h>

#define MAXCOL 10

void exibe_2d_matriz(int [ ][MAXCOL], int, int );

int main ( )
     {
       int a[1][MAXCOL] = {{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}};
       int b[2][MAXCOL] = {{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
                      {11, 12, 13, 14, 15, 16, 17, 18, 19, 20}};
       int c[3][MAXCOL] = {{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
                      {11, 12, 13, 14, 15, 16, 17, 18, 19, 20},
                      {21, 22, 23, 24, 25, 26, 27, 28, 29, 30}};
       system("color 70");
       
       exibe_2d_matriz(a, 1, MAXCOL);
       printf("\n\n");
       exibe_2d_matriz(b, 2, MAXCOL);
       printf("\n\n");
       exibe_2d_matriz(c, 3, MAXCOL);
       printf("\n\n");
       system("pause");
       return 0;
     }
     
void exibe_2d_matriz(int matriz[ ][MAXCOL], int linhas, int colunas)
  {
       int i, j;
       for (i = 0; i < linhas; i++)
       {
         printf("\n");
         for (j = 0; j < colunas; j++)
           printf("%4d", matriz[i][j]);
       }
  }
