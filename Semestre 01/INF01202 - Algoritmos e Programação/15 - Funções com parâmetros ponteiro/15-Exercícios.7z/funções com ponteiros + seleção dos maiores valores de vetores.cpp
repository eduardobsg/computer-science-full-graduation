/*
  Name: fun��es com ponteiros + vetores
  Author: Jo�o Luiz Grave Gross
  Date: 10/05/09 10:30
  Description: 
               
  Exerc�cio 1: 
            
  Preencher 3 vetores v1, v2, e v3 com valores reais, valendo-se da fun��o rand. 
  Usando o procedimento maior, preencher o vetor vmaior com os valores dos maiores 
  elementos de cada posi��o dos tr�s vetores considerados. Imprimir todos os vetores, 
  atrav�s da fun��o imprime_vetor.

  Fun��es utilizadas:

  Fun��o imprime_vetor: utiliza um par�metro vetor. Para a fun��o � repassado o endere�o 
  inicial desse vetor.

  Fun��o maior: utiliza tr�s par�metros por valor, que s�o os valores origin�rios de cada 
  um dos tr�s vetores lidos, e um par�metro ponteiro (endere�o), que permite armazenar o 
  maior dos tr�s valores lidos em um vetor de maiores.

*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h> // funcao time

#define MAX 10

void imprime_vetor(float [ ]); // vetor de reais
void maior (float, float, float, float *); // reais e ponteiro   						//para real

int main ()
{ 
    float v1[MAX], v2[MAX], v3[MAX], vmaior[MAX];
    int i;
    system("color f1");
    //iniciando semente da funcao randomica:
    srand(time(NULL));             
    //criando os vetores
    for (i=0; i<MAX; i++)
      {  //gera nros entre 1 e 10 e divide:
          v1[i]= (rand( )%10 + 1) / 0.23;
          v2[i]= (rand( )%10 + 1) / 0.23;
          v3[i]= (rand( )%10 + 1) / 0.23;
          maior(v1[i],v2[i],v3[i],&vmaior[i]);                   
      }
    //impressao dos vetores
    printf("\nVetor 1:\n");     
    imprime_vetor(v1);
    printf("\nVetor 2:\n");     
    imprime_vetor(v2);
    printf("\nVetor 3:\n");     
    imprime_vetor(v3); 
    printf("\nVetor com os maiores:\n"); 
    imprime_vetor(vmaior);      
    printf("\n");
    system("pause");
    return 0;
}
      
// imprime um vetor float de MAX elementos:
void imprime_vetor(float vet[])
 {
   int i;
   for (i=0; i<MAX; i++)
           printf("%6.2f ",vet[i]);
   printf("\n");
 }

// recebe tr�s valores reais e devolve o maior dos tr�s
void maior (float x1, float x2, float x3, float *o_maior)
 {
    *o_maior = x1;
    if (x2 > *o_maior) 
        *o_maior = x2;
    if (x3 > *o_maior) 
       *o_maior = x3;
 }
      
      
      
      
      
      
      
      
      
      
      
      
