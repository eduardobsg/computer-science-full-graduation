/*
  Name: 15.1teste3
  Author: Jo�o Luiz Grave Gross
  Date: 11/05/09 15:02
  Description: 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAMLIN 26
#define TAMCOL 2
#define TAMNOME 20

void preenchematriz (char [TAMLIN][TAMCOL][TAMNOME]);
void pegasigla (char [TAMLIN][TAMCOL][TAMNOME]); //ou char [][TAMCOL][TAMNOME]

int main ()
{
	char mat[TAMLIN][TAMCOL][TAMNOME];
	int i;
	preenchematriz (mat); //ou mat
	
    printf ("\n");
    pegasigla (mat);
	system ("pause");
	return 0;
}

void preenchematriz (char vet[TAMLIN][TAMCOL][TAMNOME])
{
     int i, j;
     for (i = 0; i < TAMLIN; i++)
     {
         printf ("(%d de %d)\nEstado: ", i + 1, TAMLIN);
         fgets(vet[i][0], sizeof(vet[i][0]), stdin);
         for (j = 0; j < TAMNOME; j++)
            if (vet[i][0][j] == '\n')
               vet[i][0][j] = '\0';
         printf ("Sigla: ");
         fgets(vet[i][1], sizeof(vet[i][1]), stdin);
         for (j = 0; j < TAMNOME; j++)
            if (vet[i][1][j] == '\n')
               vet[i][1][j] = '\0';
         printf ("\n");
     }
     
     printf ("Estado\t\t    Sigla\n");
	 for (i = 0; i < TAMLIN; i++)
	 {
         printf ("%s", vet[i][0]);
         for (j = strlen(vet[i][0]); j < TAMNOME; j++)
             printf (" ");
         printf ("%s\n", vet[i][1]);
     }
     
}

void pegasigla (char vet[][TAMCOL][TAMNOME])
{
     char texto[TAMCOL+1];
     int i, cod;
     
     do
     { 
        printf ("\nDigite uma sigla: ");
        fflush (stdin);
        fgets(texto, sizeof(texto), stdin); 
        for (i = 0; i < TAMCOL+1; i++)
            if (texto[i] == '\n')
               texto[i] = '\0';
        for (i = 0; i < TAMLIN; i++)
            if (!strcmp (vet[i][1], texto))
            {
               printf ("Estado da sigla: %s\n", vet[i][0]);
               i = TAMLIN + 1;
            }
        if (i == TAMLIN)
           printf ("Sigla %s nao encontrada\n", texto);
        do
        {
           printf ("Inserir nova sigla? (1 - sim | 0 - nao) ");
           scanf ("%d", &cod);
           if (cod < 0 || cod > 1)
              printf ("Codigo invalido!\n");
        } while (cod < 0 || cod > 1);
    } while (cod);
  	printf ("\n\n");
}

