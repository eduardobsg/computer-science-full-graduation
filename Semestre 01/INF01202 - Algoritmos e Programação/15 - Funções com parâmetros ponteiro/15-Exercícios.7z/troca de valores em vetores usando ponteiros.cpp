/*
  Name: troca de valores em vetores usando ponteiros
  Author: Jo�o Luiz Grave Gross
  Date: 10/05/09 10:55
  Description: 
               
  Preencher 2 vetores (20) de inteiros por leitura. Usando a fun��o void troca, 
  trocar os conte�dos desses 2 vetores

  Fun��o utilizada:

  Fun��o troca: recebe dois ponteiros (endere�os) inteiros, apontando para uma 
  posi��o em cada um dos vetores lidos.
 
  Troca os valores dessas posi��es.

*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 5

void troca (float *, float *);
void imprimi_v (float *, int);

int main ()
{
    float v1[MAX], v2[MAX], x;
    int i, clock_t;
    srand (time(NULL));
    
    for (i = 0; i < MAX; i++)
    {
        v1[i] = (rand () % 50 + 1) / 0.34; //intervalo de 1 a 20
        v2[i] = (rand () % 50 + 1) / 0.34;//intervalo de 1 a 20
//        printf ("(%d) Insira dois valores: ", i);
//        scanf ("%d%d", &v1[i], &v2[i]);
    }   
    
    printf ("\nVetores lidos:");
    printf ("\nVetor 1:\n");
    imprimi_v(v1, MAX);    
    printf ("\nVetor 2:\n");
    imprimi_v(v2, MAX);   
    
    for (i = 0; i < MAX; i++)   
        troca (&v1[i], &v2[i]);
        
    printf ("\n\nVetores trocados:");
    printf ("\nVetor 1:\n");
    imprimi_v(v1, MAX);    
    printf ("\nVetor 2:\n");
    imprimi_v(v2, MAX);     
    
    printf ("\n\n");
    system ("pause");
    return 0;  
}

void imprimi_v (float *v, int max)
{
     int i;
     for (i = 0; i < max; i++)
         printf ("%.2f  ", v[i]); 
}

void troca (float *p1, float *p2)
{
     float temp;
     temp = *p1;
     *p1 = *p2;
     *p2 = temp;
}













