/*
Exemplo 1 de  uso de argc e argv: apenas o nome do programa eh     parametro.
*/

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>  

int main(int argc, char *argv [] )  
  {
    system("color f1");
    printf("\nNumero de parametros = %d  \n", argc);
    printf("\nTamanho do nome do prog. = %d\n ", strlen(argv[0]));
    printf("\nNome do prog. = %s\n", argv[0]);
    printf ("\n");
    system("pause"); 
    return 0;
  }
