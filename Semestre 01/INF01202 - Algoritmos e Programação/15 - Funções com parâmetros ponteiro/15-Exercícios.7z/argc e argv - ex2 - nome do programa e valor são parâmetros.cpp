/*
Exemplo 2 de  uso de argc e argv: alem do nome do programa, mais dois valores sao passados como parametro.

Menu Execute op��o Parameters -> para inserir par�metros
*/

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>  

int main(int argc, char *argv[] )  
  {
    system("color f1");
    printf("\nNumero de parametros = %d  \n", argc);
    printf("\nTamanho do nome do prog. = %d\n ", strlen(argv[0]));
    printf("\nNome do prog. = %s\n", argv[0]);
    printf("\nPrimeiro valor apos nome do programa = %s\n", argv[1]);
    if (argc > 1)
        printf("\nSegundo valor apos nome do programa = %s\n", argv[2]);
    printf ("\n\n");
    system("pause"); 
    return 0;
  } 
