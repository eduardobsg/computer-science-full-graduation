/*
Programa 2: lista um arquivo com valores double, 
e al�m dos valores, apresenta o total de valores lidos.

*/

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#define MAXNOME 31
FILE *arquiv;  
void listarq(FILE *, int*);
FILE * AbreArquivo(int);
int main( )  
  {
     int lidos;     
     if(!(arquiv = AbreArquivo(MAXNOME)))
         { 
          printf("Erro na abertura");
          system("pause");
         }
     else
       {  
         listarq(arquiv, &lidos);
         printf("\nLidos: %d\n", lidos);
         fclose(arquiv);
         system("pause"); 
         return 0;
      }  
   }
FILE * AbreArquivo(int max)
 {
	char nomearq[max];
	printf("Nome do arquivo (com no maximo %d caracteres): ", max - 1);
	fflush(stdin);
	fgets(nomearq, sizeof(nomearq), stdin);
	if (nomearq[strlen(nomearq) - 1] == '\n')
       nomearq[strlen(nomearq) - 1] = '\0';
	return fopen(nomearq,"rb");
 }
void listarq(FILE *arquivo, int *contlid)
 {
    double valor;
    *contlid = 0;
    while (fread(&valor, sizeof(double), 1, arquivo)!= 0)
      {
         *contlid = *contlid + 1;
         printf("%6.2f   ", valor);  
      }     
 }
