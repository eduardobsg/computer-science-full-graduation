/*
  Exemplo 3:
  Lista sequencialmente um arquivo com dados de uma estrutura
  com informacoes de atletas.
*/ 

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

#define MAXNOME 31

struct atleta
    { 
       char nome[MAXNOME];
       int idade;
       float altura;
    };

FILE *arq; 
void ListagemAtletas(FILE *, struct atleta);
FILE * AbreArquivo(int max);

int main( )  
  {  
     char nome[15];
     struct atleta buffermain;    
     printf (">>> LISTA SEQUENCIALMENTE OS DADOS DE UM ARQUIVO COM DADOS DE UMA ESTRUTURA ATLETAS <<<\n\n");
     if(!(arq = AbreArquivo(MAXNOME)))
         { 
          printf("Erro na abertura\n");
          system("pause");
         }
     else
         {
          ListagemAtletas(arq, buffermain);
          fclose(arq);   
          printf ("\n\n");   
          system("pause"); 
          return 0;
         }  
   }

FILE * AbreArquivo(int max)
  {
     char nomearq[max];
     printf("Nome do arquivo para abrir (com no maximo %d caracteres): ", max - 1);
     fgets(nomearq, sizeof(nomearq), stdin);
     if (nomearq[strlen(nomearq) - 1] == '\n')
         nomearq[strlen(nomearq) - 1] = '\0';
     fflush(stdin);
     return fopen(nomearq,"rb");
  } 

void ListagemAtletas(FILE *arq2, struct atleta buffer)
  {
    printf("-----Comeco da listagem-----\n");
    while(!(feof(arq2)))
       if (fread(&buffer,sizeof(struct atleta),1,arq2) == 1)
           {//le e confirma se o que foi lido eh estrutura, entao imprime
              printf("Nome: %s",buffer.nome);
              printf("\nIdade: %d",buffer.idade);
              printf("\nAltura: %.2f\n\n",buffer.altura);		 
           }    
     printf("-----Fim da listagem-----\n");
  }
  
