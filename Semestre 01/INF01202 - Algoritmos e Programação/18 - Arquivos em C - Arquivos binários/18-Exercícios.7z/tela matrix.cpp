
#include "stdio.h"
#include "stdlib.h"
#include "conio.h"
#include <time.h>
#include <math.h>

int main()
{
    system ("color 02");
	double a;
	char b[16];    
    long int ultime; 
     
    time (&ultime);
    srand ((unsigned) ultime); 
    
    do
    {
      a = rand() % 68;    
      itoa(a,b,2); //Converte para base 2
      printf("%s ", b);
      for (a = rand() % 7; a > 0; a--)
          printf (" ");
      for (a = pow (10, 6); a > 0; a --);
    } while (true);
	return 0;
}

