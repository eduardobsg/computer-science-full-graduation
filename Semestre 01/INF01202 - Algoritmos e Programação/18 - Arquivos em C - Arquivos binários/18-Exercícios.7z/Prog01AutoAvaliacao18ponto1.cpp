/*
Programa 1: gera um arquivo com valores double, 
apresenta o total de valores gravados.
*/
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#define MAXNOME 31
FILE *arquiv;  
int gerarq(FILE *);
FILE * AbreArquivo(int);
int main( )  
  {
     int gravs;     
     if(!(arquiv = AbreArquivo(MAXNOME)))
         { 
          printf("Erro na abertura");
          system("pause");
         }
     else
       {  
         gravs = gerarq(arquiv);
         printf("\nGravados: %d\n", gravs);
         fclose(arquiv);
         system("pause"); 
         return 0;
      }  
   }
FILE * AbreArquivo(int max)
{
	char nomearq[max];
	printf("Nome do arquivo (com no maximo %d caracteres): ", max - 1);
	fflush(stdin);
	fgets(nomearq, sizeof(nomearq), stdin);
	if (nomearq[strlen(nomearq) - 1] == '\n')
       nomearq[strlen(nomearq) - 1] = '\0';
	return fopen(nomearq,"wb");
}
int gerarq(FILE *)
{
    double valor;
    int segue = 1, contgrav = 0;
    while (segue)
      {
         printf("Valor:");
         scanf("%lf", &valor);
         fwrite(&valor, sizeof(double), 1, arquiv);
         contgrav++;
         printf("\n1 - Seguir, 0 - Parar: ");
         scanf("%d", &segue);
      } 
    return contgrav;      
 }
