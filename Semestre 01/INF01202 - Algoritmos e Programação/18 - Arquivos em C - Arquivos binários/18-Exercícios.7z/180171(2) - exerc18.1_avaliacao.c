/*
  Name: 180171(2) - exerc18.1_avaliacao.c
  Author: 
  Date: 11/06/09 17:03
  Description: Programa 2
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXNOMES 31

struct data_nascimento
{
       int dia;
       int mes;
       int ano;
};
        
struct individuo
{
               char nome[MAXNOMES];
               int sexo; //1-masculino e 2-feminino
               char cor_olhos[10];
               float altura;
               float peso;
               struct data_nascimento data;
}; 

FILE *pcliente;
FILE *pcliente_f;
FILE *pcliente_m;
FILE *AbreArquivo (int);
void ImprimeCliente (struct individuo *);

int main ()
{
    struct individuo buffer;
    int codigo, i, contm, contf;
    system ("color 02");
    if (!(pcliente = AbreArquivo(MAXNOMES))) //se for true deu erro
       printf ("\nArquivo nao existente");
    else
    {
       if (!(pcliente_f = fopen ("cliente_f", "wb")))
          printf ("\nErro ao ler o arquivo!");
       else
       {
          if (!(pcliente_m = fopen ("cliente_m", "wb")))
             printf ("\nErro ao ler o arquivo!");           
          else
          {
              i = 0; contf = 0; contm = 0;                  
              while (fread(&buffer, sizeof(buffer), 1, pcliente) != 0)
              {
                       if (buffer.sexo == 1)
                       {
                          fwrite (&buffer, sizeof (buffer), 1, pcliente_m);
                          contm++;
                       }
                       else
                       {
                          fwrite (&buffer, sizeof (buffer), 1, pcliente_f);
                          contf++;
                       }
                       i++;         
              }
              fclose(pcliente); 
              fclose(pcliente_f);
              fclose(pcliente_m);  

              printf ("\nClientes do sexo feminino:");
              pcliente_f = fopen ("cliente_f", "rb");
              while (fread(&buffer, sizeof(buffer), 1, pcliente_f) != 0)
                    ImprimeCliente (&buffer);
              fclose(pcliente_f);
              printf ("\n\n\nClientes do sexo masculino:");
              pcliente_m = fopen ("cliente_m", "rb");
              while (fread(&buffer, sizeof(buffer), 1, pcliente_m) != 0)
                    ImprimeCliente (&buffer);            
              fclose(pcliente_m);       
          }
       }
       printf ("\n\n\nNumero de clientes lidos: %d", i);
       printf ("\nClientes do sexo feminino: %d", contf);
       printf ("\nClientes do sexo masculino: %d", contm);   
    } 
    printf ("\n\n");
    system ("pause");
    return 0;
}

FILE *AbreArquivo(int maxnomes)
{
     char nomearq[maxnomes];
     printf ("Abrir o arquivo de nome (maximo de %d caracteres): ", maxnomes - 1);
     fgets (nomearq, sizeof(nomearq), stdin);
     if (nomearq[strlen(nomearq) - 1] == '\n')
        nomearq[strlen(nomearq) - 1] = '\0';
     fflush (stdin);
     return fopen(nomearq,"rb");
}

void ImprimeCliente (struct individuo *buffer)
{
     printf ("\n\nNome do cliente: %s", buffer->nome);
     printf ("\nSexo: %d", buffer->sexo);
     printf ("\nCor de olhos: %s", buffer->cor_olhos);
     printf ("\nAltura em metros: %.2f", buffer->altura);
     printf ("\nPeso em quilogramas: %.2f", buffer->peso);
     printf ("\nData de nascimento: %d %d %d", buffer->data.dia, buffer->data.mes, buffer->data.ano);
}




