/*
  Name: 180171(1) - exerc18.1_avaliacao.c
  Author: 
  Date: 11/06/09 11:43
  Description: Exerc�cio de Avalia��o 18.18
  
  Gravar os arquivos resultados desta tarefa e zip�-los em um arquivo de nome At18seunumero. 
  O arquivo fonte em C deve ter o nome <seunumero>.c 
  
  Tendo por base o arquivo clientes, onde estar�o armazenados os dados de indiv�duos, organizados 
em estruturas com os campos nome, sexo, cor dos olhos, altura, peso e data de nascimento, gerar dois 
outros arquivos: um chamado homens, com os dados dos indiv�duos cujo campo sexo apresente o valor 1 
(sexo masculino) e o outro chamado mulheres, com os dados dos indiv�duos cujo campo sexo seja igual 
a 2 (sexo feminino). 

  As estruturas dos novos arquivos dever�o possuir apenas os seguintes campos: nome, cor dos olhos, 
altura e data de nascimento. 

  Para resolver o exerc�cio desenvolver dois programas: um que crie o arquivo clientes e outro que, 
a partir do arquivo clientes, crie os arquivos homens e mulheres.
  
  Todos os programas dever�o realizar suas tarefas basicamente atrav�s de fun��es.
Apresentar ao final do processamento, no programa que cria o arquivo clientes, o n�mero de indiv�duos 
processados e no programa que cria os arquivos homens e mulheres: quantos indiv�duos foram lidos e 
quantos foram armazeandos em cada arquivo. 

  Programa 1: gera arquivo cliente         
  Nome do arquivo: clientes
  Dados armazenados: 
        struct data_nascimento
        {
               int dia;
               int mes;
               int ano;
        };
        
        struct individuo
        {
               char nome[MAXNOME];
               int sexo; //1-masculino e 2-feminino
               char cor_olhos[10];
               float altura;
               float peso;
               struct data_nascimento data;
        };         
        
  Passos:
         declarar structs
         declarar ponteiro para o arquivo
         declarar prot�tipos da fun��es
         declarar vari�vel do tipo struct individuo
         
               
        
  Programa 2: gera arquivos clientes_f, clientes_m
  Dados armazenados: nome, cor dos olhos, altura, peso e data de nascimento
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXNOMES 31

struct data_nascimento
{
       int dia;
       int mes;
       int ano;
};
        
struct individuo
{
               char nome[MAXNOMES];
               int sexo; //1-masculino e 2-feminino
               char cor_olhos[10];
               float altura;
               float peso;
               struct data_nascimento data;
}; 

FILE *pcliente;
void LeClientes (struct individuo *, int);
FILE *AbreArquivo (int);

int main ()
{
    struct individuo buffer;
    int codigo, i;
    system ("color 02");

    if (!(pcliente = AbreArquivo(MAXNOMES))) //se for true deu erro
       printf ("\nErro ao ler o arquivo!");
    else
    {
       printf ("\nInsira os dados dos clientes: ");
       i = 0;
       do
       {
           i++;
           printf ("\n\nCliente %d:\n\n", i);   
           LeClientes (&buffer, MAXNOMES);    
           fwrite (&buffer, sizeof (buffer), 1, pcliente);
           printf ("\nO que deseja fazer?\n1 - Novo cliente\n0 - Finalizar\nCodigo: ");   
           scanf ("%d", &codigo);
       } while (codigo);             
    } 
    fclose (pcliente);
    printf ("\nNumero de clientes cadastrados: %d", i);
       
    printf ("\n\n");
    system ("pause");
    return 0;
}

FILE *AbreArquivo(int maxnomes)
{
     char nomearq[maxnomes];
     printf ("Nome do arquivo de destino (maximo de %d caracteres): ", maxnomes - 1);
     fgets (nomearq, sizeof(nomearq), stdin);
     if (nomearq[strlen(nomearq) - 1] == '\n')
        nomearq[strlen(nomearq) - 1] = '\0';
     fflush (stdin);
     return fopen(nomearq,"wb");
}

void LeClientes (struct individuo *buffer, int maxnomes)
{
     int cont = 1, olhos_ok, erro, i;
     char olhos [4][10] = {{"azul"}, {"castanho"}, {"ambar"}, {"verde"}};
     printf ("Nome do cliente (maximo de %d caracteres): ", maxnomes - 1);
     fflush (stdin);
     fgets (buffer->nome, sizeof (buffer->nome), stdin);
     if (buffer->nome[strlen(buffer->nome) - 1] == '\n')
        buffer->nome[strlen(buffer->nome) - 1] = '\0';
     do 
     {
        printf ("\nSexo (1 - masculino | 2 - feminino): ");
        scanf ("%d", &buffer->sexo);
        if (buffer->sexo > 2 || buffer->sexo < 1)
           printf ("\tInrisa 1 para masculino OU 2 para feminino\n");
     } while (buffer->sexo > 2 || buffer->sexo < 1);
     do
     {
        printf ("\nCor de olhos (azul, castanho, ambar ou verde): ");
        fflush (stdin);
        fgets (buffer->cor_olhos, sizeof (buffer->cor_olhos), stdin);
        if (buffer->cor_olhos[strlen(buffer->cor_olhos) - 1] == '\n')
           buffer->cor_olhos[strlen(buffer->cor_olhos) - 1] = '\0'; 
        for (i = 0, olhos_ok = 0; i < 4; i++)
           if (!(strcmp(buffer->cor_olhos, olhos[i])))
              olhos_ok = 1;;
        if (!olhos_ok)
           printf ("\tCor de olhos invalida\n");     
     } while (!olhos_ok);
     do
     {
        printf ("\nAltura em metros: ");
        scanf ("%f", &buffer->altura);
        if (buffer->altura > 2.5 || buffer->altura < 1.1)
           printf ("\tAltura invalida\n");   
     } while (buffer->altura > 2.5 || buffer->altura < 1.1);
     do
     {
        printf ("\nPeso em quilogramas: ");
        scanf ("%f", &buffer->peso);
        if (buffer->peso > 250 || buffer->peso < 40)
           printf ("\tPeso invalida\n");   
     } while (buffer->peso > 250 || buffer->peso < 40);
     do
     {
        erro = 0;
        printf ("\nData de nascimento (dd mm aaaa): ");
        scanf ("%d%d%d", &buffer->data.dia, &buffer->data.mes, &buffer->data.ano);
        if (buffer->data.dia > 31 || buffer->data.dia < 1) //n�o h� consist�nca entre dia e m�s
        {
                                                       //o usu�rio pode colocar 31/02 que dar� certo
           printf ("\tDia invalido\n");
           erro++;
        }
        if (buffer->data.mes > 12 || buffer->data.mes < 1)                                                    
        {
           printf ("\tMes invalido\n");       
           erro++;
        }
        if (buffer->data.ano > 1990 || buffer->data.ano < 1900)                                                    
        {
           printf ("\tAno invalido\n");       
           erro++;;
        }
     } while (erro);
}
















