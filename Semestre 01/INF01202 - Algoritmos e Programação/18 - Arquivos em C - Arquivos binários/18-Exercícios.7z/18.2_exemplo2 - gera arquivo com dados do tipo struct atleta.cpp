/*
  Exemplos 2:
  Cria de forma sequencial um arquivo com dados de uma estrutura com informacoes de atletas.
*/

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

#define MAXNOME 31  

struct atleta
{ 
       char nome[MAXNOME ];
       int idade;
       float altura;
};
    
FILE *arq;
void RotinaInsere(FILE *, struct atleta, int);
FILE *AbreArquivo(int);

int main( )  
  {
     char nome[15];
     struct atleta buffermain;
     int op; 
     system("color f1");  
     printf (">>> GERADOR DE ARQUIVO PARA ATLETAS <<<\n\n");
     if(!(arq = AbreArquivo(MAXNOME))) //!(arq = true) = false -> resposta esperada
                                       //se AbreArquivo devolver Null o if ter� resposta true
         { 
          printf("Erro na abertura");
          system("pause");
         }
     else
       {  
         printf ("\nInsira os dados para o arquivo:");                 
         do
           {
             RotinaInsere(arq, buffermain, MAXNOME);
             printf("\nO que dejesa fazer? \n1 - InserirNovo\n2 - Encerrar\nCodigo: ");
             scanf("%d", &op);
           } 
         while(op != 2);
         fclose(arq);      
         printf ("\n\n");
         system("pause"); 
         return 0;
      }  
   }

FILE *AbreArquivo(int max)
{
	char nomearq[max];
	printf("Nome do arquivo (com no maximo %d caracteres): ", max - 1);
	fgets(nomearq, sizeof(nomearq), stdin);
    if (nomearq[strlen(nomearq) - 1] == '\n')
 	   nomearq[strlen(nomearq) - 1] = '\0';
	fflush(stdin);
	return fopen(nomearq,"wb");
}

void RotinaInsere(FILE *arq2, atleta buffer, int max)
{	
	fflush(stdin);
          printf("\n\nNome (com no maximo %d caracteres): ", max - 1);
	fgets (buffer.nome, sizeof(buffer.nome), stdin);
 	fflush(stdin);
	printf("Idade: ");
	scanf("%d",&buffer.idade);
	printf("Altura: ");
	scanf("%f",&buffer.altura);
	fwrite(&buffer,sizeof(struct atleta),1,arq2);
}

