/*  
    Exemplo 6.1:
    Lista um arquivo de inteiros.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXNOME 21

FILE *fpin;

int main (  )
{
 char filename[MAXNOME];
 int x;
 system("color f1");
 printf (">>> ABRE E LISTA ARQUIVO DE INTEIROS <<<\n\n");
 printf("Nome do arquivo (com no maximo %d caracteres): ", MAXNOME - 1);
 fgets(filename, sizeof(filename), stdin);
 if (filename[strlen(filename) - 1] == '\n')
    filename[strlen(filename) - 1] = '\0';
 fflush(stdin);
 if ((fpin=fopen(filename,"rb"))==NULL)
    {
     printf("Nao foi possivel abrir o arquivo %s. Trabalho cancelado.\n",filename);
     system("pause");
    }
 else
    {
      while(fread(&x, sizeof(int),1,fpin) !=0)
         printf("\n%4d  ",x);
      printf("\n\n");   
      system("pause");
      return 0;
    } 
}
