/* 
   Exemplo 6:
   Cria um arquivo de inteiros de forma sequencial.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

FILE *fpin;

int main (  )
{
 int x;
 system("color f1");
 printf (">>> GERADOR DE ARQUIVO COM INTEIROS DE FORMA SEQUENCIAL <<<\n");
 if ((fpin = fopen("numint","wb")) == NULL) //c:\\numint
     printf("O arquivo nao pode ser aberto!");
 else
  {
    printf("\nCriacao do arquivo sequencial numint");
    printf("\nEntre com valores inteiros (0 para terminar)"); 
    do
    {
      printf("\nNum. inteiro: ");
      scanf("%d",&x);
      fwrite(&x, sizeof(int), 1, fpin);
    } while (x);
    fclose(fpin);
  }
 printf ("\n\n");
 system("pause");
 return 0;
}
