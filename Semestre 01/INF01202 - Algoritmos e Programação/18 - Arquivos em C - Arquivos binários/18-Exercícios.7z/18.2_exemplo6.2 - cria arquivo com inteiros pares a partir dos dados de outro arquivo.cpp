/*
  Exemplo 6.2:
  Cria um arquivo de inteiros apenas com  valores pares, a 
partir de outro j� existente.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

FILE *fpin;
FILE *fppar;

int main (  )
{
 int x , contgrav = 0,  contlidos = 0;
 system("color f1");
 printf (">>> GERA ARQUIVO COM INTEIROS PARES A PARTIR DE OUTRO ARQUIVO<<<\n\n");
 printf("\nArquivo lido (entrada): numint");
 printf("\nArquivo gravado (sa�da): numintpar\n");
 if ((fpin=fopen("numint","rb"))==NULL)
     printf("\nO arquivo de entrada nao pode ser aberto!\n");
 else
   {
    if ((fppar = fopen("numintpar", "wb")) == NULL)
        printf("\nO arquivo de saida nao pode ser aberto!\n");
    else
       while(fread(&x, sizeof(int),1,fpin) !=0) //coloca o conte�do de fpin (numint) em x
           {
             contlidos++;
             if (!(x % 2)) //se (x % 2) == 0, � par
                {
                 fwrite(&x, sizeof(int), 1, fppar); //*fppar = x, onde fppar � numintpar  
                 contgrav++;
                 }
            }
          printf("\nLidos: %d", contlidos);
          printf("\nGravados: %d\n", contgrav);
          fclose(fpin);
          fclose(fppar);
          printf ("\n");
          system("pause");
          return 0;
  }      
 system("pause");
 return 0;
}
