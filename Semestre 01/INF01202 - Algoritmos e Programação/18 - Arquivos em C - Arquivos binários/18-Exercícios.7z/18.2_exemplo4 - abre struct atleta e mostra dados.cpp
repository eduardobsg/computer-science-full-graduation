/*
  Exemplo 4:
  Apresenta a altura de um atleta cujo nome eh fornecido pelo usuario.
*/

#include <stdio.h> 
#include <stdlib.h>
#include <conio.h>
#include <string.h>

#define MAXNOME 31

FILE *arq;  
struct atleta
    { 
       char nome[MAXNOME];
       int idade;
       float altura;
    };
    
int main( )  
  {
     struct atleta buffer;
     char procurado[MAXNOME], nomearq[MAXNOME];
     int encontrado, contador = 0;  
     system("color f1");  
     printf (">>> ABRE ARQUIVO COM DADOS DE ESTRUTURA ATLETA E MOSTRA APENAS OS DADOS DO NOME ESCOLHIDO <<<\n\n");
     printf("Nome do arquivo para abrir (com no maximo %d caracteres): ", MAXNOME - 1);
     fgets(nomearq, sizeof(nomearq), stdin);
     if (nomearq[strlen(nomearq) - 1] == '\n')
         nomearq[strlen(nomearq) - 1] = '\0';
     fflush(stdin);
      if(!(arq = fopen(nomearq,"rb"))) //nomearq contem o nome do arquivo que deseja-se abrir
       { 
         printf("Erro abertura");
         system("pause");
       }
     else
       {  
         printf("Nome do procurado (maximo %d caracteres): ", MAXNOME - 1);
         fgets(procurado, sizeof(procurado), stdin);
         fflush(stdin);
         while(!feof(arq))
           {
            if (fread(&buffer,sizeof(struct atleta),1,arq) == 1) //copia o conte�do de arq (nomearq) para buffer
               if (!(strcmp(buffer.nome,procurado))) //se strcmp for zero os nomes sao iguais, por isso usa-se ! (not)
                 {
                  printf("\nIdade: %d", buffer.idade);                                   
                  printf("\nAltura do procurado: %.2f",buffer.altura);
                  encontrado = 1; /*verdade, alguem foi encontrado*/
                  contador++;
                 }              
           }
        if (!encontrado)
           printf("\nNenhum atleta encontrado");
        else
           printf("\nOcorrencias encontradas: %d",contador);
        fclose(arq);   
        printf("\n\n");  
        system("pause"); 
        return 0;
      }  
   } 

