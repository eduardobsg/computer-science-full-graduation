/*
  Exemplo 7:
  Le e escreve nomes de grupos de pessoas
*/

#include <stdio.h> 
#include <stdlib.h>

#define MAXNOME 31
#define MAXPART 4

struct gr
  {
     int num_part_gr;
     char nome_part[MAXPART][MAXNOME];  
   };
   
FILE *grupos;  
void LeGrupo(struct gr *, int , int);
void ApresentaGrupo (struct gr *);

int main( )  
  {
    int segue = 1, contgrv = 0, contlidos = 0;
    struct gr grupo;
    system("color f1");
    printf (">>> LE E ESCREVE NOMES DE GRUPOS DE PESSOAS <<<\n\n");    
    if (!(grupos = fopen ("grupos", "wb")))
       printf("Nao abriu arquivo para escrita!");
     else
       { 
        while (segue) 
         {
           LeGrupo(&grupo, MAXNOME, MAXPART);
           fwrite (&grupo, sizeof(gr), 1, grupos); //grupos = grupo
           contgrv++;
           printf("\n1- Segue , 0 - Para\n");  
           scanf("%d", &segue);
         } 
         printf("\nGravados = %d\n", contgrv);      
         fclose (grupos);
         if (!(grupos = fopen ("grupos", "rb")))
           printf("Nao abriu arquivo para leitura!"); 
         else
           {               
            while (!feof(grupos))
               if (fread(&grupo, sizeof(grupo), 1, grupos) == 1)
                 {
                  ApresentaGrupo(&grupo);
                  contlidos++;
                 }
            fclose(grupos);
            printf("\nLidos = %d\n", contlidos);                               
            system("pause"); 
            return 0;
           }
      } 
  }
  
void LeGrupo(struct gr *grup, int maxnom , int maxpart)
 {
   int i;
   fflush(stdin);
   do
    { 
      printf("\nNumero de participantes do grupo (maximo = %d): ", maxpart);  
      scanf("%d", &(*grup).num_part_gr);  
      if ((*grup).num_part_gr < 1 || (*grup).num_part_gr > maxpart)
         printf ("\nNumero participantes deve ser > 0 e no maximo %d", maxpart);
    } 
   while ((*grup).num_part_gr < 1 || (*grup).num_part_gr > maxpart);
   for  (i = 0; i < (*grup).num_part_gr; i++)
      {
           printf("\nNome do participante %d: ", i + 1);
           fflush(stdin);
           fgets((*grup).nome_part[i], sizeof((*grup).nome_part), stdin) ;
           fflush(stdin);
       }
 }

void ApresentaGrupo (struct gr *grup)
{  
   int i;  
   printf ("\n\nNumero de participantes da grupo: %d ", (*grup).num_part_gr); 
   for (i = 0; i < (*grup).num_part_gr; i++)
         printf("\nNome do participante %d: %s", i + 1, (*grup).nome_part[i]);  
 }

