/*
Programa 3: l� um arquivo de valores double 
e gera um novo arquivo, a partir desse, 
apenas com os dois primeiros e o �ltimo 
valor do arquivo original. 
Apresenta o total de valores lidos no arquivo original.
*/
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#define MAXNOME 31
FILE *arqent;
FILE *arqsai;  
int legrava(FILE *ent, FILE *sai);
FILE * AbreArquivo(int, char *, char *);
int main( )  
  {
     int lidos_orig; 
     system("color 71");  
     if(!(arqent = AbreArquivo(MAXNOME, "entrada", "rb")))
	  {
           printf("Erro na abertura do arquivo de entrada");
           system("pause");
         }
     else
         {
        
           if(!(arqsai  = AbreArquivo(MAXNOME, "saida", "wb")))
             { 
               printf("Erro na abertura do arquivo de saida");
               system("pause");
             }
           else
             {           
               lidos_orig = legrava(arqent, arqsai);
               printf("\nLidos: %d\n", lidos_orig);
               fclose(arqent);
               fclose(arqsai);
               system("pause"); 
               return 0;
             }  
         }
  }           
int legrava(FILE *ent, FILE *sai)
{
    double valor, valor_aux;
    int segue = 1, contlid = 0;
    while (fread(&valor, sizeof(double), 1, ent))
    //o mesmo que:
    //while (fread(&valor, sizeof(double), 1, ent)!= 0)
      {
         contlid++;
         if (contlid < 3)
            fwrite(&valor, sizeof(double), 1, sai);   
      }
    fwrite(&valor, sizeof(double), 1, sai);   
    return contlid;      
 }
 FILE * AbreArquivo(int max, char *qual, char *modo)
 {
       char nomearq[max];
       printf("Nome do arquivo de %s (com no maximo %d caracteres): ", qual,  max - 1);
       fflush(stdin);
       fgets(nomearq, sizeof(nomearq), stdin);
       if (nomearq[strlen(nomearq) - 1] == '\n')
          nomearq[strlen(nomearq) - 1] = '\0';
       return fopen(nomearq, modo);
 }
