/*
  Exemplo 5:
  Acrescenta dados ao final de um arquivo previamente existente
*/

#include <stdio.h> 
#include <stdlib.h>
#include <conio.h>
#include <string.h>

#define MAXNOME 31

FILE *arq;  
struct atleta
    { 
       char nome[MAXNOME];
       int idade;
       float altura;
    };
    
int main( )  
  {
     struct atleta buffer;
     char nome[15];
     int op;    
     system("color f1"); 
     printf (">>> ACRESCENTA DADOS A UMA ARQUIVO EXISTENTE <<<\n\n");
     printf("Nome do arquivo que deseja abrir (com no maximo %d caracteres): ",MAXNOME - 1);
     fgets(nome, sizeof(nome), stdin);
     if (nome[strlen(nome) - 1] == '\n')
         nome[strlen(nome) - 1] = '\0';
     fflush(stdin);
     if(!(arq = fopen(nome,"ab"))) //ab -> habilita inser��o de dados ao final do arquivo
         { 
          printf("Erro na abertura");
          system("pause");
         }
     else
       {  
         do
           {
             printf("\nNome: ");
             fflush(stdin);
             fgets(buffer.nome, sizeof(buffer.nome), stdin);
	         fflush(stdin);
             printf("Idade: ");
             scanf("%d",&buffer.idade);
             printf("Altura: ");
             scanf("%f",&buffer.altura);
             fwrite(&buffer,sizeof(struct atleta),1,arq);
             printf("\nO que dejesa fazer? \n1 - InserirNovo\n2 - Encerrar\nCodigo: ");
             scanf("%d", &op);
           } 
         while(op != 2);
         fclose(arq);      
         printf ("\n\n");
         system("pause"); 
         return 0;
      }  
   }
