/*
  Exemplo 1:
  Cria um arquivo de reais (float) positivos de forma sequencial.
  Apos, lista o conte�do do arquivo tambem sequencialmente.
*/ 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

FILE *fpin; //ponteiro para o arquivo

void criarq(FILE *);
void listarq(FILE *);

int main ()
{
    char filename[20];
    float x;
    system("color f1");
    printf (">>> GERA E MOSTRA LISTA DE ARQUIVO COM VALORES REAIS POSITIVOS <<<\n");
    
    if (!(fpin = fopen("numfloat","wb"))) 
    //Verifica ocorrencia de erro na abertura do arquivo
    //wb -> Deleta arquivo antigo e cria novo arquivo. Habilita Escrita
       printf("\nO arquivo nao pode ser aberto!");
    else
    {
       printf("\nGerando arquivo sequencial de float (reais) com o nome numfloat");
       criarq(fpin);
       fclose(fpin);
    }
    if (!(fpin = fopen("numfloat","rb")))
       printf("Nao foi possivel abrir o arquivo. Trabalho cancelado.\n");
    else
    { 
       printf ("\nAbrindo arquivo numfloat:"); 
       listarq(fpin);
       fclose(fpin);
       printf("\n\n");   
    } 
    system("pause");
    return 0;
} 

void criarq(FILE *fpin2)
{
     float x;
     printf("\nEntre com valores reais positivos");
     printf("\nNum. real (negativo para parar): ");
     scanf("%f",&x);
     while(x >= 0)
     {
        fwrite (&x, sizeof(float), 1, fpin2);
        //Escreve o conte�do de x no arquivo referente ao ponteiro fpin2
        printf("Num. real(negativo para parar): ");
        scanf("%f",&x);
     }
}
void listarq(FILE *fpin2)
{
     float x;
     while(fread(&x, sizeof(float),1,fpin2) !=0)
         printf("\n%6.2f",x);
}
