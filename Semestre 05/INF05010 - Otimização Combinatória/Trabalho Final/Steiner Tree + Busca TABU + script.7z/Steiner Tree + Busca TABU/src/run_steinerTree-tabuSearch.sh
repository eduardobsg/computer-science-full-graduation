#!/bin/sh

FILES="b14 i160-003 cc3-4p i160-033 c01 mc11 brasil58 d10 hc10p e20"

make clean
make -B

for file in $FILES;
do
	echo file=$file.stp >> out_$file.txt
	./steinertree < ../instancias/$file.stp >> out_$file.txt
done




