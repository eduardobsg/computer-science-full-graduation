# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Biblioteca::Application.config.secret_token = '88d24fb1a0fb088e5ea40285656f702c7666469b6bb42e1a5a33529681e98faa83e94551516a53d5d0d736dae71097d8771da7ec3eaffea032b74fac6abf97a0'
