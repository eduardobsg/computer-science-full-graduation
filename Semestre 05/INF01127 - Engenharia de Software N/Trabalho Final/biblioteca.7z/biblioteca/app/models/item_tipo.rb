class ItemTipo < ActiveRecord::Base
  has_many :item
end
