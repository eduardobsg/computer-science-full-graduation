class Item < ActiveRecord::Base
  belongs_to :itemTipo
end
