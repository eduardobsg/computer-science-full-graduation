class PessoaTipo < ActiveRecord::Base
  has_many :pessoa
end
