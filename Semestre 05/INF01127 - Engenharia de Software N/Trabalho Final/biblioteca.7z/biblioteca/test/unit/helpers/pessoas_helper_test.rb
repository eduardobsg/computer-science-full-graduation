require 'test_helper'

class PessoasHelperTest < ActionView::TestCase
end
