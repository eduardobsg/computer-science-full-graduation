require 'test_helper'

class PessoaTiposHelperTest < ActionView::TestCase
end
