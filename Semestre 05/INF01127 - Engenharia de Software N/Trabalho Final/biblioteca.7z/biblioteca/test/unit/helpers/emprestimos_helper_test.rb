require 'test_helper'

class EmprestimosHelperTest < ActionView::TestCase
end
