require 'test_helper'

class MultasHelperTest < ActionView::TestCase
end
