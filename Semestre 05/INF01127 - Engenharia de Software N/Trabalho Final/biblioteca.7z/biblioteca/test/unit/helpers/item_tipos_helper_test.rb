require 'test_helper'

class ItemTiposHelperTest < ActionView::TestCase
end
