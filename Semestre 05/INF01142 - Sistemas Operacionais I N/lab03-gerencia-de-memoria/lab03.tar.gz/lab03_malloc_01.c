#include<stdlib.h>

#define BUFF_SIZE 314159265

main()
{
	void *ptr;

	while(1)
		ptr = malloc(BUFF_SIZE);
}

