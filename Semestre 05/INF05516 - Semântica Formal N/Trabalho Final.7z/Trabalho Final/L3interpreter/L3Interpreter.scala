
//------------------------------------------------
// INF05516 - Semântica Formal N
// Professor Álvaro Moreira (http://www.inf.ufrgs.br/~afmoreira/doku.php?id=inf05516)
//
// 2011-01 - Turma A
// Trabalho de implementação de um verificador de tipos para L3
// Grupo: César Garcia Daudt, Jefferson Stoffel, João Luiz Gross
//------------------------------------------------

//------------------------------------------------
// T ::= int | bool | unit | T1 -> T2 | T ref
//------------------------------------------------

abstract class T
case class TInt()                      extends T
case class TBool()                     extends T
case class TUnit()                     extends T
case class TFn(t1:T, t2:T)             extends T
case class TRef(t:T)                   extends T

case class TRaise()                    extends T

//------------------------------------------------
//  e ::= n | b | e1 op e2 | if e1 then e2 else e3
//  		| e1:= e2 | !e | ref e | l
//  		| skip | e1; e2
//  		| while e1 do e2
//  		| fn x:T => e | e1 e2 | x
//  		| let x:T = e1 in e2 end
// 			| let rec f:T1 => T2 = (fn y:T1 => e1) in e2 end
//------------------------------------------------

abstract class Exp

case class N(n:Int)                         		extends Exp
case class B(b:Boolean)                     		extends Exp

case class Sum(e1:Exp, e2:Exp) 						extends Exp
case class Dif(e1:Exp, e2:Exp) 						extends Exp
case class Prod(e1:Exp, e2:Exp) 					extends Exp
case class Gte(e1:Exp, e2:Exp)     					extends Exp
case class Eql(e1:Exp, e2:Exp)     					extends Exp

case class If(e1:Exp, e2:Exp, e3:Exp)          		extends Exp
case class Atr(e1:Exp, e2:Exp)                  	extends Exp //Salva uma expressão em um endereço (alocado por Ref(e))

case class Deref(e:Exp)                       		extends Exp //!e: acesso a memória; trabalha com uma expressão
case class Ref(e:Exp)                         		extends Exp //ref e: aloca endereço de memória para e

case class Skip()                           		extends Exp
case class Seq(e1:Exp, e2:Exp)                  	extends Exp
case class While(e1:Exp, e2:Exp)                	extends Exp

case class Fn(s:String, t:T, e:Exp)           		extends Exp //Declara uma função sem nome
case class App(e1:Exp, e2:Exp)						extends Exp //Para substituição de valores
case class Var(s:String)                      		extends Exp //Representa um elemento pertencente ao conjunto de identificadores

case class Let(s:String, t:T, e1:Exp, e2:Exp)	  	extends Exp //Permite declarar identificadores
case class LetRec(s:String, t:TFn, e1:Exp, e2:Exp) 	extends Exp //Permite declarar funções recursivas

case class Raise(e:Exp)                      		extends Exp //Identificação de exceções
case class Try(e1:Exp, e2:Exp)                  	extends Exp //Tratamento de exceções

//------------------------------------------------
//
//------------------------------------------------
class L3Interpreter {
	
	//Sistema de Tipos
	def typeequal(t1:T, t2:T) : Boolean = {
		if(t1 == t2)
		  	true
		else
		  	(t1, t2) match{
		    	case (TRaise(), _) => true
		    	case (_, TRaise()) => true
		    	case _ => false
		  	}
	}

	def typeselect(t1:T, t2:T) : T = {
		(t1, t2) match {
		  	case (_, TRaise()) => t1
		  	case _ => t2
		}
	}
	
	def typecheck(e:Exp, gamma: List[(String, T)]) : Option[T] = e match {

		// Tint
		case N(_) => Some(TInt())

		// Tbool
		case B(_) => Some(TBool())

		// T+
		case Sum(e1:Exp, e2:Exp) =>
			(typecheck(e1, gamma), typecheck(e2, gamma)) match {
				case (Some(TInt() | TRaise()), Some(TInt() | TRaise())) => Some(TInt())
				case _ => None
			}
	
		// T-
		case Dif(e1:Exp, e2:Exp) =>
			(typecheck(e1, gamma), typecheck(e2, gamma)) match {
				case (Some(TInt() | TRaise()), Some(TInt() | TRaise())) => Some(TInt())
				case _ => None
			}
		
		// T *
		case Prod(e1:Exp, e2:Exp) =>
			(typecheck(e1, gamma), typecheck(e2, gamma)) match {
				case (Some(TInt() | TRaise()), Some(TInt() | TRaise())) => Some(TInt())
				case _ => None
			}
			
		// T>=
		case Gte(e1:Exp, e2:Exp) => 
			(typecheck(e1, gamma), typecheck(e2, gamma)) match {
	 			case (Some(TInt() | TRaise()), Some(TInt() | TRaise())) => Some	(TBool())
		    	case _ => None
			}	
			
		// T=
		case Eql(e1:Exp, e2:Exp) => 
			(typecheck(e1, gamma), typecheck(e2, gamma)) match {
	 			case (Some(TInt() | TRaise()), Some(TInt() | TRaise())) => Some	(TBool())
		    	case _ => None
			}		
	
		// Tif
		case If(e1:Exp, e2:Exp, e3:Exp) => 
      		(typecheck(e1, gamma), typecheck(e2, gamma), typecheck(e3, gamma)) match {
        		case (Some(TBool() | TRaise()), Some(t1), Some(t2)) if(typeequal(t1, t2)) => Some(typeselect(t1, t2))
        		case _ => None
			}
		
		// Tatr
		case Atr(e1:Exp, e2:Exp) => 
			(typecheck(e1, gamma), typecheck(e2, gamma)) match {
				case (Some(TRaise()), Some(t2)) => Some(TUnit())
		    	case (Some(TRef(t1)), Some(t2)) if(typeequal(t1, t2)) => Some(TUnit())
		    	case _ => None
			}

		// Tderef
		case Deref(e:Exp) => typecheck(e, gamma) match {
	        case (Some(TRaise())) => Some(TRaise())
        	case Some(TRef(t)) => Some(t)
        	case _ => None
        }
		        
		// Tref
		case Ref(e:Exp) => (typecheck(e, gamma)) match {
      		case (Some(t)) => Some(TRef(t))
      		case _ => None
    	}

		// Tskip
		case Skip() => Some(TUnit())

		// Tseq
		case Seq(e1:Exp, e2:Exp) => typecheck(e1, gamma) match {
			case Some(TUnit() | TRaise()) => typecheck(e2, gamma)
		    case _ => None
		}

		// Twhile
		case While(e1:Exp, e2:Exp) => 
			(typecheck(e1, gamma), typecheck(e2, gamma)) match {
				case (Some(TBool() | TRaise()), Some(TUnit() | TRaise())) => Some(TUnit())
				case _ => None
			}

		// Tfn
		case Fn(s:String, t:T, e:Exp) =>
		  	typecheck(e, gamma.filter(e => e._1 != s).::(s, t)) match {
		  		case (Some(t2)) => Some(TFn(t, t2))
				case _ => None
			}
			
		// Tapp
		case App(e1:Exp, e2:Exp) =>
		 	(typecheck(e1, gamma), typecheck(e2, gamma)) match {
		    	case (Some(TRaise()), Some(t2)) => Some(TRaise())
		    	case (Some(TFn(t1In, t1Out)), Some(t2)) if(typeequal(t1In, t2)) => Some(t1Out)
		    	case _ => None
		  	}	

		// Tvar
		case Var(s:String) =>
		  	val value: Option[(String, T)] = gamma.find(e => e._1 == s)
		  	if(value != None)
				Some(value.get._2)
		  	else
				None
		
		// Tlet
		case Let(s:String, t:T, e1:Exp, e2:Exp) =>
      		(typecheck(e1, gamma), typecheck(e2, gamma.filter(e => e._1 != s).::(s, t))) match {
        		case (Some(t1Lin), Some(t2Lin))
        			if(typeequal(t1Lin, t)) => Some(t2Lin)
        		case _ => None
      		}
		
		// Tletrec
		case LetRec(s:String, TFn(t1:T, t2:T), e1:Exp, e2:Exp) => None
      		var gammaLin = gamma.filter(e => e._1 != s).::(s, TFn(t1:T, t2:T))
			(typecheck(e1, gammaLin), typecheck(e2, gammaLin)) match {
        		case (Some(TFn(t1In, t1Out)), Some(t2Lin)) 
          			if(typeequal(t1In, t1) && typeequal(t1Out, t2)) => Some(t2Lin)
        		case _ => None
      		}
      		
		// Trs
		case Raise(e:Exp) => 
		  	(typecheck(e, gamma)) match {
		    	case (Some(TInt() | TRaise())) => Some(TRaise())
		    	case _ => None
		  	}

		// Ttry
		case Try(e1:Exp, e2:Exp) =>
		  	(typecheck(e1, gamma), typecheck(e2, gamma)) match {
		    	case (Some(t1), Some(TFn(t2In, t2Out))) if(typeequal(t1, t2Out)) => Some(typeselect(t1, t2Out))
		    	case _ => None
		  	}	
	}

	//Semântica Operacional

// Avaliacao
  def isvalue(e:Exp) : Boolean = e match
    {
      case N(_) => true
      case X(_) => true
      case B(_) => true
      case Fn(_,_,_) => true
      case Skip() => true
      case _ => false
    }

  type Endereco = String

  type Memoria = List[(Endereco,Exp)]

  def step(e: Exp, sigma: Memoria): Option[(Exp, Memoria)] = e match
    {
      /*************************SEMÂNTICA OPERACIONAL*************************/
      case N(_) => None
      case B(_) => None
      case Skip() => None

      case Sum(Raise(e1), e2) => Some(Raise(e1), sigma)
      case Sum(e1, Raise(e2)) => Some(Raise(e2), sigma)
      case Sum(e1, e2) => (e1,e2) match
	{
	  case (N(n1),N(n2)) => Some ((N(n1 + n2), sigma))
	  case (e1, e2) => if (isvalue(e1))
	    {
	      step(e2,sigma) match
		{
		  case Some((e2lin, sigmalin)) => Some((Sum(e1,e2lin), sigmalin))
		  case None => None
		}
	    } 
	    else
	      {
		step(e1, sigma) match
		  {
		    case Some((e1lin, sigmalin)) => Some((Sum(e1lin, e2), sigmalin))
		    case None => None
		  }
	      }
	}

      case Prod(Raise(e1), e2) => Some(Raise(e1), sigma)
      case Prod(e1, Raise(e2)) => Some(Raise(e2), sigma)
      case Prod(e1, e2) => (e1, e2) match
	{
	  case (N(n1),N(n2)) => Some ((N(n1 * n2), sigma))
	  case (e1, e2) => if (isvalue(e1))
	    {
	      step(e2,sigma) match
		{
		  case Some((e2lin, sigmalin)) => Some((Prod(e1,e2lin), sigmalin))
		  case None => None
		}
	    } 
	    else
	      {
		step(e1, sigma) match
		  {
		    case Some((e1lin, sigmalin)) => Some((Prod(e1lin, e2), sigmalin))
		    case None => None
		  }
	      }
	}

      case Dif(Raise(e1), e2) => Some(Raise(e1), sigma)
      case Dif(e1, Raise(e2)) => Some(Raise(e2), sigma)
      case Dif(e1, e2) => (e1, e2) match
	{
	  case (N(n1),N(n2)) => Some ((N(n1 - n2), sigma))
	  case (e1, e2) => if (isvalue(e1))
	    {
	      step(e2,sigma) match
		{
		  case Some((e2lin, sigmalin)) => Some((Dif(e1,e2lin), sigmalin))
		  case None => None
		}
	    } 
	    else
	      {
		step(e1, sigma) match
		  {
		    case Some((e1lin, sigmalin)) => Some((Dif(e1lin, e2), sigmalin))
		    case None => None
		  }
	      }
	}

      case Eql(Raise(e1), e2) => Some(Raise(e1), sigma)
      case Eql(e1, Raise(e2)) => Some(Raise(e2), sigma)
      case Eql(e1, e2) =>  (e1, e2) match
	{
	  case (N(n1),N(n2)) => Some ((B(n1 == n2), sigma))
	  case (e1, e2) => if (isvalue(e1))
	    {
	      step(e2,sigma) match
		{
		  case Some((e2lin, sigmalin)) => Some((Eql(e1,e2lin), sigmalin))
		  case None => None
		}
	    } 
	    else
	      {
		step(e1, sigma) match
		  {
		    case Some((e1lin, sigmalin)) => Some((Eql(e1lin, e2), sigmalin))
		    case None => None
		  }
	      }
	}

      case Gte(Raise(e1), e2) => Some(Raise(e1), sigma)
      case Gte(e1, Raise(e2)) => Some(Raise(e2), sigma)
      case Gte(e1, e2) =>  (e1, e2) match
	{
	  case (N(n1),N(n2)) => Some ((B(n1 >= n2), sigma))
	  case (e1, e2) => if (isvalue(e1))
	    {
	      step(e2,sigma) match
		{
		  case Some((e2lin, sigmalin)) => Some((Gte(e1,e2lin), sigmalin))
		  case None => None
		}
	    } 
	    else
	      {
		step(e1, sigma) match
		  {
		    case Some((e1lin, sigmalin)) => Some((Gte(e1lin, e2), sigmalin))
		    case None => None
		  }
	      }
	}

      case If(Raise(e1), e2, e3) => Some(Raise(e1), sigma)
      case If(B(true), e2, e3) => Some(e2, sigma)
      case If(B(false), e2, e3) => Some(e3, sigma)
      case If(e1, e2, e3) => step (e1, sigma) match
	{
	  case Some((e1lin, sigmalin)) => Some((If(e1lin, e2, e3), sigmalin))
	  case None => None
	}

      case Seq(Raise(e1), e2) => Some(Raise(e1), sigma)
      case Seq(e1, e2) => step (e1, sigma) match
	{
	  case Some((e1lin, sigmalin)) => Some((Seq(e1lin, e2), sigmalin))
	  case None => Some(e2, sigma)
	}

      case Atr(Raise(e1), e2) => Some(Raise(e1), sigma)
      case Atr(e1, Raise(e2)) => Some(Raise(e2), sigma)
      case Atr(e1, e2) => (e1, e2) match
	{
	  case (L(s1),v) => Some ((Skip(), sigma))	  
	  case (e1, e2) => if (isvalue(e1))
	    {
	      step(e2,sigma) match
		{
		  case Some((e2lin, sigmalin)) => Some((Atr(e1,e2lin), sigmalin))
		  case None => None
		}
	    }
	    else 
	      {
		step(e1, sigma) match
		  {
		    case Some((e1lin, sigmalin)) => Some((Atr(e1lin, e2), sigmalin))
		    case None => None
		  }
	      }
	}

      case While(e1, e2) => Some(If(e1,Seq(e2,While(e1, e2)), Skip()), sigma)

      case Raise(N(_)) => None
      case Raise(e) => step(e, sigma) match
	{
	  case Some((elin, sigmalin)) => Some(Raise(elin), sigmalin)
	  case _ => Some(e, sigma)
	}
      /***********************************************************************/
    }

  def eval(e: Exp, sigma:Memoria): Option[(Exp, Memoria)] =
  step(e,sigma) match
    {
      case None => Some((e,sigma))
      case Some((elin, sigmalin)) => eval(elin, sigmalin)
    }



}
	

//------------------------------------------------
//
//------------------------------------------------
object Main {	
	def run_tipos(e:Exp, sigma:List[(String, Exp)], gamma:List[(String, T)]) {

		new L3Interpreter().typecheck(e, gamma) match {
		  	case Some(t) => println("Exp: " + e + " T: " + t)
		  	case None => println("TYPE ERROR")
		}
	}

	def run_semantica(e:Exp, sigma:List[(String, Exp)]) {

		new L3Interpreter().eval(e, sigma) match 
		  {
		    case Some(t) => println("Sigma: " + t)
		    case None => println("OPERATION ERROR")
		  }
	}

	def main(args: Array[String]) {

		println()
		println("Testes: ")

		// Expressao e memoria para teste - Sistema de Tipos
		List(
			""" VALUES """,
			N(1), 												// TInt() - 5
			B(false), 											// TBool() - false

			""" OPERATIONS """,
			Sum(N(5), N(10)), 									// TInt() - 15
			Sum(N(5), N(10)),									// TInt() - -5
			Prod(N(10), N(100)), 								// TInt() - 1000
			Gte(N(5), N(10)), 									// TBool() - false
			Eql(N(5), N(5)), 									// TBool() - true			
			
			""" IF """,
			If(B(true), N(5), B(true)), 						// error
		    If(B(true), N(5), N(10)), 							// TInt() - 5
	     	If(B(true), B(false), B(true)), 					// TBool() - false
	     	If(B(false), B(false), B(true)), 					// TBool() - true
			If(Gte(N(5), Sum(N(2), N(3))), N(5), N(10)), 		// TInt() - 5
			
			""" SEQ """, 
			Seq(Skip(), N(5)), 									// TInt() - 5
		    Seq(N(5), N(5)), 									// error

			""" WHILE """,
      		While(B(false), N(5)), 								// TUnit()
     		While(B(false), Skip()), 							// TUnit()

		    """ REF & DEREF & ATR """,
	 	    Ref(Sum(N(5), N(3))), 								// TRef(TInt())
			Ref(Var("sla")),
      		Deref(Ref(N(5))),  									// TInt() - 5
		    Atr(Ref(N(5)), N(8)), 								// TUnit()
      		Atr(Ref(N(4)), N(65)), 								// TUnit()

		    """ FN  &  APP """,
		    Fn("x", TInt(), N(5)),								// TInt()
		    App(Fn("j", TInt(), Var("j")), N(4)), 				// TInt() - 4
		    Deref(App(Fn("x", TInt(), Ref(Var("x"))), N(100))),	// TInt() - 100
		    App(Deref(Ref(Fn("x", TInt(), Var("x")))), N(110)), // TInt() - 110

      		""" LET """,
      		Let("x", TInt(), N(5), Var("x")), 					// TInt() - 5
		    Let("x", TInt(), N(6), Sum(Var("x"), N(2))),		// TInt() - 8
		    Let("x", TInt(), N(6), 
		    	App(Fn("x", TInt(), Var("x")), 
		    		Sum(Var("x"), N(2)))), 						// TInt() - 8
		    Let("x", TRef(TInt()), Ref(N(4)), Deref(Var("x"))), // TInt() - 4

      		""" LET REC """,
      		LetRec("fn", TFn(TInt(), TInt()), 
      			Fn("y", TInt(), Var("y")), App(Var("fn"), N(3))),	// TInt()
      		LetRec("y", TFn(TInt(), TInt()), 
      			Fn("x", TInt(), Var("x")), App(Var("y"), N(3))),	// TInt()	
		
		   	""" TRY & RAISE """,
      		Try(Seq(Raise(N(5)), N(5)), 
      			Fn("r", TInt(), Var("r"))),						// TInt()
     		
     		App(
				Fn("x", TBool(),
					Try(
				    	If(Var("x"), Raise(N(1)), Fn("y", TBool(), B(true))),
				    	Fn("z", TInt(), Raise(N(2)))
				 	)
				), B(true)),									// TFn(TBool(),TBool())
				
			App(
				Fn("x", TBool(),
					Try(
				    	If(Var("x"), Raise(N(1)), Fn("y", TBool(), B(true))),
				    	Fn("z", TInt(), Raise(N(2)))
				  	)
				), B(false)),									// TFn(TBool(),TBool())

			Try(Gte(N(5), N(5)), Fn("r", TInt(), B(false))),	// TBool()
	      	Try(Raise(Raise(N(5))), Fn("r", TInt(), Var("r"))),	// TInt()
  		    Raise(Raise(N(5))),									// TRaise()
      		Let("e", TInt(), Sum(N(4), N(2)), Raise(Var("e")))	// TRaise()	
      		
		).foreach(i => 
				if(i.isInstanceOf[Exp])
        			run_tipos(i.asInstanceOf[Exp], List(), List())
      			else
        			println("\n*****" + i + "*****")
        )

		println()

		// Testes para semântica operacional	
		/*
			if, while, op, seq
		*/
	
		var ex:Exp = Sum(Prod(N(4),N(5)),Dif(N(7),N(8)))
		var sigma: List[(String,Exp)] = List(("l1",ex)/*, ("l2", ex)*/)
		run_semantica(ex, sigma)
		
		ex = Gte(N(5), N(7))
		sigma = List(("x",ex))
		run_semantica(ex, sigma)

		ex = Eql(N(5), N(7))
		sigma = List(("x",ex))
		run_semantica(ex, sigma)

		ex = Sum(Raise(B(false)), N(7))
		sigma = List(("x",ex))
		run_semantica(ex, sigma)

		ex = Seq(Sum(N(5), N(7)), Dif(N(8), N(7)))
		sigma = List(("x",ex))
		run_semantica(ex, sigma)

		val ex6:Exp = If(Gte(N(11), N(10)),(Sum(N(5), N(7))), Dif(/*N(8)*/B(false), N(7)))
		val sigma6: List[(String,Exp)] = List(("x",ex6))
		run_semantica(ex6, sigma6)
		
		val ex7:Exp = While(B(false), Skip())
		val sigma7: List[(String,Exp)] = List(("x",ex7))
		run_semantica(ex7, sigma7)
			
	}
}

