object Timer {

	def oncePerSecond(callback: () => Unit) {
		while(true) {
			callback();
			//Thread sleep 1000; //the same as Thread.sleep(1000), but less verbosely
			Thread.sleep(1000);
		}
	}
	
	def timeFlies() {
		println("time flies like an arrow...")
	}
	
	def main(args: Array[String]) {		
		//uncomment the following call to use timeFlies()
		//oncePerSecond(timeFlies)
		
		//this is the same the above, but with anonymous function (functions with no names)
		oncePerSecond(() => 
			println("hoio hoio, tempus fugit"))
	}

}

