object patterns {
	
	abstract class Tree	
	case class Sum(l: Tree, r: Tree) extends Tree	
	case class Var(s: String) extends Tree
	case class Const(n: Int) extends Tree

	//	couldn't use type construction
	//	but it should work as an alias
	type Environment = String => Int

	// s: string, n: int
	def eval(t: Tree, env: Environment): Int = t match {
		case Sum(l, r) 	=> eval(l, env) + eval(r, env)
		case Var(s)		=> env(s)
		case Const(n)	=> n
	}

	// s: string, n: int, w: string
	def derive(t: Tree, w: String): Tree = t match {
		case Sum(l, r) 			=> Sum(derive(l, w), derive(r, w))
		case Var(s) if (w == s)	=> Const(1)
		case _					=> Const(0)	// _ == anything else
	}

	def main(args: Array[String]) {
		val exp: Tree = Sum(Sum(Var("x"), Var("x")), Sum(Const(7), Var("y"))) // (x + x) + (7 + y)
		val env: Environment = {
			case "x" => 5
			case "y" => 7
		}
	
		println("Expression: " + exp)
		println("Expression with x = 5, y = 7: " + eval(exp, env)) // (x + x) + (7 + y) => (5 + 5) + (7 + 7) => 10 + 14 => 24
		println("Derivative relative to x:\n " + derive(exp, "x")) // [(x + x) + (7 + y)]dx => [(1 + 1) + (0 + 0)] => 2
		println("Derivative relative to y:\n " + derive(exp, "y")) // [(x + x) + (7 + y)]dy => [(0 + 0) + (0 + 1)] => 1
	}
}

