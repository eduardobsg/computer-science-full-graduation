class Complex(real: Double, imaginary: Double) {
	//although not explicitly declared, "real" and "imaginary" are members of Complex class.
	//Also, when calling Complex constructor (new Complex()), you should give two Double values 
	//as args (line 1 shows how to declare a constructor in the class definition)

	//these are functions with zero args, need to write ()
	def re() {
		println("Typing (). Real part: " + real)
	}
	def im() {
		println("Typing (). Imaginary part: " + imaginary)
	}
	
	//these are functions with no args. They do the same as above, but 
	//there is no need to type ()
	def re2 = {
		println("Without typing (). Real part: " + real)
	}
	def im2 = {
		println("Without typing (). Imaginary part: " + imaginary)
	}
	
	//some overriding example (toString is a member of Object class)
	override def toString() = {
		"" + real + (if (imaginary < 0) " " else " + ") + imaginary + "i"
	}
}

object ComplexNumbers {
	def main(args: Array[String]) {
		val c = new Complex(1.2, 3.4)
		c.re()
		c.im()
		c.re2
		c.im2
		println("Here is the number: " + c.toString())
	}
}
