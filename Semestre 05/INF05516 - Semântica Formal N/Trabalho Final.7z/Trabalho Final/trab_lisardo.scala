package semantica

/*
 *  INTERPRETADOR PARA A LINGUAGEM L3 de Peter Sewell
 *  INF05516 - Sem�ntica Formal N (2010/2) - �lvaro Moreira
 *
 *   Diego Morsolin Marcon
 *   Jean Carlo Emer
 *   Lisardo Sallaberry Kist
 */


/*
 *  T ::= int | bool | unit | T1 -> T2 | T ref
 */
abstract class T
case class TInt()                      extends T
case class TBool()                     extends T
case class TUnit()                     extends T
case class TFn(t1:T, t2:T)             extends T
case class TRef(t:T)                   extends T

case class TList(t:T)                  extends T
case class TNil()                      extends T

case class TRaise()                    extends T

abstract class Opr
case class Sum()                  extends Opr
case class Prd()                  extends Opr
case class Dif()                  extends Opr
case class Eql()                  extends Opr
case class Gte()                  extends Opr
/*
 *  e ::= n | b | e1 op e2 | if e1 then e2 else e3
 *  | e1:= e2 | ! e | ref e | l
 *  | skip | e1; e2
 *  | while e1 do e2
 *  | fn x:T => e | e1 e2 | x
 *  | let x:T = e1 in e2 end
 *  | let rec f:T1 => T2 = (fn y:T1 => e1) in e2 end
 */
abstract class E
trait V

case class N(n:Int)                         extends E with V
case class B(b:Boolean)                     extends E with V

case class Op(o:Opr, e1:E, e2:E)            extends E

case class If(e1:E, e2:E, e3:E)             extends E
case class Atr(e1:E, e2:E)                  extends E
case class Deref(e:E)                       extends E
case class Ref(e:E)                         extends E
case class L(s:String)                      extends E with V

case class Skip()                           extends E with V
case class Seq(e1:E, e2:E)                  extends E
case class While(e1:E, e2:E)                extends E

case class Fn(s:String, t:T, e:E)           extends E with V
case class Call(e1:E, e2:E)                 extends E
case class X(s:String)                      extends E with V
case class Let(s:String, t:T,  e1:E, e2:E)  extends E
case class LetRec(s:String, t:TFn, e1:E, e2:E) extends E

/*
 *  EXTRA 2
 *  listas (de acordo com a de?ni��o formal vista em aula). Nessa exens�o cuidar
 *  com o algoritmo de infer�ncia de tipo j� que a express�o nil pode ter um tipo
 *  qualquer a ser de?nido pelo contexto
 */
case class Cons(e1:E, e2:E)                 extends E with V
case class Nil()                            extends E with V
case class Hd(e:E)                          extends E
case class Tl(e:E)                          extends E
case class Empty(e:E)                       extends E

/*
 *  EXTRA 3
 *  de?ni��o formal e implementa��o de um mecanismo de ativa�ao e tratamento
 *  de exce��es atrav�s do qual seja poss�vel detectar tanto exce��es sem tratamento
 *  como tratadores sem exce��o (mais detalhes na lista de exerc�cios)
 */
case class Raise(e:E)                       extends E
case class Try(e1:E, e2:E)                  extends E


/*
 *  INTERPRETER
 */
class L3_interpreter{

  // SISTEMA DE TIPOS   
  def typeequal(t1:T, t2:T) : Boolean = {
    if(t1 == t2)
      true
    else
      (t1, t2) match{
        case (TList(_), TNil()) => true
        case (TNil(), TList(_)) => true
        case (TRaise(), _) => true
        case (_, TRaise()) => true
        case _ => false
      }
  }

  def typeselect(t1:T, t2:T) : T = {
    (t1, t2) match{
      case (TList(_), TNil()) => t1
      case (_, TRaise()) => t1
      case _ => t2
    }
  }
  
  def typecheck(e:E, gamma: List[(String,T)]) : Option[T] = e match {
    case N(_) => Some(TInt())
    case B(_) => Some(TBool())
    case Op(o:Opr, e1:E, e2:E) =>
      (o, typecheck(e1, gamma), typecheck(e2, gamma)) match{
        case (Gte() | Eql(), Some(TInt() | TRaise()), Some(TInt() | TRaise())) => Some(TBool())
        case (_, Some(TInt() | TRaise()), Some(TInt() | TRaise())) => Some(TInt())
        case _ => None
      }
    // T * IF
    case If(e1:E, e2:E, e3:E) =>
      (typecheck(e1, gamma), typecheck(e2, gamma), typecheck(e3, gamma)) match{
        case (Some(TBool() | TRaise()), Some(t1), Some(t2)) if(typeequal(t1, t2)) => Some(typeselect(t1, t2))
        case _ => None
      }
    // T * ATR
    case Atr(e1:E, e2:E) =>
      (typecheck(e1, gamma), typecheck(e2, gamma)) match{
        case (Some(TRaise()), Some(t2)) => Some(TUnit())
        case (Some(TRef(t1)), Some(t2)) if(typeequal(t1, t2)) => Some(TUnit())
        case _ => None
      }
    // T * DEREF
    case Deref(e:E) =>
      (typecheck(e, gamma)) match{
        case (Some(TRaise())) => Some(TRaise())
        case (Some(TRef(t))) => Some(t)
        case _ => None
      }
    // T * REF
    case Ref(e:E) => (typecheck(e, gamma)) match{
      case (Some(t)) => Some(TRef(t))
      case _ => None
    }
    // T * SKIP
    case Skip() => Some(TUnit())
    // T * SEQ
    case Seq(e1:E, e2:E) =>
      (typecheck(e1, gamma)) match{
        case (Some(TUnit() | TRaise())) => typecheck(e2, gamma)
        case _ => None
      }
    // T * WHILE
    case While(e1:E, e2:E) =>
      (typecheck(e1, gamma), typecheck(e2, gamma)) match{
        case (Some(TBool() | TRaise()), Some(TUnit() | TRaise())) => Some(TUnit())
        case _ => None
      }
    // T * FN
    case Fn(s:String, t:T, e:E) =>
      //println("FN: " + gamma.filter(i => i._1 != s).::(s,t))
      (typecheck(e, gamma.filter(i => i._1 != s).::(s,t))) match{
        case (Some(t2)) => Some(TFn(t, t2))
        case _ => None
      }
    // T * CALL
    case Call(e1:E, e2:E) =>
      (typecheck(e1, gamma), typecheck(e2, gamma)) match{
        case (Some(TRaise()), Some(t2)) => Some(TRaise())
        case (Some(TFn(t1In, t1Out)), Some(t2)) if(typeequal(t1In, t2)) => Some(t1Out)
        case _ => None
      }
    // T * X
    case X(s:String) =>
      val value = gamma.find(i => i._1 == s)
      if(value != None)
        Some(value.get._2)
      else
        None
    // T * LET
    case Let(s:String, t:T, e1:E, e2:E) =>
      (typecheck(e1, gamma), typecheck(e2, gamma.filter(i => i._1 != s).::(s,t))) match{
        case (Some(t1Lin), Some(t2Lin)) if(typeequal(t1Lin, t)) => Some(t2Lin)
        case _ => None
      }
    // T * LET REC
    case LetRec(s:String, TFn(t1:T, t2:T), e1:E, e2:E) => None
      var gammaLin = gamma.filter(i => i._1 != s).::(s, TFn(t1:T, t2:T))
      //println("LETREC: " + gammaLin)
      (typecheck(e1, gammaLin), typecheck(e2, gammaLin)) match{
        case (Some(TFn(t1In, t1Out)), Some(t2Lin))
          if(typeequal(t1In, t1) && typeequal(t1Out, t2)) => Some(t2Lin)
        case _ => None
      }

    // T * CONS
    case Cons(e1:E, e2:E) =>
      (typecheck(e1, gamma), typecheck(e2, gamma)) match{
        case (Some(t1), Some(TNil())) if(t1 != TNil()) => Some(TList(t1))
        case (Some(t1), Some(TList(t2))) if(t1 != TNil() && typeequal(t1, t2)) => Some(TList(typeselect(t1, t2)))
        case _ => None
      }
    // T * NIL 
    case Nil() => Some(TNil())
    // T * HD
    case Hd(Nil()) => None
    case Hd(e:E) =>
      (typecheck(e, gamma)) match{
        case (Some(TRaise())) => Some(TRaise())
        case (Some(TList(t))) => Some(t)
        case _ => None
      }
    // T * TL
    case Tl(Nil()) => None
    case Tl(e:E) =>
      (typecheck(e, gamma)) match{
        case (Some(TRaise())) => Some(TList(TRaise()))
        case (Some(TList(t))) => Some(TList(t))
        case _ => None
      }
    // T * Empty
    case Empty(Nil()) => Some(TBool())
    case Empty(e:E) => 
      (typecheck(e, gamma)) match{
        case (Some(TList(_) | TRaise())) => Some(TBool())
        case _ => None
      }

    // T * RAISE
    case Raise(e:E) => 
      (typecheck(e, gamma)) match{
        case (Some(TInt() | TRaise())) => Some(TRaise())
        case _ => None
      }
    // T * TRY
    case Try(e1:E, e2:E) =>
      (typecheck(e1, gamma), typecheck(e2, gamma)) match{
        case (Some(t1), Some(TFn(t2In, t2Out))) if(typeequal(t1, t2Out)) => Some(typeselect(t1, t2Out))
        case _ => None
      }
  }

  
  /*
   *
   * SEMANTICA OPERACIONAL
   *
   */
  type Memory = List[(String, E)]
  def step(e:E, sigma:Memory) : Option[(E, Memory)] = e match{
    case N(_) => None
    case B(_) => None
    // OP
      /*R*/ case Op(o:Opr, Raise(e1), e2:E) => Some(Raise(e1), sigma)
      /*R*/ case Op(o:Opr, e1:E, Raise(e2)) => Some(Raise(e2), sigma)
    case Op(Sum(), N(n1), N(n2)) => Some(N(n1 + n2), sigma)
    case Op(Prd(), N(n1), N(n2)) => Some(N(n1 * n2), sigma)
    case Op(Dif(), N(n1), N(n2)) => Some(N(n1 - n2), sigma)
    case Op(Eql(), N(n1), N(n2)) => Some(B(n1 == n2), sigma)
    case Op(Gte(), N(n1), N(n2)) => Some(B(n1 >= n2), sigma)
    case Op(o:Opr, v1:V, e2:E) =>
      step(e2, sigma) match{
        case Some((e2Lin, sigmaLin)) => Some(Op(o, v1, e2Lin), sigmaLin)
        case None => None
      }
    case Op(o:Opr, e1:E, e2:E) =>
      step(e1, sigma) match{
        case Some((e1Lin, sigmaLin)) => Some(Op(o, e1Lin, e2), sigmaLin)
        case None => None
      }

    // IF
      /*R*/ case If(Raise(e1), e2:E, e3:E) => Some(Raise(e1), sigma)
    case If(B(true), e2:E, e3:E) => Some(e2, sigma)
    case If(B(false), e2:E, e3:E) => Some(e3, sigma)
    case If(e1:E, e2:E, e3:E) =>  step(e1, sigma) match{
      case Some((e1Lin, sigmaLin)) => Some(If(e1Lin, e2, e3), sigmaLin)
      case None => None
    }
    // ATR
      /*R*/ case Atr(Raise(e1), e2:E) => Some(Raise(e1), sigma)
      /*R*/ case Atr(e1:E, Raise(e2)) => Some(Raise(e2), sigma)
    case Atr(L(s), v:V) =>
      if(sigma.find(i => i._1 == s) != None) // pertence ao Dom?
        Some(Skip(), sigma.filter(i => i._1 != s).::(s, v))
      else
        None
    case Atr(L(s), e2:E) =>
      step(e2, sigma) match{
        case Some((e2Lin, sigmaLin)) => Some((Atr(L(s), e2Lin), sigmaLin))
        case None => None
      }
    case Atr(e1:E, e2:E) => step(e1, sigma) match{
      case Some((e1Lin, sigmaLin)) => Some((Atr(e1Lin, e2), sigmaLin))
      case None => None
    }
    // DEREF
      /*R*/ case Deref(Raise(e)) => Some(Raise(e), sigma)
    case Deref(L(s)) =>
      val value = sigma.find(i => i._1 == s)
      if(value != None)
        Some(value.get._2, sigma)
      else
        None
    case Deref(e:E) => step(e, sigma) match{
      case Some((eLin, sigmaLin)) => Some((Deref(eLin), sigmaLin))
      case None => None
    }
    // REF
      /*R*/ case Ref(Raise(e)) => Some(Raise(e), sigma)
    case Ref(v:V) =>
      var s = "" ; var x = 1
      while(x > 0){
        s = "l" + x
        x = if(sigma.filter(i => i._1 == s).isEmpty) 0 else x+1
      }
      Some(L(s), (sigma.::(s, v)))
    case Ref(e:E) => step(e, sigma) match{
      case Some((eLin, sigmaLin)) => Some(Ref(eLin), sigmaLin)
      case None => None
    }
    // L
    case L(s:String) => None
    // SKIP
    case Skip() => None
    // SEQ
      /*R*/ case Seq(Raise(e1), e2:E) => Some(Raise(e1), sigma)
      /*R*/ case Seq(e1:E, Raise(e2)) => Some(Raise(e2), sigma)
    case Seq(e1:E, e2:E) => step(e1, sigma) match{
      case Some((e1Lin, sigmaLin)) => Some((Seq(e1Lin, e2), sigmaLin))
      case None => Some(e2, sigma)
    }
    // WHILE
    case While(e1:E, e2:E) =>
      Some(If(e1, Seq(e2, While(e1, e2)), Skip()), sigma)
    // FN
    case Fn(s:String, t:T, e:E) => None

    // CALL
      /*R*/ case Call(Raise(e1:V), e2:E) => Some(Raise(e1), sigma)
      /*R*/ case Call(e1:V, Raise(e2)) => Some(Raise(e2), sigma)
    case Call(Fn(s:String, t:T, e:E), v2:V) => Some(replace(e, s, v2), sigma)
    case Call(Fn(s:String, t:T, e:E), e2:E) =>
      step(e2, sigma) match{
        case Some((e2Lin, sigmaLin)) => Some(Call(Fn(s, t, e), e2Lin), sigmaLin)
        case None => None
      }
    case Call(e1:E, e2:E) => step(e1, sigma) match{
      case Some((e1Lin, sigmaLin)) => Some((Call(e1Lin, e2), sigmaLin))
      case None => None
    }
    // X
    case X(s:String) => None
    // LET
    case Let(s:String, t:T, v1:V, e2:E) => Some(replace(e2, s, v1), sigma)
    case Let(s:String, t:T, e1:E, e2:E) =>
      step(e1, sigma) match{
        case Some((e1Lin, sigmaLin)) => Some(Let(s, t, e1Lin, e2), sigmaLin)
        case None => None
      }
    // LET REC
    case LetRec(s:String, t:TFn, Fn(y:String, t1:T, e1:E), e2:E) =>
      Some(
        replace(e2, s,
          Fn(y, t1, LetRec(s, t, Fn(y, t1, e1), e1))
        ), sigma)

    // CONS
    case Cons(v1:V, Nil()) => None
    case Cons(v1:V, e2:E) => step(e2, sigma) match{
      case Some((e2Lin, sigmaLin)) => Some(Cons(v1, e2Lin), sigmaLin)
      case t => None
    }
    case Cons(e1:E, e2:E) => step(e1, sigma) match{
      case Some((e1Lin, sigmaLin)) => Some(Cons(e1Lin, e2), sigmaLin)
      case _ => None
    }

    // NIL
    case Nil() => None
    // HD
      /*R*/ case Hd(Raise(e)) => Some(Raise(e), sigma)
    case Hd(Nil()) => None
    case Hd(Cons(e1:E, e2:E)) => Some(e1, sigma)
    case Hd(e:E) => step(e, sigma) match{
      case Some((e1:E, sigmaLin)) => Some(Hd(e1), sigmaLin)
      case _ => None
    }
    // TL
      /*R*/ case Tl(Raise(e)) => Some(Raise(e), sigma)
    case Tl(Cons(e1:E, e2:E)) => Some(e2, sigma)
    case Tl(e:E) => step(e, sigma) match{
      case Some((e1:E, sigmaLin)) => Some(Tl(e1), sigmaLin)
      case _ => None
    }
    // EMPTY
      /*R*/ case Empty(Raise(e)) => Some(Raise(e), sigma)
    case Empty(Nil()) => Some(B(true), sigma)
    case Empty(Cons(e1:E, e2:E)) => Some(B(false), sigma)
    case Empty(e:E) => step(e, sigma) match{
      case Some((eLin, sigmaLin)) => Some(Empty(eLin), sigmaLin)
      case _ => None
    }

    // RAISE
    case Raise(N(_)) => None
    case Raise(e:E) => step(e, sigma) match{
      case Some((eLin, sigmaLin)) => Some(Raise(eLin), sigmaLin)
      case _ => Some(e, sigma)
    }
    // TRY
    case Try(e1:V, e2:Fn) => Some(e1, sigma)
    case Try(e1:E, e2:Fn) => step(e1, sigma) match{
      case Some((Raise(e1Lin), sigmaLin)) => Some(Call(e2, e1Lin), sigmaLin)
      case Some((eLin, sigmaLin)) => Some(Try(eLin, e2), sigmaLin)
      case _ => None
    }
  }

  /*
   * REPLACE / em E troco S por v
   */
  def replace(e:E, s:String, v:E) : E = e match{
    // R * OP
    case Op(o, e1, e2) =>
      Op(o, replace(e1, s, v), replace(e2, s, v))
    // R * IF
    case If(e1, e2, e3) => 
      If(replace(e1, s, v), replace(e2, s, v), replace(e3, s, v))
    // R * ATR
      Atr(replace(e1, s, v), replace(e2, s, v))
    // R * DEREF
    case Deref(e:E) =>
      Deref(replace(e, s, v))
    // R * REF
    case Ref(e:E) =>
      Ref(replace(e, s, v))
    // R * SEQ
    case Seq(e1:E, e2:E) =>
      Seq(replace(e1, s, v), replace(e2, s, v))
    // R * WHILE
    case While(e1:E, e2:E) =>
      While(replace(e1, s, v), replace(e2, s, v))
    // R * FN
    case Fn(s1:String, t:T, e1:E) if(s != s1) =>
      Fn(s1, t, replace(e1, s, v))
    // R * CALL
    case Call(e1:E, e2:E) =>
      Call(replace(e1, s, v), replace(e2, s, v))
    // R * X
    case X(s1:String) if(s == s1) => v // !IMPORTANT
    // R * LET
    case Let(s1:String, t:T, e1:E, e2:E) if(s != s1) =>
      Let(s1, t, e1, replace(e2, s, v))
    // R * LET REC
    case LetRec(s1:String, t:TFn, e1:E, e2:E) if(s != s1) =>
      LetRec(s1, t,
             replace(e1, s, v),
             replace(e2, s, v))
      
    // R * CONS
    case Cons(e1:E, e2:E) => 
      Cons(replace(e1, s, v), replace(e2, s, v))
    // R * HD
    case Hd(e1:E) => Hd(replace(e1, s, v))
    // R * TL
    case Tl(e1:E) => Tl(replace(e1, s, v))
    // R * EMPTY
    case Empty(e1:E) => Empty(replace(e1, s, v))

    // R * RAISE
    case Raise(e1:E) => Raise(replace(e1, s, v))
    // R * TRY
    case Try(e1:E, e2:E) =>
      Try(replace(e1, s, v), replace(e2, s, v))

    case _ => e
  }

  /*
   * EVAL
   */
  def eval(e:E, sigma:Memory) : Option[(E, Memory)] = step(e, sigma) match{
    case None => Some((e, sigma))
    case Some((eLin, sigmaLin)) => eval(eLin, sigmaLin)
  }
}


/*
 *  CASES
 */
object L3 {
  def main(args: Array[String]){
    List(     
      """
       *  OP
      """,
      Op(Sum(), Op(Sum(), N(5), N(10)), Op(Prd(), N(10), N(100))), // 1015

      Op(Gte(), N(5), N(10)), // false

      Op(Eql(), N(10), N(10)), // true

      """
       *  IF
      """,
      If(B(true), N(5), B(true)), // -- error

      If(B(true), N(5), N(10)), // 5

      If(B(true), B(false), B(true)), // false

      If(Op(Eql(), N(5), Op(Sum(), N(2), N(3))), N(5), N(10)), // 5

      """
       *  SEQ
      """,
      Seq(Skip(), N(5)), // 5

      Seq(N(5), N(5)), // -- error

      """
       *  WHILE
      """,
      While(B(false), N(5)), // Skip()

      While(B(false), Skip()), // Skip()

      """
       *  REF   &   DEREF   &   ATR
      """,
      Ref(Op(Sum(), N(5), N(3))), // L(l1)

      Deref(Ref(N(5))),  // 5

      Atr(Ref(N(5)), N(8)), // Skip()

      Atr(Ref(N(4)), N(65)), // Skip()

      """
       *  FN  &  CALL
      """,
      Fn("x", TInt(), N(5)),

      Call(Fn("j", TInt(), X("j")), N(4)), // 4

      Deref(Call(Fn("x", TInt(), Ref(X("x"))), N(100))), // 100

      Call(Deref(Ref(Fn("x", TInt(), X("x")))), N(110)), // 110

      """
       *  LET
      """,
      Let("x", TInt(), N(5), X("x")), // 5

      Let("x", TInt(), N(6), Op(Sum(), X("x"), N(2))), // 8

      Let("x", TInt(), N(6), Call(Fn("x", TInt(), X("x")), Op(Sum(), X("x"), N(2)))), // 8

      Let("x", TRef(TInt()), Ref(N(4)), Deref(X("x"))), // 4
      
      """
       *  X
      """,
      X("s"),

      """
       *  LET REC
      """,
      LetRec("fn", TFn(TInt(), TInt()), Fn("y", TInt(), X("y")), Call(X("fn"), N(3))),

      LetRec("y", TFn(TInt(), TInt()), Fn("x", TInt(), X("x")), Call(X("y"), N(3))),

      """
       *  LIST
      """,
      Cons(N(5), Cons(N(5), Nil())),

      Hd(Cons(N(5), Cons(N(5), Nil()))),

      Deref(Ref(Cons(N(5), Cons(N(5), Nil())))),

      Hd(Deref(Ref(Cons(N(5), Cons(N(5), Nil()))))),

      Tl(Cons(N(5), Cons(N(5), Nil()))),

      Hd(Tl(Cons(N(5), Nil()))),

      Hd(Nil()),

      Let("x", TInt(), Hd(Tl(Cons(N(5), Cons(X("x"), N(5))))), N(4)),

      Let("x", TInt(), Hd(Tl(Cons(N(5), Cons(X("x"), Nil())))), N(4)),

      Cons(Op(Sum(), N(5), N(5)), Nil()),

      Call(Fn("L", TList(TInt()), Skip()), Nil()),

      """
       *  INC  &  FAT
      """,
      LetRec("Inc", TFn(TList(TInt()), TList(TInt())),
        Fn("L",
          TList(TInt()),
          Cons(
            Op(Sum(), Hd(X("L")), N(1)),
            If(
              Empty(Tl(X("L"))),
              Nil(),
              Call(X("Inc"), Tl(X("L")))
            )
          )
        ), Call(X("Inc"), Cons(N(5), Cons(N(4), Cons(N(3), Nil()))))
      ),

      LetRec("Inc", TFn(TList(TInt()), TList(TInt())),
        Fn("L",
          TList(TInt()),
          If(
            Empty(X("L")),
            Nil(),
            Cons(
              Op(Sum(), Hd(X("L")), N(1)),
              Call(X("Inc"), Tl(X("L")))
            )
          )
        ),
        Call(X("Inc"), Cons(N(5), Cons(N(4), Cons(N(3), Nil()))))
      ),

      LetRec("fat", TFn(TInt(), TInt()),
        Fn("y",
          TInt(),
          If(Op(Eql(), N(0), X("y")),
            N(1),
            Op(Prd(), X("y"), Call(X("fat"), Op(Sum(), X("y"), N(-1))))
          )
        ),
        Call(X("fat"), N(10))
      ),
      
      LetRec("fateach", TFn(TList(TInt()), TList(TInt())),
        Fn("L",
          TList(TInt()),
          If(
            Empty(X("L")),
            Nil(),
            Cons(
              LetRec("fat", TFn(TInt(), TInt()),
                Fn("y",
                  TInt(),
                  If(Op(Eql(), N(0), X("y")),
                    N(1),
                    Op(Prd(), X("y"), Call(X("fat"), Op(Sum(), X("y"), N(-1))))
                  )
                ),
                Call(X("fat"), Hd(X("L")))
              ),
              Call(X("fateach"), Tl(X("L")))
            )
          )
        ),
        Call(X("fateach"), Cons(N(5), Cons(N(4), Cons(N(3), Nil()))))
      ),
      
      """
       *  TRY   &   RAISE
      """,
      Try(Seq(Raise(N(5)), N(5)), Fn("r", TInt(), X("r"))),

      Call(
        Fn("x", TBool(),
          Try(
            If(X("x"), Raise(N(1)), Fn("y", TBool(), B(true))),
            Fn("z", TInt(), Raise(N(2)))
          )
        ), B(true)),

      Call(
        Fn("x", TBool(),
          Try(
            If(X("x"), Raise(N(1)), Fn("y", TBool(), B(true))),
            Fn("z", TInt(), Raise(N(2)))
          )
        ), B(false)),

      Try(Op(Gte(), N(5), N(5)), Fn("r", TInt(), B(false))),

      Try(Raise(Raise(N(5))), Fn("r", TInt(), X("r"))),

      Raise(Raise(N(5))),

      Let("e", TInt(), Op(Sum(), N(4), N(2)), Raise(X("e"))),

      Let("e", TInt(), Op(Sum(), N(4), N(2)), Cons(Raise(N(2)), Nil())),

      LetRec("fat", TFn(TInt(), TInt()),
        Fn("y",
          TInt(),
          If(Op(Gte(), N(-1), X("y")),
            Raise(N(1)),
            If(Op(Eql(), N(0), X("y")),
              N(1),
              Op(Prd(), X("y"), Call(X("fat"), Op(Sum(), X("y"), N(-1))))
            )
          )
        ),
        Call(X("fat"), N(1))
      ),

      Try(
        Let("e", TInt(), Op(Sum(), N(4), N(2)), Cons(Raise(X("e")), Nil())),
        Fn("r", TInt(), Nil())
      ),
      
      Cons(Raise(N(5)), Cons(N(4), Cons(Raise(N(3)), Nil()))),

      If(B(true), Nil(), Raise(N(4)))



      
    /* APPLY RUN TO EACH TEST */
    ).foreach(i =>
      if(i.isInstanceOf[E])
        run(i.asInstanceOf[E], List(), List())
      else
        println("      ****************************" + i + "****************************\n")
    )
  }

  /*
   * RUN
   */
  def run(e:E, sigma:List[(String, E)], gamma:List[(String, T)]){
    println("**\nE: " + e)

    new L3_interpreter().typecheck(e, gamma) match{
      case Some(t) => println("T: " + t)
      case None => println("* TYPE ERROR")
    }
  }
}
