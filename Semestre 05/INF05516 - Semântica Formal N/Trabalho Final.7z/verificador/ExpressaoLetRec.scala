/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class ExpressaoLetRec extends Expressao{
    private var tipo:Tipo = null;
    private var tipoIdent:Tipo = null;
    private var e1:ExpressaoFn = null;
    private var e2:Expressao = null;
    val nomeExpressao = "letrec"
    private var fimDeContexto = "in";
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    def addExpr(e: Expressao):Unit = {
        if(e1 == null){
            if(e.isInstanceOf[ExpressaoFn]){
                e1 = e.asInstanceOf[ExpressaoFn]
                fimDeContexto = "end";
            }else{
                throw new Exception("Função esperada");
            }
        }else if(e2 == null){
            e2 = e
            if(tipoIdent.isPonteiro && tipoIdent.getTipoApontado.isIgual(e1.getTipo) && tipoIdent.isIgualSemPonteiro(e1.getTipoIdent)){
                tipo = e2.getTipo 
            }else{
                throw new Exception("Incoerencia de tipos");
            }
        }
    }
    def setTipoIdent(t: Tipo):Unit={
        tipoIdent = t
    }
    
   
    def getTipo():Tipo = {
        tipo
    }
}

