/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class ExpressaoSkip extends Expressao{
    val nomeExpressao = "skip"
    private var fimDeContexto = "";
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    def addExpr(e:Expressao){
        //nothing
    }
    def getTipo():Tipo = {
        new Tipo("unit")
    }
}
