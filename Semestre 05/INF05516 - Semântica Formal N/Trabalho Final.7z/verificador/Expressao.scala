/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

abstract class Expressao {
    
    val nomeExpressao:String;
    def addExpr(e:Expressao):Unit;
    def getFimDeContexto():String; 
    def getTipo():Tipo;
}
