/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class ExpressaoDeref extends Expressao {
    private var tipo:Tipo = null;
    private var fimDeContexto = "";
    private var e1:Expressao = null;
    val nomeExpressao = "deref"
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    def addExpr(e: Expressao):Unit = {
        e1 = e;
        if(e1.getTipo.isRef){
            tipo = e1.getTipo.getTipoReferenciado;
        }else{
            throw new Exception("Incoerencia de tipos");
        }
    }
    
    def getTipo():Tipo = {
        tipo
    }
}
