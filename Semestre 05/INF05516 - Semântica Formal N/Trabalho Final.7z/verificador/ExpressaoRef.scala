/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class ExpressaoRef extends Expressao {
    private var tipo:Tipo = null;
    private var e1:Expressao = null;
    val nomeExpressao = "ref"
    private var fimDeContexto = "";
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    def addExpr(e:Expressao):Unit = {
        e1 = e
        tipo = new Tipo("unit")
        tipo.setRef(e1.getTipo)
    }
    
    def getTipo():Tipo = {
        tipo
    }
}
