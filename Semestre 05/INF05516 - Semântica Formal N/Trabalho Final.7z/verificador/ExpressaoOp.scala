/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class ExpressaoOp extends Expressao{
    private var tipo:Tipo = null;
    private var operador:String = "";
    private var e1:Expressao = null;
    private var e2:Expressao = null;
    val nomeExpressao = "op";
    private var fimDeContexto = "";
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    
    def this(op:String) = this(operador = op)
    
    def addExpr(e:Expressao):Unit = {
        if(e1 == null){
            e1 = e
        }else{
            e2 = e
            val tipoInt = new Tipo("int");
            if(tipoInt.isIgual(e1.getTipo) && tipoInt.isIgual(e2.getTipo)){
                if(operador.compareTo("+") == 0){
                    tipo = tipoInt
                }else if(operador.compareTo(">=") == 0){
                    tipo = new Tipo("bool")
                }else{
                    throw new Exception("Parâmetro inválido");
                }
            }else{
                
                throw new Exception("Incoerencia de tipos");
            }    
        }
    }
    
    def getTipo():Tipo = {
        tipo
    }
}
