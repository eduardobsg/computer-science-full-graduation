/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class ExpressaoLet extends Expressao{
    private var tipo:Tipo = null;
    private var tipoIdent:Tipo = null;
    private var e1:Expressao = null;
    private var e2:Expressao = null;
    val nomeExpressao = "let"
    private var fimDeContexto = "in";
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    def addExpr(e: Expressao):Unit = {
        if(e1 == null){
            e1 = e
            fimDeContexto = "end";
        }else if(e2 == null){
            e2 = e
            if(e1.getTipo.isIgual(tipoIdent)){
                tipo = e2.getTipo
            }else{
                throw new Exception("Incoerencia de tipos");
            } 
        }
    }
    
    def setTipoIdent(t: Tipo):Unit={
        tipoIdent = t
    }
    
    def getTipo():Tipo = {
        if(tipo == null){
            throw new Exception("Expressão incompleta");
        }
        tipo
    }
}
