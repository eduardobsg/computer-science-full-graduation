/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador 

class ExpressaoValor extends Expressao{
    private var tipo:Tipo = null;
    private var valor:String = "";
    val nomeExpressao = "valor"
    private var fimDeContexto = "";
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    def addExpr(e:Expressao){
        //nothing
    }
    def this(v: String) = {
        this(
        if(v.compareTo("numero") == 0){
            tipo = new Tipo("int")
        }else if(v.compareTo("booleano") == 0){
            tipo = new Tipo("bool")
        }else{
            throw new Exception("Parâmetro inválido");
        }
        )
    }
    
    def getTipo():Tipo = {
        tipo
    }

}
