/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

object Main {
    
    var pilha:List[Expressao] = List[Expressao]();
    var pilhaIdent:List[ExpressaoIdent] = List[ExpressaoIdent]();
    /**
     * @param args the command line arguments
     */
    def main(args: Array[String]): Unit = {
        try{
            println("Informe o arquivo com o programa a ser verificado:")
            val diretorio = readLine()
            val conteudoArquivo = scala.io.Source.fromFile(diretorio).mkString
            println(conteudoArquivo)
            Tokens.getTokens(conteudoArquivo)
            var e:Expressao = null
            
            var tokens = Tokens.tokens
            for(i <-0 until tokens.length){
                if(Tokens.isDeMeio(tokens(i))){
                    if(e == null){
                        throw new Exception("Expressao incorreta")
                    }else{
                        pilha::= Tokens.getExpressao(tokens(i))
                        pilha(0).addExpr(e)
                        e = null
                    }
                }else if(Tokens.isFimDeExpressao(tokens(i))){
                    if(pilha.isEmpty){
                        throw new Exception("Fim de Expressão incorreto")
                    }
                    if(pilha(0).getFimDeContexto.compareTo(tokens(i)) == 0){
                        if(e == null){
                            throw new Exception("Expressao incorreta")
                        }
                        pilha(0).addExpr(e)
                        e = null
                        if(pilha(0).getTipo != null){
                            e = pilha(0)
                            pilha = pilha.tail   
                        }
                    }else{
                        throw new Exception("Fim de Expressão incorreto")
                    }
                }else {
                    var e1:Expressao = null
                    if(tokens(i).startsWith("id")){
                        e1 = getIdFromPilha(tokens(i))
                    }else if(tokens(i).compareTo("numero") == 0 || tokens(i).compareTo("booleano") == 0){
                        e1 = new ExpressaoValor(tokens(i))
                    }else{
                        e1 = Tokens.getExpressao(tokens(i))
                    }
                    if(e != null){
                        pilha ::= new ExpressaoApp()
                        pilha(0).addExpr(e)
                    }   
                    e = e1
                }
                if(e != null){
                    while(i < (tokens.length - 1) && e.getTipo != null && (pilha.length == 0 || pilha(0).getFimDeContexto.compareTo("") == 0)){
                        pilha(0).addExpr(e)
                        e = pilha(0)
                        pilha = pilha.tail
                    }
                    if(e.getTipo == null){
                        pilha::=e
                        e = null
                    }
                }
            }
            
            print(e.getTipo.getNome)
            
        }catch{
            case e: Exception => println(e.getMessage)
        }
    }
    
    def getIdFromPilha(token: String):ExpressaoIdent = {
        for(i <-0 until pilhaIdent.length){
            if(pilhaIdent(i).getNomeIdent.compareTo(token) == 0){
                pilhaIdent(i);
            }
        }
        throw new Exception("Identificador fora de escopo");
    }

}
