/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class ExpressaoSeq extends Expressao{
    private var tipo:Tipo = null;
    private var e1:Expressao = null;
    private var e2:Expressao = null;
    val nomeExpressao = "seq"
   private var fimDeContexto = "";
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    
    def addExpr(e: Expressao):Unit = {
        if(e1 == null){
            e1 = e
        }else{
            e2 = e
            val tipoUnit = new Tipo("unit");
            if(tipoUnit.isIgual(e1.getTipo)){
                tipo = e2.getTipo
            }else{
                throw new Exception("Incoerencia de tipos");
            }   
        }
    }
    
    def getTipo():Tipo = {
        tipo
    }
}
