/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class ExpressaoIf extends Expressao{
    private var tipo:Tipo = null;
    private var e1:Expressao = null;
    private var e2:Expressao = null;
    private var e3:Expressao = null;
    private var fimDeContexto = "then";
    val nomeExpressao="if";
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    
    def addExpr(e:Expressao):Unit = {
        if(e1 == null){
            e1 = e;
            fimDeContexto = "else"
        }else if(e2 == null){
            e2 = e;
            fimDeContexto = ""
        }else{
            e3 = e
            val tipoBool = new Tipo("bool");
            
            if(tipoBool.isIgual(e1.getTipo) && e2.getTipo.isIgual(e3.getTipo)){
                tipo = e2.getTipo;
            }else{
                throw new Exception("Incoerencia de tipos");
            }  
        }
    }
    def getTipo():Tipo = {
        tipo
    }
}

