/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
 
package verificador

class ExpressaoIdent extends Expressao{
	private var tipo:Tipo = null;
    private var nomeIdent = "";
    private var posicaoPilha = 0;
    val nomeExpressao = "ident"
    private var fimDeContexto = "";
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    
    def setNomeIdent(nome: String):Unit = {
        nomeIdent = nome
    }
    
    def getNomeIdent():String = {
        nomeIdent
    }
    
    def setTipo(t:Tipo):Unit = {
        tipo = t;
    }
    
    def addExpr(e:Expressao):Unit = {
        //Nothing
    }
    
    def this(pp: Int) = this(posicaoPilha = pp)
    
    def getTipo():Tipo = {
        tipo
    }
}
