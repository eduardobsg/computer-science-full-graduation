/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

object Tokens {
    var tokens = List[String]();
    private var isNumero = false;
    private var isLiteral = false;
    private var isMenos = false;
    private var isIgual = false;
    private var isMaior = false;
    private var isDoisPontos = false;
    var token = "";
    
    private def addToken():Unit = {
        if(isNumero){
            tokens:+="numero"
        }else if(token.compareTo("true") == 0 || token.compareTo("false") == 0){
            tokens:+="booleano"
        }else if(isReservado){
            if(token.compareTo("=>") != 0){
                tokens:+=token
            }else{
                tokens:+="="
            }
        }else if(isLiteral){
            val tokenCharList = token.toList
            var isSohDeUnderline = true;
            for (i <- 0 until tokenCharList.length){
                val richChar = new runtime.RichChar(tokenCharList(i))
                isSohDeUnderline = isSohDeUnderline && !richChar.isLetterOrDigit
            }
            if(isSohDeUnderline){
                throw new Exception("Token invalido: " + token)
            }
            else{
                tokens:+="id" + token
            }
        }else{
            throw new Exception("Token invalido: " + token)
        }
        token = ""
        isNumero = false
        isLiteral = false
        isMenos = false;
        isIgual = false;
        isMaior = false;
        isDoisPontos = false;
    }
    
    def isFimDeExpressao(token:String):Boolean={
        (token.compareTo("then") == 0 || token.compareTo("else") == 0 || token.compareTo("do") == 0 ||
         token.compareTo("fn") == 0 ||token.compareTo("in") == 0 || token.compareTo("end") == 0 ||
         token.compareTo(")") == 0 ) 
    }
    
    def isDeMeio(token:String):Boolean ={
        (token.compareTo("+") == 0 || token.compareTo(">=") == 0 || token.compareTo(":=") == 0 ||
         token.compareTo(";") == 0)
    }
    
    def getExpressao(token:String):Expressao ={
         if(token.compareTo("+") == 0 || token.compareTo(">=") == 0){
             new ExpressaoOp(token);
         }else if(token.compareTo("if") == 0){
             new ExpressaoIf()
         }else if(token.compareTo(":=") == 0){
            new ExpressaoAtrib()
         }else if(token.compareTo("!") == 0){
             new ExpressaoDeref()
         }else if(token.compareTo("ref") == 0 ){
             new ExpressaoRef()
         }else if(token.compareTo("skip") == 0){
             new ExpressaoSkip()
         }else if(token.compareTo(";") == 0){
             new ExpressaoSeq()
         }else if(token.compareTo("while") == 0){
             new ExpressaoWhile()
         }else if(token.compareTo("fn") == 0){
             new ExpressaoFn()
         }else if(token.compareTo("let") == 0 ){
             new ExpressaoLet()
         }else if(token.compareTo("letrec") == 0){
             new ExpressaoLetRec()
         }else if(token.compareTo("numero") == 0 || token.compareTo("booleano") == 0){
             new ExpressaoValor(token)
         }else if(token.compareTo("(") == 0 ){
             new ExpressaoParent()
         }else{
             null
         }
    }
    
    private def isReservado():Boolean ={
        (token.compareTo("+") == 0 || token.compareTo(">=") == 0 || token.compareTo("if") == 0 ||
         token.compareTo("then") == 0 || token.compareTo("else") == 0 || token.compareTo(":=") == 0 ||
         token.compareTo("!") == 0 || token.compareTo("ref") == 0 || token.compareTo("skip") == 0 ||
         token.compareTo(";") == 0 || token.compareTo("while") == 0 || token.compareTo("do") == 0 ||
         token.compareTo("fn") == 0 || token.compareTo(":") == 0 || token.compareTo("=>") == 0 ||
         token.compareTo("let") == 0 || token.compareTo("in") == 0 || token.compareTo("end") == 0 ||
         token.compareTo("letrec") == 0 || token.compareTo("->") == 0 || token.compareTo("(") == 0 ||
         token.compareTo(")") == 0 || token.compareTo("=") == 0 || token.compareTo("bool") == 0 ||
         token.compareTo("int") == 0)
    }
    
    private def newToken(richChar: runtime.RichChar):Unit ={
        token = token + richChar
        isMenos = (richChar.compare('-') == 0)
        isIgual = (richChar.compare('=') == 0)
        isMaior = (richChar.compare('>') == 0)
        isDoisPontos = (richChar.compare(':') == 0)
        isNumero = richChar.isDigit
        isLiteral = (richChar.isLetter || richChar.compare('_') == 0)
    }
    
    def getTokens(programa:String ):Unit = {
        val charList = programa.toList
        for (i <- 0 until charList.length) {
            val richChar = new runtime.RichChar(charList(i))
            if(richChar.compare(' ') == 0 || richChar.compare('\n') == 0 || richChar.compare('\t') == 0){
                if(token.compareTo("let") == 0 && (i+4) < charList.length){
                    val r = new runtime.RichChar(charList(i+1))
                    val e = new runtime.RichChar(charList(i+2))
                    val c = new runtime.RichChar(charList(i+3))
                    val n = new runtime.RichChar(charList(i+4))
                   
                    if(!(r.compare('r') == 0 && e.compare('e') == 0 && c.compare('c') == 0
                    && !n.isLetterOrDigit && !(n.compare('_') == 0))){
                        addToken
                    }
                           
                }else if(!token.isEmpty){
                    addToken
                }
            }else if(token.isEmpty){
                newToken(richChar)
            }else{
                if((richChar.isLetterOrDigit || richChar.compare('_') == 0) && isLiteral){
                    token = token + richChar
                }else if(richChar.isDigit && (isMenos || isNumero)){
                    token = token + richChar
                    isMenos = false
                    isNumero = true
                }else if((richChar.compare('>') == 0) && (isMenos || isIgual)){
                    token = token + richChar
                    isMenos = false
                    isIgual = false
                }else if((richChar.compare('=') == 0) && (isMaior || isDoisPontos)){
                    token = token + richChar
                    isDoisPontos = false
                    isMaior = false
                }else{
                    addToken
                    newToken(richChar)
                }
            }
        }
        if(!token.isEmpty){
            addToken
        }
    }
    
    
    
    
}
