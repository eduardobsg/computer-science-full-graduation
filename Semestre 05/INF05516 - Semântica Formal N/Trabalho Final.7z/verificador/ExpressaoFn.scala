/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class ExpressaoFn extends Expressao{
    private var tipo:Tipo = null;
    private var tipoIdent:Tipo = null;
    private var e1:Expressao = null;
    private var fimDeContexto = "";
    val nomeExpressao = "fn"
    
    def getFimDeContexto():String = {
        fimDeContexto
    }
    def addExpr(e: Expressao):Unit = {
        e1 = e
        tipo = tipoIdent.clone
        tipo.setPonteiro(e1.getTipo)
    }
    
    def setTipoIdent(t: Tipo):Unit={
        tipoIdent = t
    }
    
    def getTipoIdent():Tipo = {
        tipoIdent
    }
    
    def getTipo():Tipo = {
        tipo
    }
}
