#!/bin/sh

#Put on terminal: sh run.sh

scalac Main.scala Expressao.scala ExpressaoApp.scala ExpressaoAtrib.scala ExpressaoDeref.scala ExpressaoExcl.scala ExpressaoFn.scala ExpressaoIf.scala ExpressaoLet.scala ExpressaoLetRec.scala ExpressaoOp.scala ExpressaoParent.scala ExpressaoRef.scala ExpressaoSeq.scala ExpressaoSkip.scala ExpressaoValor.scala ExpressaoWhile.scala Tipo.scala Tokens.scala
