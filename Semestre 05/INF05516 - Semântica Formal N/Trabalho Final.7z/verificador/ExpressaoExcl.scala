/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class ExpressaoExcl extends Expressao {
    private var tipo:Tipo = null;
    
    def this(e1: Expressao) = {
        this(
        if(e1.getTipo.isRef){
            tipo = e1.getTipo.getTipoReferenciado;
        }else{
            throw new Exception("Incoerencia de tipos");
        }
        )
    }
    
    def getTipo():Tipo = {
        tipo
    }
}
