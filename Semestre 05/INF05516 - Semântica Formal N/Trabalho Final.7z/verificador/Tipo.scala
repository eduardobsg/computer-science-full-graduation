/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package verificador

class Tipo {
    protected var tipo = "";
    protected var isRefe = false;
    protected var isPointer = false;
    protected var tipoApontado: Tipo = null;
    protected var tipoReferenciado: Tipo = null;
    
    def this(t: String) = this(tipo = t)
    
    def getNome():String = {
        tipo
    }
    
    def setPonteiro(t: Tipo):Unit = {
        isPointer = true
        tipoApontado = t
        
    }
    
    def setRef(t: Tipo):Unit = {
        isRefe = true
        tipoReferenciado = t
    }
    
    def isRef():Boolean = {
        isRefe
    }
    
    def isPonteiro():Boolean = {
        isPointer
    }
    
    def getTipoApontado():Tipo = {
        tipoApontado
    }
    
    def getTipoReferenciado():Tipo = {
        tipoReferenciado
    }
    
    override def clone(): Tipo = {
        val tRet = new Tipo(tipo)
        if(isRefe){
            tRet.setRef(tipoReferenciado.clone)
        }
        if(isPonteiro){
            tRet.setPonteiro(tipoApontado.clone)
        }
        tRet
    }
    
    def isIgual(t : Tipo): Boolean={
        if(this == t){
            true
        }else if(tipo.compareTo(t.tipo) == 0){
            if(isRefe == t.isRef && isPointer == t.isPointer){
                if(isPonteiro && isRef){
                    tipoReferenciado.isIgual(t.tipoReferenciado) && tipoApontado.isIgual(t.tipoApontado)
                }else if(isPonteiro){
                    tipoApontado.isIgual(t.tipoApontado)
                }else if(isRefe){
                    tipoReferenciado.isIgual(t.tipoReferenciado)
                }else{
                    true
                }
            }else{
                false
            }
        }else{
            false
        }
    }
    
    def isIgualSemPonteiro(t : Tipo): Boolean={
        if(tipo.compareTo(t.tipo) == 0){
            if(isRefe == t.isRef){
                if(t.isRefe){
                    tipoReferenciado.isIgual(t.tipoReferenciado)
                }else{
                    true
                }
            }else{
                false
            }
        }else{
            false
        }
    }
    
}
